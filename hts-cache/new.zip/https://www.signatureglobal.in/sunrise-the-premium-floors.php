<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="facebook-domain-verification" content="zqv18clg4hyd5synd83cbrczwv588t" />
<title> Affordable housing project in Karnal | Affordable Flats in Karnal | Sunrise The Premium Floors</title>
<meta name=description content="Signature Global is coming up with new Affordable housing project in Sec 35, Karnal. We aspire to deliver some of India’s most innovative real estate projects in Karnal." />
<meta name=keywords content="Affordable housing project in Karnal, Affordable housing sector 35 in karnal, Affordable Flats in Karnal, 2 Bhk Flats in Karnal, 1 Bhk Flats in Karnal, residential flats in karnal" />
<link rel="canonical" href="https://www.signatureglobal.in/sunrise-the-premium-floors.php" />
<meta name="robots" content="noodp" />
 

    
  
  
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5S8ZC8X');</script>
<!-- End Google Tag Manager -->
  
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-90138100-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-90138100-1');
</script>
  
  

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-MRPZNF8ZD2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-MRPZNF8ZD2');
</script>
  
<!-- Global site tag (gtag.js) - Google Ads: 962082073 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-962082073"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config','AW-962082073', {'allow_enhanced_conversions':true});
</script>
<script>
  gtag('config', 'AW-962082073/BUgQCILmzakDEJnq4MoD', {
    'phone_conversion_number': '7053-121-121'
  });
</script>
  
  

  
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '359225061117882');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=359225061117882&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<link href=https://www.signatureglobal.in/images/favicon1.png rel="shortcut icon" type=image/x-icon>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/bootstrap.min.css"/>
<link  rel="stylesheet"  href="https://www.signatureglobal.in/css/fontawesome/css/all.min.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/style.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/responsive.css"/>
<script src="https://www.signatureglobal.in/js/jquery.min.js"></script>
<script  src="https://www.signatureglobal.in/js/bootstrap.min.js"></script>
<style>
  .shhhow{display:block !important; opacity:1 !important;}
  }
</style>

</head>
<body>
  <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5S8ZC8X"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

        
    <header class="header-area">
        <div class="overlayhd"></div>
        <nav class="navbar navbar-expand-md navbar-dark">
            <div class="container">
                <a href="https://www.signatureglobal.in/" class="navbar-brand"><img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/></a> 
                <div class="mobiconbtn">
                    <a href="tel:+91-7053121121">
                        <svg id="Layer_4" data-name="Layer 4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><circle class="cls-1 cls2" cx="75" cy="75" r="73.55"/><path d="M54.68,41.25,50,41a5.64,5.64,0,0,0-4,1.36c-2.25,2-5.86,5.76-7,10.69-1.66,7.37.9,16.39,7.51,25.4S65.5,101.9,87.29,108.06c7,2,12.55.65,16.81-2.08a15,15,0,0,0,6.54-9.54l.75-3.47a2.43,2.43,0,0,0-1.35-2.7L94.3,83a2.41,2.41,0,0,0-2.92.71l-6.18,8a1.78,1.78,0,0,1-2,.6C79,90.85,64.81,84.91,57,69.93a1.77,1.77,0,0,1,.23-2l5.9-6.83a2.41,2.41,0,0,0,.39-2.53L56.77,42.71A2.42,2.42,0,0,0,54.68,41.25Z"/></svg>
                    </a>
                    <a id="forother" href="https://api.whatsapp.com/send?phone=%2B917303918365&text=Hii%2C+I+am+interested+in+Signature%20Global+Affordable+Housing">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>
                  	<a id="forwhatsapp" href="https://api.whatsapp.com/send?phone=919311144622&amp;text=">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>	
                  
                </div>
                <button type="button" class="navbar-toggler collapsed" data-target="#main-nav">
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                </button>                
                <div id="main-nav" class="navbar-collapse">
                    <div class="topnavbaxy">
                        <ul class="navbar-nav width100 dlfx">                         
                         <!--   <li><a href="career.php" class="nav-link" title="Signature Global - Carrer">Career </a></li> -->
                            <li class="dropdown loginpage">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">LOGIN <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://signatureglobal2.my.salesforce-sites.com/sg?cpForm=true" class="assreg" target="_blank">Associate Registration</a></li>
                                     <li><a href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" class="assreg" target="_blank">MBDA/BDA Login</a></li>
                                     <li><a href="https://app.hrone.cloud/login" class="assreg assreg1" target="_blank">Employee Login</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                        <!--    <li><a href="pay-online.php" class="nav-link" title="Signature Global  - Pay Online">APPLY ONLINE</a></li>-->
                            <li><a href="https://www.signatureglobal.in/investor.php" class="nav-link" title="Signature Global  - Investor">Investor</a></li> 
                            <li><a href="https://www.signatureglobal.in/customer_support.php" class="nav-link" title="Signature Global  - Custome Support">Customer Support </a></li>                         
                   <!--      <li><a href="pdf/SG_Mobile_App_User_Manual.pdf" class="nav-link" target="_blank">Mobile app User Manual</a></li>-->
                         <li><a href="https://www.signatureglobal.in/signature-global-foundation.php" class="nav-link" target="_blank">Signature Global Foundation</a></li>                        
                        </ul>
                    </div>                     
                    <ul class="navbar-nav width100 dlfx ">
                   <!--     <li class="nav-item">
                          <a href="about-us.php" class="nav-link" title="Signature Global  - About Us">About US </a>
                          
                      </li>-->
                      
                       <li class="nav-item dropdown loginpage position-relative">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">About US <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#companyjourney" class="assreg scdown"> Company's Journey</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" class="assreg scdown" >Chairman's Message</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" class="assreg scdown" >Board of Directors</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" class="assreg scdown">Key Managerial Positions</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" class="assreg scdown" >Our Architects</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" class="assreg scdown">Vision & Mission</a></li>
                                     <li><a href="https://www.signatureglobal.in/career.php#life-signature" class="assreg" target="_blank"> Life @ Signature Global</a></li>
                                     <li><a href="https://www.signatureglobal.in/green-development.php" class="assreg assreg1" target="_blank">Green Development</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                      
                        <li class="nav-item dropdown">
                            <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">RESIDENTIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                            <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-5">
                                                <strong>Residential</strong>
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/residential/affordable/">Affordable Group Housing</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/premium/">Premium Independent Floors</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/plots/">Residential Plots</a></li>
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div> 
                                            </div>
                                            <div class="col-lg-8 col-md-7">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5 col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Residential</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/residential/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_6" data-name="Layer 6"><g id="Layer_1-6" data-name="Layer 6"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Resdential-nvbg.jpg" alt="Residential Projects by Signature Global
" title="Residential Projects by Signature Global
">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item dropdown">
                          <a href="#" title="Commercial projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">COMMERCIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                          <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-6 ">
                                                <strong>Commercial</strong>
                                    
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/commercial/society-shops/">Society Shops</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/malls/">Mall</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/sco-plots/">SCO</a></li> 
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-lg-8 col-md-6 ">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5  col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Commercial</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/commercial/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_7" data-name="Layer 7"><g id="Layer_1-7" data-name="Layer 7"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Commercial-nvbg.jpg" alt="Commercial Projects by Signature Global" title="Commercial Projects by Signature Global">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item"><a title="Signature Global  - Contact Us" href="https://www.signatureglobal.in/contact.php" class="nav-link">CONTACT US </a></li>
                    </ul>
                    <div class="bottommediamobwrap">
                        <ul class="pplink">
                            <li><a href="https://www.signatureglobal.in/privacy-policy.php">Privacy Policy</a></li>
                          <li><span>|</span></li>
                            <li><a href="https://www.signatureglobal.in/social-media-policy.php">Social Media Policy</a></li>
                        </ul>
                        <div class="footermedianav mtopft">
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <div class="overlaymobbg"></div>    
     <!--Download Brochure-->
    <div class="downloadbtnwrap sg-city-application">
        <a href="pdf/sunrise-the-premium-floors/applicationForm/Application-Form-Karnal.pdf" target="_blank" class="btnrt" alt="">Application Form</a>
    </div>
    <!--Download Brochure-->
    
    <!--Enquire Now Iframe-->
    <div class="registerform">
        <div class="fixedbtn">
            <span class="btnrt">Enquire Now</span>
        </div>
        <div class="innerform">
            <iframe  frameborder="0" width="100%" height="400px" id="abc_frame"></iframe>
        </div>
    </div>
    <!--Enquire Now Iframe-->
    
    <!--banner section-->
    <div class="banner banner-sunrise  padd100">
        <div class="overlaybottom"></div>
        <div class="container">
            <div class="cpationlogo cnewlogo">
                <span><img src="images/logo/SG-Sunrise.png" alt="Logo"/></span>
            </div>
        <!--    <div class="delevered-stam">
                <img src="images/Stamp.svg" alt="Delevered Stam">
            </div> -->
        </div>
    </div>
    <!--banner-->
    <!--rera no-->
    <div class="afterimg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        <span>Rose Building Solutions Pvt Ltd License number – 77 of 2017 dated 14th September 2017 , HRERA Number - 269 of 2017 dated 09.10.2017</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--rera no-->
    
    <!--Welcome Section-->
    <div class="sectionbg-one">
        <div class="innerprobannerbg">
            <div class="container">
                <div class="row padd100">
                    <div class="col-lg-12">
                          <span class="captext wow animate__ animate__fadeInUp">WELCOME TO </span>
                          <h1 class="headingtag clrwh mb-5 wow animate__ animate__fadeInUp">Sunrise The Premium Floors</h1>
                    </div>
                    <div class="col-lg-12">
                        <span class="captext wow animate__ animate__fadeInUp">WHAT MAKES HAR PARIVAR EK GHAR COME TO KARNAL.</span>
                        <p class="clrwh wow animate__ animate__fadeInUp">Karnal, also known as the 'Rice Bowl of India', is a city in Haryana and is also a part of the Delhi NCR (National Capital Region). The city is known since the days of the Mahabharata and is said to have been founded by Karna, the first son of Kunti and archival of Arjuna. But, the city gained fame in the year 1739 when Nadir Shah defeated Muhammad Shah here. Karnal and its adjoining areas played a historic role in India’s struggle for freedom. During the First War of Independence in 1857 which broke out at Meerut, the residents of Karnal along with 15 other villages refused to pay revenue to the British Raj. Furthermore, the city is also the birthplace of the first Indo-American woman astronaut, Kalpana Chawla, who went to space twice. First, on the Space Shuttle Columbia in 1997 as a mission specialist and primary robotic arm operator. And in 2003, was one of the seven crew members that died in the Space Shuttle Columbia tragedy. Dedicated to her memory and accomplishments, the Kalpana Chawla Hospital also recently became operational in Karnal. Termed the ‘Beautiful City’ of Haryana renowned for its cleanliness, Karnal has also been selected as one of the hundred Indian cities to be developed as a smart city under PM Narendra Modi's flagship Smart Cities Mission. Promising a bright future in real estate development for a historic city.</p>
                      
                    </div>
                  
                  <div class="col-lg-12">
                    <div class="textwrap mt-4">
                       <h2><p>1 & 2 BHK LOW RISE INDEPENDENT FLOORS, SECTOR 35 KARNAL </p></h2>
                      
                    </div>
                </div>
                </div>
            </div>
        </div>      
    </div>
    <!--Welcome Section-->
    
   <!--Delivered Project Gallery-->
    <div class="videogallerywrap padd100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <span class="captext fcolorlgt wow animate__ animate__fadeInUp">Testimonials</span>
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Listen to some words of appreciation</h2>
                    
                    <div class="controlarcsr pull-right mobslidear">
                        <span class="arrow-icon-leftcsr leftvdg3">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </span>
                        <span class="arrow-icon-rightcsr rightvdg3">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </span>
                   </div>
                </div>
                <div class="col-lg-12">
                    <div class="vdsliderg3">
                        <div>
                            <iframe width="100%" height="290" src="https://www.youtube.com/embed/6qmvmALsYCc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <div>
                            <iframe width="100%" height="290" src="https://www.youtube.com/embed/wpvUHS1xhQU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                        <div>
                            <iframe width="100%" height="290" src="https://www.youtube.com/embed/f4eaAGd4Wd4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                </div>
                <!--<div class="col-lg-3 wow animate__ animate__fadeInUp">-->
                <!--    <div class="csrbtn pull-right">-->
                <!--        <a class="abtn halvar_rg" href="synera-video-gallery.php">-->
                <!--           Video Gallery-->
                <!--            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{fill:none;stroke:#203d3b;stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>-->
                <!--        </a>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
    </div>
    <!--Delivered Project Gallery-->
    
    <!--Location-->
    <div class="locationwrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="locationmap wow animate__ animate__fadeInUp">
                        <a data-fancybox="unit-location" href="images/projects/sunrise-the-premium-floors/LocationMap/Location-Map2.jpg">
                            <img src="images/projects/sunrise-the-premium-floors/LocationMap/Location-Map2.jpg" alt="Location Map - Sunrise Premium Residential Floors at Signature Global Karnal 
" title="Location Map - Sunrise Premium Residential Floors at Signature Global Karnal 
"/>
                            <div class="btnclick halvar_rg">
                                <span>Click Here</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-5 location-bg">
                    <div class="locationadvantage">
                        <h3 class="headingtag clrwh mb-4 wow animate__ animate__fadeInUp">Location<br/> Advantages</h3>
                        
                        <div class="locationlistslider">
                            <div>
                                <div class="ullist wow animate__ animate__fadeInUp">
                                    <ul>
                                     

<li>6.5 acres housing society</li>
<li>Low rise premium apartments – under Deen Dayal Jan Awas Yojana Affordable plotted Housing Policy, 2016</li>
<li>Designed by Padmabhushan Hafeez Contractor</li>
<li>First aluminium form work technology enabled building project</li>
<li>Classical theme</li>
<li>Jogging track</li>
<li>Gated community</li>
<li>Thematic garden</li>
<li>Earthquake resistant structure</li>
<li>Convenient shopping plaza within the compound</li>


                                    </ul>
                                </div>
                            </div>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Location-->
    
    <!--Unit Plan-->
    <div class="unitsectionwrap padd100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Floor Plans</h2>
                    <div class="controlar pull-right" style="display: none;">
                        <span class="arrow-icon-leftpl">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </span>
                        <span class="arrow-icon-rightpl">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </span>
                    </div>
                </div>
                <div class="col-lg-12 wow animate__ animate__fadeInUp">
                    <div class="unitplanslider">
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/projects/sunrise-the-premium-floors/B1.jpg" ><img src="images/projects/sunrise-the-premium-floors/S1.jpg" alt="Lower Ground Floor Plan - Sunrise Premium Residential Floors at Signature Global  Karnal 
" title="Lower Ground Floor Plan - Sunrise Premium Residential Floors at Signature Global  Karnal 
"/></a>
                               <h3>
                                  <b>Commercial Ground Floor Plan</b>
                              </h3>
                            </div>
                        </div>
                       <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/projects/sunrise-the-premium-floors/B3.jpg"><img src="images/projects/sunrise-the-premium-floors/S3.jpg" alt="First Floor Plan - Sunrise Premium Residential Floors at Signature Global karnal 
" alt="First Floor Plan - Sunrise Premium Residential Floors at Signature Global karnal 
"/></a>
                                <h3>
                                  <b>Type-A (2BHK)</b>
                              <span>Ground Floor (Typical)</span>
                              </h3>
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/projects/sunrise-the-premium-floors/B2.jpg"><img src="images/projects/sunrise-the-premium-floors/S2.jpg" alt="Upper Ground Floor Plan - Sunrise Premium Residential Floors at Signature Global karnal
" title="Upper Ground Floor Plan - Sunrise Premium Residential Floors at Signature Global karnal
"/></a>
                               <h3>
                                  <b>Type-A (2BHK)</b>
                              <span>1st and 2nd Floor (Typical)</span>
                              </h3>
                            </div>
                        </div>
                       
                   <!--     <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/projects/sunrise-the-premium-floors/floorplan/4.jpg"><img src="images/projects/sunrise-the-premium-floors/floorplan/4.jpg" alt="Second Floor Plan - Sunrise Premium  Residential Floors at Signature Global 
" title="Second Floor Plan - Sunrise Premium  Residential Floors at Signature Global 
"/></a>
                                <b>Second Floor</b>
                            </div>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Unit Plan-->
    
    <!--Site Plan-->
    <div class="siteplanwrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Site Plan</h2>
                </div>
                
                <div class="col-lg-12">
                    <div class="signum-slider">
                      <div>
                              <div class="sitemapimg wow animate__ animate__fadeInUp">
                              <a data-fancybox="siteplan" href="images/projects/sunrise-the-premium-floors/1.jpg">
                                  <img src="images/projects/sunrise-the-premium-floors/1.jpg" alt=" Residential Building Site Plan - Sunrise Premium Residential Floors at Signature Global 
      " title=" Residential Building Site Plan - Sunrise Premium Residential Floors at Signature Global 
      "/>
                              </a>
                          </div>
                      </div>
                       <div>
                              <div class="sitemapimg wow animate__ animate__fadeInUp">
                              <a data-fancybox="siteplan" href="images/projects/sunrise-the-premium-floors/2.jpg">
                                  <img src="images/projects/sunrise-the-premium-floors/2.jpg" alt=" Residential Building Site Plan - Sunrise Premium Residential Floors at Signature Global 
      " title=" Residential Building Site Plan - Sunrise Premium Residential Floors at Signature Global 
      "/>
                              </a>
                          </div>
                      </div>
                  </div>
                </div>
            </div>
        </div>
    </div>
    <!--Site Plan-->

    <!--Projects Gallery-->
    <div class="elevationsectionwrap padd100">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
                <span class="captext fcolorlgt wow animate__ animate__fadeInUp">Elevations</span>
                <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp"> Our array of luxury accommodations</h2>
            </div>
            <div class="col-lg-12 wow animate__ animate__fadeInUp">
                <div class="progalleryslider mt-4">
                    <div class="slider-for">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/1.jpg" alt="Low Rise Building Exterior View - Sunrise Premium Residential Floors at Signature Global" title="Low Rise Building Exterior View - Sunrise Premium Residential Floors at Signature Global 
">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/2.jpg" alt="Low Rise Building Garden view - Sunrise Premium Residential Floors at Signature Global" title="Low Rise Building Garden view - Sunrise Premium Residential Floors at Signature Global ">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/3.jpg" alt="Low Rise Building Residential Park - Sunrise Premium Residential Floors at Signature Global" title="Low Rise Building Residential Park - Sunrise Premium Residential Floors at Signature Global 
">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/4.jpg" alt=" Parking Area  - Sunrise Premium Residential Floors at Signature Global" title=" Parking Area  - Sunrise Premium Residential Floors at Signature Global
">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/5.jpg" alt="Kids Play Amusement Park - Sunrise Premium Residential Floors at Signature Global" title="Kids Play Amusement Park - Sunrise Premium Residential Floors at Signature Global">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/6.jpg" alt=" Low Rise Building Front View - Sunrise Premium Residential Floors at Signature Global 
" title="">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/7.jpg" alt="Low Rise Building Another Front View - Sunrise Premium Residential Floors at Signature Global 
" title="Low Rise Building Another Front View - Sunrise Premium Residential Floors at Signature Global">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/8.jpg" alt="Low Rise Building Campus - Sunrise Premium Residential Floors at Signature Global
" title="Low Rise Building Campus - Sunrise Premium Residential Floors at Signature Global">
                    </div>
                    <div class="slider-nav"> 
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/1.jpg" alt="Low Rise Building Exterior View - Sunrise Premium Residential Floors at Signature Global" title="Low Rise Building Exterior View - Sunrise Premium Residential Floors at Signature Global 
">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/2.jpg" alt="Low Rise Building Garden view - Sunrise Premium Residential Floors at Signature Global" title="Low Rise Building Garden view - Sunrise Premium Residential Floors at Signature Global ">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/3.jpg" alt="Low Rise Building Residential Park - Sunrise Premium Residential Floors at Signature Global" title="Low Rise Building Residential Park - Sunrise Premium Residential Floors at Signature Global 
">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/4.jpg" alt=" Parking Area  - Sunrise Premium Residential Floors at Signature Global" title=" Parking Area  - Sunrise Premium Residential Floors at Signature Global
">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/5.jpg" alt="Kids Play Amusement Park - Sunrise Premium Residential Floors at Signature Global" title="Kids Play Amusement Park - Sunrise Premium Residential Floors at Signature Global">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/6.jpg" alt=" Low Rise Building Front View - Sunrise Premium Residential Floors at Signature Global 
" title="">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/7.jpg" alt="Low Rise Building Another Front View - Sunrise Premium Residential Floors at Signature Global 
" title="Low Rise Building Another Front View - Sunrise Premium Residential Floors at Signature Global 
">
                        <img class="item-slick" src="images/projects/sunrise-the-premium-floors/elevation/8.jpg" alt="Low Rise Building Campus - Sunrise Premium Residential Floors at Signature Global
" title="Low Rise Building Campus - Sunrise Premium Residential Floors at Signature Global
">
                    </div>
                </div>
            </div>
          </div>
        </div>
    </div>
    <!--Projects Gallery-->
    
   
    <!--Accordion Notification-->
    <div class="notificationwrap padb100">
        <div class="container">
            <div class="accordion" id="accordionExample">
                <div class="card wow animate__ animate__fadeInUp">
                    <div class="card-head" id="headingOne">
                        <h2 class="mb-0 collapsed show-more" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            <b>Notification Advertisement</b> <span class="halvar_rg text show-more-height"></span>
                        </h2>
                    </div>
                
                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="notificationtable">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Title</th>
                                                <th>Date</th>
                                                <th>English</th>
                                                <th>Hindi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Sunrise The Premium Floors Ad</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/sunrise-the-premium-floors/Karnal-notification-nov-1.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Compliance of stipulated environmental conditions & safeguards</td>
                                                <td>-</td>
                                                <td><a href="pdf/sunrise-the-premium-floors/6 Month Compliances-Rose building.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                             
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                
                </div>
        </div>
    </div>
    <!--Accordion Notification-->
    
    <!--CIN No-->
    <div class="footerpagetop">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        <span>Rose Building Solutions Pvt Ltd , CIN - U70109DL2013PTC257303, 2nd Floor, Unit no. 201 A,Tower A, Signature Towers,South City 1,Gurugram,122001</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--CIN No-->

	<div class="footerpagetop">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        <strong>Disclaimer</strong>
                      	<p>Promoter urges every applicant to inspect the project site and shall not merely rely upon any architectural impression, plan or sales brochure and, therefore, requests to make personal judgment prior to submitting an application for allotment. The Project is being developed in phases, hence, certain facilities/amenities etc, may be used by allottee of other phases. Unless otherwise stated, all the images, visuals, materials and information contained herein are purely creative/artistic and may not be actual representations of the product and/or any amenities. Further, the actual design may vary in the fit and finished form, from the one displayed above . Journey time shown, if any, is based upon Google Maps which may vary as per the traffic at a relevant point of time. *Rate mentioned above does not include GST and other statutory charges, if applicable. T & C Apply. 1 sq. mt. = 10.7639 sq. ft.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>    
    <script>
         $.urlParam = function (name) {
            var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);
            return (results !== null) ? results[1] || 0 : false;
            }
            
            var utmSource = $.urlParam('utm_source') ? $.urlParam('utm_source') : 'direct';
            var utmMedium = $.urlParam('utm_medium') ? $.urlParam('utm_medium') : '';
            var utmCampaign = $.urlParam('utm_campaign') ? $.urlParam('utm_campaign') : '';
            var utmId = $.urlParam('utm_id') ? $.urlParam('utm_id') : '';
             
            var url = new URL("https://enquiry.signatureglobal.in/?projectName=Sunrise&enquiryFrom=Online");
            $(function() {
                    url.searchParams.set('utm_source',utmSource);
                    if(utmMedium!=""){url.searchParams.set('utm_medium',utmMedium);}
                    if(utmCampaign!=""){url.searchParams.set('utm_campaign',utmCampaign);}
                    if(utmId!=""){url.searchParams.set('utm_id',utmId);}
                    $('#abc_frame').attr('src', url)
            
            });

    </script>

<!--Footer-->
    <footer class="footerbg padd100">
       <div class="width100">
            <div class="container">
                <div class="row paddb60">
                   <div class="col-12">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt m-0 wow animate__ animate__fadeInUp">
                                    <strong>SIGNATURE GLOBAL</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/residential/" title="Residentential projects by Signature Global">Residential</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/" title="Commercial projects by Signature Global">Commercial</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/">Retail</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class=" footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>OUR PRESENCE</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/commercial/society-shops/gurugram/" title="Signature Global in Gurugram">Gurugram</a></li>
                                        <li><a href="https://www.signatureglobal.in/residential/plots/karnal" title="Signature Global in Karnal">Karnal</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/ghaziabad" title="Signature Global in Ghaziabad">Ghaziabad</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>ABOUT US</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" title="Signature Global - Chairman's message" class="scdown">Chairman’s Message</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" title="Signature Global - Board of Director" class="scdown">Board of Directors</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" title="Signature Global - Key Managerial Positions" class="scdown">Key Managerial Positions</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" title="Our Architect" class="scdown">Our Architects</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" title="Signature Global - Vission & Mission of Signature Global" class="scdown">Vision & Mission</a></li>
                                    <!--    <li><a href="signature-global-foundation.php" title="Signature Global Foundation">Signature Global Foundation</a></li>-->
                                    </ul>
                                </div>
                           </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>CAREERS</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/career.php#as-associate" title="Careers at Signature Global">As Associate</a></li>
                                        <li><a href="https://www.signatureglobal.in/career.php#life-signature" title="Life At Signature Global">Life @ Signature Global </a></li>
                                        <li><a href="#"></a></li>
                                    </ul>
                                </div>
                              
                                <div class="footernav halvar_lt wow animate__ animate__fadeInUp publicnoticehome">
                                  <ul>
                                    <li><a href="https://www.signatureglobal.in/public-notice.php" title="Signature Global Public Notice"><strong>Public Notice</strong></a></li>
                                  </ul>                                  
                             	</div>
                                          
                           </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong style="margin-bottom: 15px;">GALLERY</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/gallery.php" title="Signature Global Gallery">Picture Library</a></li>
                                        <li><a href="https://www.signatureglobal.in/video-gallery.php" title="Signature Global Video Gallery">Video Library</a></li>
                                    </ul>
                                </div>   
                            </div>
                           <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/media.php" title="Signature Global Blogs">MEDIA</a></strong> 
                                    <ul>
                                     <li><a href="https://www.signatureglobal.in/media-coverage.php" title="Signature Global Gallery">Media Coverage</a></li>
                                        <!--<li><a href="https://www.signatureglobal.in/press-release.php" title="Signature Global Video Gallery">Press Release</a></li> -->
                                         <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Gallery">Press Kit</a></li>
                                        <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Video Gallery">Media Contact</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                   <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/blog" title="Signature Global Blogs">Blog</a></strong>
                                <!--    <strong class="mb-2"><a class="clrwh opctext" href="https://online.anyflip.com/dhkmm/nalj/mobile/index.html" target="_blank" title="Signature Global Newsletter ">NEWSLETTER</a></strong> -->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/home-loans.php" title="Signature Global - Home Loans">Home Loans</a></strong>
                                  <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/pay-online.php" title="Signature Global - APPLY ONLINE">PAY ONLINE</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/award.php" title="Signature Global Certificates">AWARD</a></strong>                                  
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                 <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" target="_blank" title="Signature Global Login">MBDA/BDA Login</a></strong>
                                   <!-- <strong class="mb-2"><a class="clrwh opctext" href="http://signatureglobal04.realboost.in/add_appointment.aspx" target="_blank" title="Signature Global Appointments">Appointment</a></strong>-->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/terms-of-appointment.php" title="Signature Global - Terms of appointment">Terms of Appointment</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/green-development.php" title="Signature Global - Green Development">Green Development</a></strong>
                                </div>     
                            </div>
                        </div>
                        
                   </div>
                </div>
            </div>
        </div>
      
        
        <div class="width100 bordertop padt60 wow animate__ animate__fadeInUp">
            <div class="container">
                <div class="row">    
                    <div class="col-lg-3">
                       <div class="footerlogo wow animate__ animate__fadeInUp">
                           <img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/>
                       </div> 
                    </div>
                    <div class="col-lg-4">
                        <div class="footernav pl-65 wow animate__ animate__fadeInUp">
                            <strong>REGISTERED OFFICE</strong>
                            <p>13<sup>th</sup> Floor, Dr. Gopal Das Bhawan, 28<br class="ftmb"/> Barakhamba Road, Connaught Place,<br class="ftmb"/> New Delhi 110 001, India.</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Registered Office: +91 11 4928 1700</a>
                        </div>
                    </div>
                    <div class="col-lg-3 pl-00">
                        <div class="footernav wow animate__ animate__fadeInUp">
                            <strong>CORPORATE OFFICE</strong>
                            <p>Unit No.101, Ground Floor, Tower-A,<br class="ftmb"/>Signature Tower South City-1, Gurugram,<br class="ftmb"/>Haryana 122 001, India</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Corporate Office: +91 124 4398 011</a>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="footermedianav mtopft wow animate__ animate__fadeInUp">
                            <strong>FOLLOW US</strong>
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </footer>
     <!--policytab-->
     <div class="policywraper">
         <div class="container">
             <div class="row">
                 <div class="col-lg-10 col-md-10">
                     <div class="policylink text-left">
                        <p>© 2023 Signature Global. All Rights Reserved <br class="mobhidebr"/><span class="clrwh mobhide">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/advertising-policy-for-channel-partners.php"  >Advertising Policy For Channel Partners</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/privacy-policy.php" title="Signature Global - Privacy Policy">Privacy Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/social-media-policy.php" title="Signature Global - Social Media Policy">Social Media Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/generic-faqs-for-haryana-affordable-housing-policy.php">Generic Faq's</a>                        
                       </p>
                       
                     </div>
                  
                 </div>
             <!--     <div class="col-lg-2 col-md-2 cclogo ">
                     <img src="https://www.signatureglobal.in/images/cogdigital.svg" alt="" width="15">
                   </div> -->
             </div>
         </div>
     </div>
   
    <script>
         $.urlParam = function (name) {
            var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);
            return (results !== null) ? results[1] || 0 : false;
            }
            
            var utmSource = $.urlParam('utm_source') ? $.urlParam('utm_source') : 'direct';
            var utmMedium = $.urlParam('utm_medium') ? $.urlParam('utm_medium') : '';
            var utmCampaign = $.urlParam('utm_campaign') ? $.urlParam('utm_campaign') : '';
            var utmId = $.urlParam('utm_id') ? $.urlParam('utm_id') : '';
             
            var enq_url = new URL("https://enquiry.signatureglobal.in/?projectName=ContactUs&enquiryFrom=Online");
            $(function() {
                    enq_url.searchParams.set('utm_source',utmSource);
                    if(utmMedium!=""){enq_url.searchParams.set('utm_medium',utmMedium);}
                    if(utmCampaign!=""){enq_url.searchParams.set('utm_campaign',utmCampaign);}
                    if(utmId!=""){enq_url.searchParams.set('utm_id',utmId);}
                    
              if($('#main_frame').length > 0)
                    $('#main_frame').attr('src', enq_url)
            
            });

    </script>


<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/animate.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/jquery.fancybox.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/slick.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>


<script src="https://www.signatureglobal.in/js/wow.min.js"></script>
<script src="https://www.signatureglobal.in/js/slick.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.fancybox.min.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.validate.min.js"></script>
<script src="https://www.signatureglobal.in/js/additional-methods.js"></script>
<script src="https://www.signatureglobal.in/js/custom.js"></script> 
<script src="https://www.signatureglobal.in/js/app.js"></script> 
<!-- Start of  Zendesk Widget script -->
<script>
   setTimeout(function(){
      var chatScript = '<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"/>';
      $('body').append(chatScript);
   },  
 5000);
</script>

<script>
  window.addEventListener('load', function() {
    jQuery('body').on('mousedown', '[href*="tel:"]', function() {
      gtag('event', 'phone_call')
    })
    jQuery('body').on('mousedown', '[href*="api.whatsapp.com"]', function() {
      gtag('event', 'whatsapp_click')
    })
    jQuery('body').on('mousedown', '.btnrt:contains(Enquire Now)', function() {
      gtag('event', 'enquire_now')
    })
    jQuery('body').on('mousedown', '.contact100-form-btn:contains(Submit)', function() {
      gtag('event', 'Submit_btn')
    })
  });

</script>
<!--<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"> </script>-->
<!-- End of  Zendesk Widget script -->





 


</body>
</html>