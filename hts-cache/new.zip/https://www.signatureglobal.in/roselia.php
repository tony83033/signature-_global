<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="facebook-domain-verification" content="zqv18clg4hyd5synd83cbrczwv588t" />
<title> The Roselia Sector 95A | New Affordable Housing Projects Gurgaon</title>
<meta name=description content="The Roselia is Signature Global's affordable housing project in Gurgaon Sector 95A, with close proximity to places like Dwarka Expressway, Pataudi Road, NH-8." />
<meta name=keywords content="The Roselia Sector 95A - Signature Global, Affordable Housing Project in Gurgaon sector 95A, Sector 95A The Roselia, New Projects in Pataudi Road, Gurgaon, 2 BHK Flats for Sale in Pataudi Road" />
<link rel="canonical" href="https://www.signatureglobal.in/roselia.php" />
<meta name="robots" content="noodp" />
 

    
  
  
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5S8ZC8X');</script>
<!-- End Google Tag Manager -->
  
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-90138100-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-90138100-1');
</script>
  
  

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-MRPZNF8ZD2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-MRPZNF8ZD2');
</script>
  
<!-- Global site tag (gtag.js) - Google Ads: 962082073 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-962082073"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config','AW-962082073', {'allow_enhanced_conversions':true});
</script>
<script>
  gtag('config', 'AW-962082073/BUgQCILmzakDEJnq4MoD', {
    'phone_conversion_number': '7053-121-121'
  });
</script>
  
  

  
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '359225061117882');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=359225061117882&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<link href=https://www.signatureglobal.in/images/favicon1.png rel="shortcut icon" type=image/x-icon>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/bootstrap.min.css"/>
<link  rel="stylesheet"  href="https://www.signatureglobal.in/css/fontawesome/css/all.min.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/style.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/responsive.css"/>
<script src="https://www.signatureglobal.in/js/jquery.min.js"></script>
<script  src="https://www.signatureglobal.in/js/bootstrap.min.js"></script>
<style>
  .shhhow{display:block !important; opacity:1 !important;}
  }
</style>

</head>
<body>
  <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5S8ZC8X"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

        
    <header class="header-area">
        <div class="overlayhd"></div>
        <nav class="navbar navbar-expand-md navbar-dark">
            <div class="container">
                <a href="https://www.signatureglobal.in/" class="navbar-brand"><img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/></a> 
                <div class="mobiconbtn">
                    <a href="tel:+91-7053121121">
                        <svg id="Layer_4" data-name="Layer 4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><circle class="cls-1 cls2" cx="75" cy="75" r="73.55"/><path d="M54.68,41.25,50,41a5.64,5.64,0,0,0-4,1.36c-2.25,2-5.86,5.76-7,10.69-1.66,7.37.9,16.39,7.51,25.4S65.5,101.9,87.29,108.06c7,2,12.55.65,16.81-2.08a15,15,0,0,0,6.54-9.54l.75-3.47a2.43,2.43,0,0,0-1.35-2.7L94.3,83a2.41,2.41,0,0,0-2.92.71l-6.18,8a1.78,1.78,0,0,1-2,.6C79,90.85,64.81,84.91,57,69.93a1.77,1.77,0,0,1,.23-2l5.9-6.83a2.41,2.41,0,0,0,.39-2.53L56.77,42.71A2.42,2.42,0,0,0,54.68,41.25Z"/></svg>
                    </a>
                    <a id="forother" href="https://api.whatsapp.com/send?phone=%2B917303918365&text=Hii%2C+I+am+interested+in+Signature%20Global+Affordable+Housing">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>
                  	<a id="forwhatsapp" href="https://api.whatsapp.com/send?phone=919311144622&amp;text=">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>	
                  
                </div>
                <button type="button" class="navbar-toggler collapsed" data-target="#main-nav">
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                </button>                
                <div id="main-nav" class="navbar-collapse">
                    <div class="topnavbaxy">
                        <ul class="navbar-nav width100 dlfx">                         
                         <!--   <li><a href="career.php" class="nav-link" title="Signature Global - Carrer">Career </a></li> -->
                            <li class="dropdown loginpage">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">LOGIN <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://signatureglobal2.my.salesforce-sites.com/sg?cpForm=true" class="assreg" target="_blank">Associate Registration</a></li>
                                     <li><a href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" class="assreg" target="_blank">MBDA/BDA Login</a></li>
                                     <li><a href="https://app.hrone.cloud/login" class="assreg assreg1" target="_blank">Employee Login</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                        <!--    <li><a href="pay-online.php" class="nav-link" title="Signature Global  - Pay Online">APPLY ONLINE</a></li>-->
                            <li><a href="https://www.signatureglobal.in/investor.php" class="nav-link" title="Signature Global  - Investor">Investor</a></li> 
                            <li><a href="https://www.signatureglobal.in/customer_support.php" class="nav-link" title="Signature Global  - Custome Support">Customer Support </a></li>                         
                   <!--      <li><a href="pdf/SG_Mobile_App_User_Manual.pdf" class="nav-link" target="_blank">Mobile app User Manual</a></li>-->
                         <li><a href="https://www.signatureglobal.in/signature-global-foundation.php" class="nav-link" target="_blank">Signature Global Foundation</a></li>                        
                        </ul>
                    </div>                     
                    <ul class="navbar-nav width100 dlfx ">
                   <!--     <li class="nav-item">
                          <a href="about-us.php" class="nav-link" title="Signature Global  - About Us">About US </a>
                          
                      </li>-->
                      
                       <li class="nav-item dropdown loginpage position-relative">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">About US <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#companyjourney" class="assreg scdown"> Company's Journey</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" class="assreg scdown" >Chairman's Message</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" class="assreg scdown" >Board of Directors</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" class="assreg scdown">Key Managerial Positions</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" class="assreg scdown" >Our Architects</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" class="assreg scdown">Vision & Mission</a></li>
                                     <li><a href="https://www.signatureglobal.in/career.php#life-signature" class="assreg" target="_blank"> Life @ Signature Global</a></li>
                                     <li><a href="https://www.signatureglobal.in/green-development.php" class="assreg assreg1" target="_blank">Green Development</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                      
                        <li class="nav-item dropdown">
                            <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">RESIDENTIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                            <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-5">
                                                <strong>Residential</strong>
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/residential/affordable/">Affordable Group Housing</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/premium/">Premium Independent Floors</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/plots/">Residential Plots</a></li>
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div> 
                                            </div>
                                            <div class="col-lg-8 col-md-7">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5 col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Residential</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/residential/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_6" data-name="Layer 6"><g id="Layer_1-6" data-name="Layer 6"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Resdential-nvbg.jpg" alt="Residential Projects by Signature Global
" title="Residential Projects by Signature Global
">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item dropdown">
                          <a href="#" title="Commercial projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">COMMERCIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                          <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-6 ">
                                                <strong>Commercial</strong>
                                    
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/commercial/society-shops/">Society Shops</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/malls/">Mall</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/sco-plots/">SCO</a></li> 
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-lg-8 col-md-6 ">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5  col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Commercial</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/commercial/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_7" data-name="Layer 7"><g id="Layer_1-7" data-name="Layer 7"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Commercial-nvbg.jpg" alt="Commercial Projects by Signature Global" title="Commercial Projects by Signature Global">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item"><a title="Signature Global  - Contact Us" href="https://www.signatureglobal.in/contact.php" class="nav-link">CONTACT US </a></li>
                    </ul>
                    <div class="bottommediamobwrap">
                        <ul class="pplink">
                            <li><a href="https://www.signatureglobal.in/privacy-policy.php">Privacy Policy</a></li>
                          <li><span>|</span></li>
                            <li><a href="https://www.signatureglobal.in/social-media-policy.php">Social Media Policy</a></li>
                        </ul>
                        <div class="footermedianav mtopft">
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <div class="overlaymobbg"></div>    
   
	<!--Download Brochure-->
    <div class="downloadbtnwrap oc-certificates">
        <a href="roselia-oc-certificate.php" class="btnrt" alt="" target="_blank">OC Certificates</a>
    </div>
    <!--Download Brochure-->
    
    <!--Enquire Now Iframe-->
    <div class="registerform">
        <div class="fixedbtn">
            <span class="btnrt">Enquire Now</span>
        </div>
        <div class="innerform">
            <iframe  frameborder="0" width="100%" height="400px" id="abc_frame"></iframe>
        </div>
    </div>
    <!--Enquire Now Iframe-->
    <!--banner section-->
    <div class="banner banner-sector95a-roselia">
        <div class="overlaybottom"></div>
        <div class="container">
            <div class="cpationlogo">
                <span><img src="images/logo/The-Roselia.png" alt="Signature global Roselia Affordable House -  logo" title="Signature global Roselia Affordable House -  logo"></span>
            </div>
          <div class="delevered-stam">
                <img src="images/Stamp.svg" alt="Delevered Stam">
         	</div>
        </div>
    </div>
    <!--banner-->
    <!--rera no-->
    <div class="afterimg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        <span>Licence No.13 of 2016 dated 26-09-2016. Building Plan Approved Plan ZP -1131/SD(BS)/2016/479 dated 09-01-2017, HRERA Number - 05 of 2017 dated 20.06.2017</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--rera no-->
    <!--Welcome Section-->
    <div class="sectionbg-one">
        <div class="innerprobannerbg">
            <div class="container">
                <div class="row padd100">
                    <div class="col-lg-12">
                          <span class="captext wow animate__ animate__fadeInUp">WELCOME TO </span>
                          <h1 class="headingtag clrwh mb-5 wow animate__ animate__fadeInUp">The Roselia Sector 95A, Gurugram</h1>
                    </div>
                    <div class="col-lg-12">
                        <p class="mb-3 clrwh wow animate__ animate__fadeInUp">Welcome to the whole new world of comfort living at the most strategically developed location of the New Gurgaon area. Located in Sector 95A, New Gurgaon, this residential project has spaciously planned 2 BHK units. It covers an area of 8.034 acres & has a total number of 1101 units. Roselia by Signature Global is a work of perfection clubbed with superb features & modern amenities. Life at Roselia is full of fantastic experiences & memorable moments. There are amenities for individuals of all age groups. From crèche to kids' play area, jogging tracks & senior citizen seating, the project has it all. 
</p>                  
                        <p class="mb-3 clrwh wow animate__ animate__fadeInUp">The green pathways & the expansive lush surrounding will captivate residents & will also keep them close to Mother Nature. The neighbourhood is also a settled surrounding, where one can easily find good recreational centers, hospitals, schools & much more. The project is at the most accessible address ever. Professionals working in Gurgaon or nearby areas prefer staying here. Going to Gurgaon & Delhi from Roselia is easy & smooth. The connectivity is good enough to help the dwellers commute from one place to another.
</p>                     
                        <p class="mb-3 clrwh wow animate__ animate__fadeInUp">Roselia connects well to Manesar & National Highway 8. The Northern Peripheral Road or the Dwarka Expressway is nearby the project. It is bang on the proposed Gurugram-Pataudi National Highway. In order to fulfill the daily needs of the dwellers of Roselia, the developer introduced Signum 95A. This is a high-street retail hub which fulfills all the daily needs of residents living in the sociey.
</p>                     
                    </div>
                 <!--   <div class="col-lg-12">
                        <div class="tablewrap padt80 wow animate__ animate__fadeInUp">
                            <div class="table-responsive-lg">
                                <table class="table table-striped table-dark">
                                    <thead>
                                        <tr class="tophd">
                                          	<td>S No.</td>
                                            <td>TYPES OF UNIT</td>                            
                                            <td>TYPE</td>
                                            <td>CARPET AREA IN Mtr.</td>
                                            <td>CARPET AREA in Sqft</td>
                                            <td>BALCONY AREA IN Mtr</td>
                                            <td>BALCONY AREA IN SQ. FT.</td>
                                            <td>Total flat cost (BSP)</td>
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                          	<td>01</td>
                                            <td>Type-A</td>
                                            <td>2BHK</td>
                                            <td>52.884</td>
                                            <td>569.243</td>
                                            <td>9.474</td>
                                            <td>101.978</td>
                                            <td>2326972</td>
                                        </tr>
                                        <tr>
                                          	<td>02</td>
                                            <td>Type-B</td>
                                            <td>2BHK</td>
                                            <td>47.777</td>
                                            <td>514.272</td>
                                            <td>7.425</td>
                                            <td>79.923</td>
                                            <td>2097050</td>
                                            
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div> -->
                   
                    
                    
                    
                </div>
            </div>
        </div>      
    </div>
    <!--Welcome Section-->
    
      <!--3D WALKTHROUGH-->
    <div class="walkthroughwrap padd100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
       <!--             <span class="captext fcolorlgt wow animate__ animate__fadeInUp">3D WALKTHROUGH</span> -->
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Sneak Peek at Roselia</h2>
                </div>
                <div class="col-lg-12">
                    <div class="walkvideoiframe wow animate__ animate__fadeInUp">
                       <iframe width="100%" height="500" src="https://www.youtube.com/embed/EaEkdt2C2x0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--3D WALKTHROUGH-->
    
    <!--Location-->
    <div class="locationwrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="locationmap wow animate__ animate__fadeInUp">
                        <a data-fancybox="unit-location" href="images/projects/sector-95a-gurugram/LocationMap/Location-Map.jpg">
                            <img src="images/projects/sector-95a-gurugram/LocationMap/Location-Map.jpg" alt="Signature global Roselia Affordable House - Location" title="Signature global Roselia Affordable House - Location"/>
                            <div class="btnclick halvar_rg">
                                <span>Click Here</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-5 location-bg">
                    <div class="locationadvantage">
                        <h2 class="headingtag clrwh mb-4 wow animate__ animate__fadeInUp">Location<br/> Advantages</h2>
                        
                        <div class="locationlistslider">
                            <div>
                                <div class="ullist wow animate__ animate__fadeInUp">
                                    <ul>
                                      <li> On State & Six-Lane highway</li>
<li>Easy and smooth connectivity from Pataudi road, Dwarka Expressway, NH8, KMP Expressway & IGI Airport</li>
<li>Adjacent to New Gurugram</li>
<li>9km from Sultanpur National Park</li>
<li>Close proximity to educational and health institutions like Sharda International School, Colonel’s Public School and Kamla Hospital</li>
<li>A paradise away from city noises, yet in close proximity of commercial sectors</li>
<li>Premium Residential Colonies & Commercial Projects in close proximity</li>
                                    </ul>
                                </div>
                            </div>
                            
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Location-->
    
    <!--Unit Plan-->
 <!--    <div class="unitsectionwrap padd100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h3 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Unit Plans</h3>
                    <div class="controlar pull-right mobslidear">
                        <span class="arrow-icon-leftpl"><img src="images/icon/right-arrow.svg"></span>
                        <span class="arrow-icon-rightpl"><img src="images/icon/right-arrow.svg"></span>
                   </div>
                </div>
                <div class="col-lg-12 wow animate__ animate__fadeInUp">
                    <div class="row unitplansliderg2">
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/projects/sector-95a-gurugram/Type-A.jpg">
                                    <img src="images/projects/sector-95a-gurugram/Type-A.jpg" alt="Signature global Roselia Affordable House - unit plan" title="Signature global Roselia Affordable House - unit plan"/></a>
                                <b>Type A</b>
                                <span>U.A : 569.243 SQ.FT | B.A : 101.978 SQ.FT</span>
                                
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/projects/sector-95a-gurugram/Type-B.jpg">
                                    <img src="images/projects/sector-95a-gurugram/Type-B.jpg" alt="Signature global Roselia Affordable House - unit plan" title="Signature global Roselia Affordable House - unit plan"/></a>
                                <b>Type B</b>
                                <span>U.A : 514.272 SQ.FT | B.A : 79.923 SQ.FT</span>
                                
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <!--Unit Plan-->
    
    <!--Site Plan-->
 <!--   <div class="siteplanwrap padb100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h4 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Site Plan</h4>
                </div>
                <div class="col-lg-12">
                    <div class="sitemapimg wow animate__ animate__fadeInUp">
                        <a data-fancybox="siteplan" href="images/projects/sector-95a-gurugram/Signum-95-A.jpg">
                            <img src="images/projects/sector-95a-gurugram/Signum-95-A.jpg" alt="Signature global Roselia Affordable House - site plan" title="Signature global Roselia Affordable House - site plan"/>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>  -->
    <!--Site Plan-->
    
    <!--Projects Gallery-->
    <div class="elevationsectionwrap padd100">
        <div class="container">
          <div class="row">
            <div class="col-lg-9">
                <span class="captext fcolorlgt wow animate__ animate__fadeInUp">ELEVATIONS</span>
                <h5 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp"> Our Array of Affordable Accommodations</h5>
            </div>
            
            <div class="col-lg-12 wow animate__ animate__fadeInUp">
                <div class="progalleryslider mt-4">
                    <div class="slider-for">                      
                        <img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/5Z8A0221.jpg" alt="Sector - a elevation BirdEye 1" title="">
                        <img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/5Z8A0223.jpg" alt="Sector - a elevation Corner" title="">
                        <img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/5Z8A0226.jpg" alt="Signum-95A-elevation" title="Signum-95A-elevation">
                        <img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/5Z8A0230.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">
                       	<img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/5Z8A0231.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">
                      	<img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/DJI_0256.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">
                      	<img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/DJI_0258.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">
                      	<img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/DJI_0259.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">
                      	<img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/DJI_0260.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">
                      	<img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/DJI_0262.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">
                    </div>
                    <div class="slider-nav"> 
                       <img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/5Z8A0221.jpg" alt="Sector - a elevation BirdEye 1" title="">
                        <img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/5Z8A0223.jpg" alt="Sector - a elevation Corner" title="">
                        <img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/5Z8A0226.jpg" alt="Signum-95A-elevation" title="Signum-95A-elevation">
                        <img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/5Z8A0230.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">
                       	<img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/5Z8A0231.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">
                      	<img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/DJI_0256.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">
                      	<img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/DJI_0258.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">
                      	<img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/DJI_0259.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">
                      	<img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/DJI_0260.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">
                      	<img class="item-slick" src="images/projects/sector-95a-gurugram/elevation/DJI_0262.jpg" alt="Tower-Profile-CMYK" title="Tower-Profile-CMYK">     
                    </div>
                </div>
            </div>
          </div>
        </div>
    </div>
    <!--Projects Gallery-->
    
    
    <!--Accordion Notification-->
    <div class="notificationwrap padb100">
        <div class="container">
            <div class="accordion" id="accordionExample">
                 
                <div class="card mb-0 wow animate__ animate__fadeInUp">
                    <div class="card-head" id="headingOne">
                        <h2 class="mb-0 collapsed show-more" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            <b>Notification Advertisement</b> <span class="halvar_rg text show-more-height"></span>
                        </h2>
                    </div>
                
                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body pb-0 mb-0">
                            <div class="notificationtable">
                                <div class="table-responsive">
                                    <table class="table mb-0">
                                        <thead>
                                            <tr>
                                                <th>Title</th>
                                                <th>Date</th>
                                                <th>English</th>
                                                <th>Hindi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          
                                          
                                           <tr>
                                                <td>Dainik Jagran(Gurugram)</td>
                                                <td>12.08.2023</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/Roselia Cancellation Ad_8x11_cm_10.08.2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr> 
                                          
                                          <tr>
                                                <td>Dainik Jagran(Gurugram)</td>
                                                <td>19.07.2023</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/Rosellia-NPA-Cancellation-Ad-8x13-cm_18.07.2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>  
                                          
                                       <!--    <tr>
                                                <td>Dainik Jagran(Gurugram)</td>
                                                <td>24.01.2023</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/Rosellia_NPA_cancellation_ad_ 13.1.2023_CTC.PDF" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr> -->
                                           <tr>
                                                <td>Dainik Jagran(Gurugram)</td>
                                                <td>23.03.2023</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/Rosellia NPA Cancellation Ad 8x12 cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>  
                                            <tr>
                                                <td>Dainik Jagran(Gurugram)</td>
                                                <td>18.11.2022</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/The-roselia-notification.PDF" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>                                        
                                            
                                           
                      
                                                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                
                </div>
        </div>
    </div>
    <!--Accordion Notification-->

    
    
    <!--Accordion Notification-->
 <!--   <div class="notificationwrap padb100">
        <div class="container">
            <div class="accordion" id="accordionExample">
                
                <!--construction update start-->
                
           <!--       <div class="card wow animate__ animate__fadeInUp">
                    <div class="card-head" id="headingTwo">
                        <h6 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseConstruction" aria-expanded="true" aria-controls="collapseConstruction">
                             <b>Construction Update</b> <span class="halvar_rg">View More</span>
                        </h6>
                    </div>
                 <div id="collapseConstruction" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="notificationtable">
                                <div class="row">
                                   
                                    <div class="col-md-4">
                                        <div class="bon_vivant construction-img" >
                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=pPdcM5-0105" target="_blank">
                                                <img src="images/projects/sector-95a-gurugram/construction/The-Roselia.jpg" alt="Signature global Roselia Affordable House - Construction building " title="Signature global Roselia Affordable House - Construction building">
                                            </a>
                                            <b>Project Update</b>
   <span>1st March 2022</span>
                                         
                                    </div>
                                </div>
                              
                                <div class="col-md-4">
  
                                </div>
                                
                                
                                <div class="col-md-4">
  
                                </div>
                                
                                
                                
                                </div>
                                
                            </div>
                        </div>
                    </div>


                </div> -->
                
                
                
                <!--construction update end-->

                
                
                
         
                <!--       <div class="card wow animate__ animate__fadeInUp">
                    <div class="card-head" id="headingOne">
                        <h6 class="mb-0 collapsed show-more" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            <b>Notification Advertisement</b> <span class="halvar_rg text show-more-height"></span>
                        </h6>
                    </div>
                
                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="notificationtable">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Title</th>
                                                <th>Date</th>
                                                <th>English</th>
                                                <th>Hindi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Dainik Jagran, Gurugram (Cancellation Ad Hindi)</td>
                                                <td>27.10.2021</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/95A%20The%20Rosellia%20Can%20Ad%208x14%20cms_%20Table_CTC.PDF" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Jagran, Gurugram (Cancellation Ad Hindi)</td>
                                                <td>24.07.2021</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/Roselia%20Cancellation%20Ad%208x10cm%2023.07.2021.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                             <tr>
                                                <td>Dainik Jagran, Gurugram (Cancellation Ad Hindi)</td>
                                                <td>09.04.2021</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/Roselia%20Cancellation%20Ad%208x9%20cm%2008.04.2021.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            
                                            </tr>
                                             <tr>
                                                <td>Dainik Jagran, Gurugram (Cancellation Ad )</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roselia_cancellation%20ad_8x9_cm_09.12.2020.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Jagran, Gurugram</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia-2/roselia_cancellation%20ad_8x9_cm_05.03.2020.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar, Gurugram</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roselia_cancellation%20ad_8x9_cm_05.03.2020.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar and Dainik Jagran (Gurugram)</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roselia_cancellation%20ad_8x8_cm_30.10.2019%20copy.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar and Dainik Jagran (Gurugram)</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/The%20Roselia_Cancellation%20Ad_8x9_cm%20Edit%2001.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                           
                                            <tr>
                                                <td>Dainik Bhaskar and Dainik Jagran (Gurugram)</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roselia_cancellation%20ad_8x9_cm_28.08.2019.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar and Dainik Jagran, Gurugram </td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roselia_cancellation%20ad_8x9_cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar and Dainik Jagran, Gurugram</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/Roselia%20Draw%20Result%20Ad_21.06.2019%20(1).pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar and Dainik Jagran (Gurugram)</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roselia_draw_ads_hindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Mail Today (D-NCR)</td>
                                                <td>-</td>
                                                
                                                <td><a href="pdf/roselia/roselia_draw_ads_english.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            
                                            <tr>
                                                <td>Dainik Bhaskar and Dainik Jagran (Gurugram) </td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roselia-hindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                             <tr>
                                                <td>Mail Today</td>
                                                <td>-</td>
                                                
                                                <td><a href="pdf/roselia/roselia-english.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar (Gurugram) </td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/Roselia%20Draw%20Result%20Ad%2012x16.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar (Gurugram) </td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roselia%208x11.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Jansatta (DNCR) and Dainik Bhaskar (Gurugram)</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roseliasec95ahindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Indian Express, Financial Express </td>
                                                <td>-</td>
                                                
                                                <td><a href="pdf/roselia/roseliasec95aeng.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Indian Express, Financial Express</td>
                                                <td>-</td>
                                                
                                                <td><a href="pdf/roselia/roselia%20Corigendum%20Ad%208x8%20english.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Jansatta and Dainik Jagran</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roselia%20Corigendum%20Ad%208x8%20hindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar, Danik Jagran</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/RoseliaDrawResultAd-10cmX12cm-30-01-19Hindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Mail Today </td>
                                                <td>-</td>
                                                
                                                <td><a href="pdf/roselia/RoseliaDrawResultAd-10cmX12cm-30-01-19English.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar,Dainik Jagran</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roselia%20hindi%208x10%20ad.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Mail Today </td>
                                                <td>-</td>
                                                
                                                <td><a href="pdf/roselia/roselia%20english%208x10%20ad.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Financial Express and Indain Express</td>
                                                <td>05-01-2019</td>
                                                
                                                <td><a href="pdf/roselia/roseliaenglish16x25.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Jansatta (D-NCR), Dainik Bhaskar (Gurugram)</td>
                                                <td>05-01-2019</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roseliahindi16x25.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Mail Today Delhi NCR</td>
                                                <td>24-10-2018</td>
                                                
                                                <td><a href="pdf/roselia/roseliaAdenglish2491X2012.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar</td>
                                                <td>24-10-2018</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roseliaAdhindi16x2512.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Dainik Jagran</td>
                                                <td>24-10-2018</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roseliaAdhindi16x2512.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Roselia Draw Result Ad</td>
                                                <td>24-10-2018</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roseliadrawresultAd_16cmx12cm-18-10-18_1.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar</td>
                                                <td>17-10-2018</td>
                                                
                                                <td><a href="pdf/roselia/roseliaAdenglish24.91X20.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Jagran</td>
                                                <td>17-10-2018</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roseliaAdhindi16x25.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Roselia Draw Ad English</td>
                                                <td>-</td>
                                                
                                                <td><a href="pdf/roselia/roseliadrawad_english_8cmx10cm-09-10-18.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Roselia Draw Ad Hindi</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roseliadrawad_hindi_8cmx10cm-09-10-18.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar Cancellation Ad</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/roseliacancellationdainikbhaskar.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Indian Express (Delhi NCR) , Financial Express (Delhi NCR)</td>
                                                <td>26-09-2018</td>
                                                
                                                <td><a href="pdf/roselia/corrigendumenglish.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Jansatta (D-NCR), Dainik Bhaskar (Gurugram)</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/corigendumhindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                 
                                            </tr>
                                            <tr>
                                                <td>Draw Result Ad Dainik Bhaskar, Gurugram Edition (Hindi)</td>
                                                <td>26-09-2018</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-Draw%20Result-Ad-25-07-18-Hindi-Dainik-Bhaskar.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                              <tr>
                                                <td>The Roselia (Hindi)</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-Draw-Ad-12thjuly-hin.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            
                                              <tr>
                                                <td>The Roselia (English)</td>
                                                <td>-</td>
                                                
                                                <td><a href="pdf/roselia/Roselia-Draw-Ad-12thjuly-eng.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Roselia week 2 Ad India Express (English)</td>
                                                <td>-</td>
                                                
                                                <td><a href="pdf/roselia/Roselia-Week-2-%20Ad%20Indian%20Express-26-06-18.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Roselia week 2 Ad Dainik Bhaskar (Hindi)</td>
                                                <td>-</td>
                                                <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-Week-2-%20Ad-Dainik%20Bhaskar-26-06-18.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Re-lunch Ad English</td>
                                                <td>-</td>
                                               
                                                <td><a href="pdf/roselia/Roselia-Re-launch-Ad-English-26.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Re-lunch Ad Hindi</td>
                                                <td>-</td>
                                               <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-Re-launch-Ad-Hindi-26.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 
                                            </tr>
                                            <tr>
                                                <td>Draw Result Ad Dainik Bhaskar, Gurugram Edition</td>
                                                <td>-</td>
                                               <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-Draw-ResultAd24-05-18.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar and Dainik Jagran Hindi</td>
                                                <td>-</td>
                                               <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-Draw-Ad%20_%20Hindi_%208cm-x-10cm-17-05-18.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                    
                                            </tr>
                                            <tr>
                                                <td>Mail Today (Delhi NCR) English</td>
                                                <td>-</td>
                                              
                                                <td><a href="pdf/roselia/Roselia-Draw-Ad%20_%20English_%208cm-x-10cm-17-05-18.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                  <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Jagran Gurugram Edition Cancellation Ad</td>
                                                <td>-</td>
                                              <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-Cancellation-Ad.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                  
                                            </tr>
                                            <tr>
                                                <td>Roselia Draw Result Ad Hindi</td>
                                                <td>-</td>
                                              <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-Draw-ResultAd_%208cm%20x%2012cm-28-03-18.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                  
                                            </tr>
                                            
                                            <tr>
                                                <td>Mail Today-Delhi NCR (English)Ad</td>
                                                <td>-</td>
                                              
                                                <td><a href="pdf/roselia/Roselia-english20-march.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 <td>-</td> 
                                            </tr>
                                            <tr>
                                                <td>Dainik Jagran City and Dainik Bhaskar Gurugram Edition (Hindi)Ad</td>
                                                <td>-</td>
                                              <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-hindi-20-march.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                  
                                            </tr>
                                            <tr>
                                                <td>Dainik Jagran Gurugram Edition (Hindi) Ad</td>
                                                <td>-</td>
                                              <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-Re-launch-Ad-Hindi1.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                  
                                            </tr>
                                            <tr>
                                                <td>Mail Today Delhi NCR English Ad</td>
                                                <td>-</td>
                                              
                                                <td><a href="pdf/roselia/Roselia-Re-launch%20Ad-English-new.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 <td>-</td> 
                                            </tr>
                                            <tr>
                                                <td>Jacket Ad Dainik Bhaskar and Dainik Jagran</td>
                                                <td>-</td>
                                              <td>-</td> 
                                                <td><a href="pdf/roselia/Roselia-Serenas-Re-Launch-Full-Page-Hindi-33cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 
                                            </tr>
    <tr>
                                                <td>Roselia Draw Result Ad Hindi</td>
                                                <td>-</td>
                                               <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-Draw-Ad8.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 
                                            </tr>
                                            <tr>
                                                <td>Roselia Draw Result Ad English Indian Express, Jansatta, F.Express, Dainik Jagran</td>
                                                <td>-</td>
                                               
                                                <td><a href="pdf/roselia/Roselia-Draw-Ad3.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Roselia Draw Result Ad Hindi Indian Express, Jansatta, F.Express, Dainik Jagran</td>
                                                <td>-</td>
                                               <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-DrawAdHindi..pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar and Dainik Jagran Hindi Ad</td>
                                                <td>-</td>
                                               <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-Ad-Hindi-Dainik-Bhaskar-Dainik-Jagran.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 
                                            </tr>
                                            <tr>
                                                <td>Mail Today English Ad</td>
                                                <td>-</td>
                                               
                                                <td><a href="pdf/roselia/Roselia-Ad%20_%20English-Mail-Today.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Jagran Corrigendum Hindi Ad</td>
                                                <td>-</td>
                                               <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-Ad-Hindi-Dainik-Bhaskar-Dainik-Jagran.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 
                                            </tr>
                                            <tr>
                                                <td>Dainik Bhaskar Corrigendum Hindi Ad</td>
                                                <td>-</td>
                                               <td>-</td>
                                                <td><a href="pdf/roselia/Corrigendum-ad-DB.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 
                                            </tr>
                                            <tr>
                                                <td>Daink Bhaskar and Dainik  Bhaskar Hindi Ad</td>
                                                <td>-</td>
                                               <td>-</td>
                                                <td><a href="pdf/roselia/Roselia-Quarter-page-Ad-Hindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                 
                                            </tr>
                                            <!--<tr>-->
                                            <!--    <td>Daink Bhaskar and Dainik  Bhaskar Hindi Ad</td>-->
                                            <!--    <td>-</td>-->
                                            <!--   <td>-</td>-->
                                            <!--    <td><a href="pdf/roselia/Roselia-Quarter-page-Ad-Hindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>-->
                                                 
                                            <!--</tr>-->
     
                                            <!--<tr>
                                                <td>Roselia Mail Today Legal Ad</td>
                                                <td>-</td>
                                               
                                                <td><a href="pdf/roselia/roselia-half-page.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td> 
                                            </tr>
                                            <tr>
                                                <td>GrandIva Launch English Front Ad</td>
                                                <td>-</td>
                                               
                                                <td><a href="pdf/roselia/GrandIva-Launch-Front.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                               <td>-</td>  
                                            </tr>
                                            <tr>
                                                <td>GrandIva Launch English Back Ad</td>
                                                <td>-</td>
                                               
                                                <td><a href="pdf/roselia/GrandIva-Launch-back.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                               <td>-</td>  
                                            </tr>
                                            <tr>
                                                <td>Cancellation Ad</td>
                                                <td>-</td>
                                               <td>-</td>  
                                                <td><a href="pdf/roselia/roselia-cancellation-ad-8X16cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                               
                                            </tr>
                                            <tr>
                                                <td>Ads, Indian Express, Jagran City, Jansatta, Financial Express</td>
                                                <td>11-09-2017</td>
                                               
                                                <td><a href="pdf/roselia/Roselia-Print-Ad_16%20x%2025cm%20_08-09-2017.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                               <td>-</td>  
                                            </tr>
                                            <tr>
                                                <td>Ad Jagran Gurgaon Times</td>
                                                <td>04-09-2017</td>
                                               
                                                <td><a href="pdf/roselia/jacket%20advt%20on%20monday%20-%20jagran%20-%20Pdf_2.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                               <td>-</td>  
                                            </tr>
                                             <tr>
                                                <td>Ad Jagran and TOI</td>
                                                <td>04-09-2017</td>
                                               
                                                <td><a href="pdf/roselia/roselia-print.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                               <td>-</td>  
                                            </tr>
                                            <tr>
                                                <td>The Roselia Legal Ads</td>
                                                <td>-</td>
                                               
                                                <td><a href="pdf/roselia/Roselia%20Print%20Ad%20_%2016%20x%2025cm%20_02-09-2017.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                               <td>-</td>  
                                            </tr>
                                            <tr>
                                                <td>Ad For NavBharat Times, Dainik Jagran</td>
                                                <td>-</td>
                                               <td>-</td> 
                                                <td><a href="pdf/roselia/NBT-DJ_SMCAd_16cmx25cm_07-07-2017-min.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Ad For Mail Today</td>
                                                <td>-</td>
                                               
                                                <td><a href="pdf/roselia/SMCAd-Mail-Today_24.9cmX20cm_07-07-2017.pdf.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td> 
                                            </tr>
                                            <tr>
                                                <td>Ad For NavBharat Times, Dainik Jagran</td>
                                                <td>-</td>
                                               <td>-</td> 
                                                <td><a href="pdf/roselia/NBT-DJ_SMCAd_16cmx25cm_01-07-2017-min.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Ad For Mail Today</td>
                                                <td>-</td>
                                               
                                                <td><a href="pdf/roselia/SMCAd-Mail-Today_24.9cmX20cm_01-07-2017.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td> 
                                            </tr>
                                            <tr>
                                                <td>Draw Result Ad Hindi NavBharat Times</td>
                                                <td>-</td>
                                               <td>-</td> 
                                                <td><a href="pdf/roselia/Roselia-Draw-ResultAd_16-x25cms-20-06-17-Hindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            
                                            <tr>
                                                <td>Draw Result Ad English NavBharat Times</td>
                                                <td>-</td>
                                               
                                                <td><a href="pdf/roselia/Roselia-Draw-ResultAd_16-x-25cms-20-06-17English.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td> 
                                            </tr>
                                            <tr>
                                                <td>HH Ad</td>
                                                <td>13-02-2017</td>
                                               <td>-</td> 
                                                <td><a href="pdf/roselia/HH-Ad-%2032_4cm-x-45cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>Hindi Ad</td>
                                                <td>13-06-2017</td>
                                               <td>-</td> 
                                                <td><a href="pdf/roselia/Roselia%20Draw%20Ad%20_%20%208cm%20x%2010cm%20-13-06-17%20Hindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>English Ad</td>
                                                <td>13-06-2017</td>
                                               
                                                <td><a href="pdf/roselia/Roselia%20Draw%20Ad%20_%20%208cm%20x%2010cm%20-13-06-17%20English%20(1).pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td> 
                                            </tr>
                                            <tr>
                                                <td>HH Ad</td>
                                                <td>13-02-2017</td>
                                               <td>-</td> 
                                                <td><a href="pdf/roselia/HH-Ad-%2032_4cm-x-45cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>HH Ad</td>
                                                <td>13-02-2017</td>
                                               <td>-</td> 
                                                <td><a href="pdf/roselia/HH-Ad-32-4cm-x-52cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>TOI Ad</td>
                                                <td>13-02-2017</td>
                                               <td>-</td> 
                                                <td><a href="pdf/roselia/TOI%20_%20SMC%20Ad%20_%2032.8cm%20x%2047.4cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>TOI Ad</td>
                                                <td>13-02-2017</td>
                                                
                                                <td><a href="pdf/roselia/TOI%20_%20SMC%20Ad%20_%2032.8cm%20x%2047.4cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>NBT Ad</td>
                                                <td>13-02-2017</td>
                                               <td>-</td> 
                                                <td><a href="pdf/roselia/NBT%20_%20Roselia%20Ad%20_%2016cm%20x%2025cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>NBT Ad</td>
                                                <td>13-01-2017</td>
                                               <td>-</td> 
                                                <td><a href="pdf/roselia/HH-Ad-%2032_4cm-x-45cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                
                                            </tr>
                                            <tr>
                                                <td>TOI Ad</td>
                                                <td>13-01-2017</td>
                                               
                                                <td><a href="pdf/roselia/toi-ad.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td> 
                                            </tr>
                                            <tr>
                                                <td>HH Live Ad</td>
                                                <td>20-01-2017</td>
                                               
                                                <td><a href="pdf/roselia/smc-nation-corporate.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td> 
                                            </tr>
                                            <tr>
                                                <td>HH Live Ad</td>
                                                <td>20-01-2017</td>
                                               
                                                <td><a href="pdf/roselia/SMC-Nation-Corporate-Ad-HH-Live_Inside-32cm-X-52cm_19-01-2017%20.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td> 
                                            </tr>
                                            <tr>
                                                <td>Mail Today Ad</td>
                                                <td>20-01-2017</td>
                                               
                                                <td><a href="pdf/roselia/SMC%20Nation%20Corporate%20Ad%20Mail%20Today%20Inside_24cm%20X%2039cm_19-01-2017.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td> 
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>-->
                
                
   
    <!--Accordion Notification-->
    
    <!--rera no-->
    <div class="footerpagetop">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        
                        <span>Forever Buildtech Pvt. Ltd. CIN - U70109DL2012PTC241744, 12TH FLOOR, DR. GOPAL DAS BHAWAN 28 BARAKHAMBA ROAD NEW DELHI Central Delhi DL 110001</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--rera no-->

	<div class="footerpagetop">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        <strong>Disclaimer</strong>
                      	<p>Promoter urges every applicant to inspect the project site and shall not merely rely upon any architectural impression, plan or sales brochure and, therefore, requests to make personal judgment prior to submitting an application for allotment. Unless otherwise stated, all the images, visuals, materials and information contained herein are purely creative/artistic and may not be actual representations of the product and/or any amenities. Further, the actual design may vary in the fit and finished form, from the one displayed above. Journey time shown, if any, is based upon Google Maps which may vary as per the traffic at a relevant point of time.. *Rate mentioned above does not include GST and other statutory charges, if applicable. T & C Apply. 1 sq. mt. = 10.7639 sq. ft.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
   

<!--Footer-->
    <footer class="footerbg padd100">
       <div class="width100">
            <div class="container">
                <div class="row paddb60">
                   <div class="col-12">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt m-0 wow animate__ animate__fadeInUp">
                                    <strong>SIGNATURE GLOBAL</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/residential/" title="Residentential projects by Signature Global">Residential</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/" title="Commercial projects by Signature Global">Commercial</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/">Retail</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class=" footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>OUR PRESENCE</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/commercial/society-shops/gurugram/" title="Signature Global in Gurugram">Gurugram</a></li>
                                        <li><a href="https://www.signatureglobal.in/residential/plots/karnal" title="Signature Global in Karnal">Karnal</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/ghaziabad" title="Signature Global in Ghaziabad">Ghaziabad</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>ABOUT US</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" title="Signature Global - Chairman's message" class="scdown">Chairman’s Message</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" title="Signature Global - Board of Director" class="scdown">Board of Directors</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" title="Signature Global - Key Managerial Positions" class="scdown">Key Managerial Positions</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" title="Our Architect" class="scdown">Our Architects</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" title="Signature Global - Vission & Mission of Signature Global" class="scdown">Vision & Mission</a></li>
                                    <!--    <li><a href="signature-global-foundation.php" title="Signature Global Foundation">Signature Global Foundation</a></li>-->
                                    </ul>
                                </div>
                           </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>CAREERS</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/career.php#as-associate" title="Careers at Signature Global">As Associate</a></li>
                                        <li><a href="https://www.signatureglobal.in/career.php#life-signature" title="Life At Signature Global">Life @ Signature Global </a></li>
                                        <li><a href="#"></a></li>
                                    </ul>
                                </div>
                              
                                <div class="footernav halvar_lt wow animate__ animate__fadeInUp publicnoticehome">
                                  <ul>
                                    <li><a href="https://www.signatureglobal.in/public-notice.php" title="Signature Global Public Notice"><strong>Public Notice</strong></a></li>
                                  </ul>                                  
                             	</div>
                                          
                           </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong style="margin-bottom: 15px;">GALLERY</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/gallery.php" title="Signature Global Gallery">Picture Library</a></li>
                                        <li><a href="https://www.signatureglobal.in/video-gallery.php" title="Signature Global Video Gallery">Video Library</a></li>
                                    </ul>
                                </div>   
                            </div>
                           <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/media.php" title="Signature Global Blogs">MEDIA</a></strong> 
                                    <ul>
                                     <li><a href="https://www.signatureglobal.in/media-coverage.php" title="Signature Global Gallery">Media Coverage</a></li>
                                        <!--<li><a href="https://www.signatureglobal.in/press-release.php" title="Signature Global Video Gallery">Press Release</a></li> -->
                                         <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Gallery">Press Kit</a></li>
                                        <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Video Gallery">Media Contact</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                   <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/blog" title="Signature Global Blogs">Blog</a></strong>
                                <!--    <strong class="mb-2"><a class="clrwh opctext" href="https://online.anyflip.com/dhkmm/nalj/mobile/index.html" target="_blank" title="Signature Global Newsletter ">NEWSLETTER</a></strong> -->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/home-loans.php" title="Signature Global - Home Loans">Home Loans</a></strong>
                                  <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/pay-online.php" title="Signature Global - APPLY ONLINE">PAY ONLINE</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/award.php" title="Signature Global Certificates">AWARD</a></strong>                                  
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                 <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" target="_blank" title="Signature Global Login">MBDA/BDA Login</a></strong>
                                   <!-- <strong class="mb-2"><a class="clrwh opctext" href="http://signatureglobal04.realboost.in/add_appointment.aspx" target="_blank" title="Signature Global Appointments">Appointment</a></strong>-->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/terms-of-appointment.php" title="Signature Global - Terms of appointment">Terms of Appointment</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/green-development.php" title="Signature Global - Green Development">Green Development</a></strong>
                                </div>     
                            </div>
                        </div>
                        
                   </div>
                </div>
            </div>
        </div>
      
        
        <div class="width100 bordertop padt60 wow animate__ animate__fadeInUp">
            <div class="container">
                <div class="row">    
                    <div class="col-lg-3">
                       <div class="footerlogo wow animate__ animate__fadeInUp">
                           <img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/>
                       </div> 
                    </div>
                    <div class="col-lg-4">
                        <div class="footernav pl-65 wow animate__ animate__fadeInUp">
                            <strong>REGISTERED OFFICE</strong>
                            <p>13<sup>th</sup> Floor, Dr. Gopal Das Bhawan, 28<br class="ftmb"/> Barakhamba Road, Connaught Place,<br class="ftmb"/> New Delhi 110 001, India.</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Registered Office: +91 11 4928 1700</a>
                        </div>
                    </div>
                    <div class="col-lg-3 pl-00">
                        <div class="footernav wow animate__ animate__fadeInUp">
                            <strong>CORPORATE OFFICE</strong>
                            <p>Unit No.101, Ground Floor, Tower-A,<br class="ftmb"/>Signature Tower South City-1, Gurugram,<br class="ftmb"/>Haryana 122 001, India</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Corporate Office: +91 124 4398 011</a>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="footermedianav mtopft wow animate__ animate__fadeInUp">
                            <strong>FOLLOW US</strong>
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </footer>
     <!--policytab-->
     <div class="policywraper">
         <div class="container">
             <div class="row">
                 <div class="col-lg-10 col-md-10">
                     <div class="policylink text-left">
                        <p>© 2023 Signature Global. All Rights Reserved <br class="mobhidebr"/><span class="clrwh mobhide">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/advertising-policy-for-channel-partners.php"  >Advertising Policy For Channel Partners</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/privacy-policy.php" title="Signature Global - Privacy Policy">Privacy Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/social-media-policy.php" title="Signature Global - Social Media Policy">Social Media Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/generic-faqs-for-haryana-affordable-housing-policy.php">Generic Faq's</a>                        
                       </p>
                       
                     </div>
                  
                 </div>
             <!--     <div class="col-lg-2 col-md-2 cclogo ">
                     <img src="https://www.signatureglobal.in/images/cogdigital.svg" alt="" width="15">
                   </div> -->
             </div>
         </div>
     </div>
   
    <script>
         $.urlParam = function (name) {
            var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);
            return (results !== null) ? results[1] || 0 : false;
            }
            
            var utmSource = $.urlParam('utm_source') ? $.urlParam('utm_source') : 'direct';
            var utmMedium = $.urlParam('utm_medium') ? $.urlParam('utm_medium') : '';
            var utmCampaign = $.urlParam('utm_campaign') ? $.urlParam('utm_campaign') : '';
            var utmId = $.urlParam('utm_id') ? $.urlParam('utm_id') : '';
             
            var enq_url = new URL("https://enquiry.signatureglobal.in/?projectName=ContactUs&enquiryFrom=Online");
            $(function() {
                    enq_url.searchParams.set('utm_source',utmSource);
                    if(utmMedium!=""){enq_url.searchParams.set('utm_medium',utmMedium);}
                    if(utmCampaign!=""){enq_url.searchParams.set('utm_campaign',utmCampaign);}
                    if(utmId!=""){enq_url.searchParams.set('utm_id',utmId);}
                    
              if($('#main_frame').length > 0)
                    $('#main_frame').attr('src', enq_url)
            
            });

    </script>


<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/animate.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/jquery.fancybox.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/slick.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>


<script src="https://www.signatureglobal.in/js/wow.min.js"></script>
<script src="https://www.signatureglobal.in/js/slick.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.fancybox.min.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.validate.min.js"></script>
<script src="https://www.signatureglobal.in/js/additional-methods.js"></script>
<script src="https://www.signatureglobal.in/js/custom.js"></script> 
<script src="https://www.signatureglobal.in/js/app.js"></script> 
<!-- Start of  Zendesk Widget script -->
<script>
   setTimeout(function(){
      var chatScript = '<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"/>';
      $('body').append(chatScript);
   },  
 5000);
</script>

<script>
  window.addEventListener('load', function() {
    jQuery('body').on('mousedown', '[href*="tel:"]', function() {
      gtag('event', 'phone_call')
    })
    jQuery('body').on('mousedown', '[href*="api.whatsapp.com"]', function() {
      gtag('event', 'whatsapp_click')
    })
    jQuery('body').on('mousedown', '.btnrt:contains(Enquire Now)', function() {
      gtag('event', 'enquire_now')
    })
    jQuery('body').on('mousedown', '.contact100-form-btn:contains(Submit)', function() {
      gtag('event', 'Submit_btn')
    })
  });

</script>
<!--<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"> </script>-->
<!-- End of  Zendesk Widget script -->





 


</body>
</html>
 <script>
        $.urlParam = function (name) {
           var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);
        return (results !== null) ? results[1] || 0 : false;
        }
        
        var utmSource = $.urlParam('utm_source') ? $.urlParam('utm_source') : 'direct';
        var utmMedium = $.urlParam('utm_medium') ? $.urlParam('utm_medium') : '';
        var utmCampaign = $.urlParam('utm_campaign') ? $.urlParam('utm_campaign') : '';
        var utmId = $.urlParam('utm_id') ? $.urlParam('utm_id') : '';
         
        var url = new URL("https://enquiry.signatureglobal.in?projectName=Roselia&enquiryFrom=Online");
        $(function() {
                url.searchParams.set('utm_source',utmSource);
                if(utmMedium!=""){url.searchParams.set('utm_medium',utmMedium);}
                if(utmCampaign!=""){url.searchParams.set('utm_campaign',utmCampaign);}
                if(utmId!=""){url.searchParams.set('utm_id',utmId);}
                $('#abc_frame').attr('src', url)
        
        });
    </script>