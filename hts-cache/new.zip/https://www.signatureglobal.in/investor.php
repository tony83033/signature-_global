<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="facebook-domain-verification" content="zqv18clg4hyd5synd83cbrczwv588t" />
<title> Investor Zone - Signature Global</title>
<meta name=description content="Get Signature Global’s annual reports, corporate announcements and IPO details. " />
<meta name=keywords content="" />
<link rel="canonical" href="https://www.signatureglobal.in/investor.php" />
<meta name="robots" content="noodp" />
 

    
  
  
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5S8ZC8X');</script>
<!-- End Google Tag Manager -->
  
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-90138100-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-90138100-1');
</script>
  
  

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-MRPZNF8ZD2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-MRPZNF8ZD2');
</script>
  
<!-- Global site tag (gtag.js) - Google Ads: 962082073 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-962082073"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config','AW-962082073', {'allow_enhanced_conversions':true});
</script>
<script>
  gtag('config', 'AW-962082073/BUgQCILmzakDEJnq4MoD', {
    'phone_conversion_number': '7053-121-121'
  });
</script>
  
  

  
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '359225061117882');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=359225061117882&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<link href=https://www.signatureglobal.in/images/favicon1.png rel="shortcut icon" type=image/x-icon>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/bootstrap.min.css"/>
<link  rel="stylesheet"  href="https://www.signatureglobal.in/css/fontawesome/css/all.min.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/style.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/responsive.css"/>
<script src="https://www.signatureglobal.in/js/jquery.min.js"></script>
<script  src="https://www.signatureglobal.in/js/bootstrap.min.js"></script>
<style>
  .shhhow{display:block !important; opacity:1 !important;}
  }
</style>

</head>
<body>
  <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5S8ZC8X"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

        
    <header class="header-area">
        <div class="overlayhd"></div>
        <nav class="navbar navbar-expand-md navbar-dark">
            <div class="container">
                <a href="https://www.signatureglobal.in/" class="navbar-brand"><img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/></a> 
                <div class="mobiconbtn">
                    <a href="tel:+91-7053121121">
                        <svg id="Layer_4" data-name="Layer 4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><circle class="cls-1 cls2" cx="75" cy="75" r="73.55"/><path d="M54.68,41.25,50,41a5.64,5.64,0,0,0-4,1.36c-2.25,2-5.86,5.76-7,10.69-1.66,7.37.9,16.39,7.51,25.4S65.5,101.9,87.29,108.06c7,2,12.55.65,16.81-2.08a15,15,0,0,0,6.54-9.54l.75-3.47a2.43,2.43,0,0,0-1.35-2.7L94.3,83a2.41,2.41,0,0,0-2.92.71l-6.18,8a1.78,1.78,0,0,1-2,.6C79,90.85,64.81,84.91,57,69.93a1.77,1.77,0,0,1,.23-2l5.9-6.83a2.41,2.41,0,0,0,.39-2.53L56.77,42.71A2.42,2.42,0,0,0,54.68,41.25Z"/></svg>
                    </a>
                    <a id="forother" href="https://api.whatsapp.com/send?phone=%2B917303918365&text=Hii%2C+I+am+interested+in+Signature%20Global+Affordable+Housing">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>
                  	<a id="forwhatsapp" href="https://api.whatsapp.com/send?phone=919311144622&amp;text=">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>	
                  
                </div>
                <button type="button" class="navbar-toggler collapsed" data-target="#main-nav">
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                </button>                
                <div id="main-nav" class="navbar-collapse">
                    <div class="topnavbaxy">
                        <ul class="navbar-nav width100 dlfx">                         
                         <!--   <li><a href="career.php" class="nav-link" title="Signature Global - Carrer">Career </a></li> -->
                            <li class="dropdown loginpage">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">LOGIN <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://signatureglobal2.my.salesforce-sites.com/sg?cpForm=true" class="assreg" target="_blank">Associate Registration</a></li>
                                     <li><a href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" class="assreg" target="_blank">MBDA/BDA Login</a></li>
                                     <li><a href="https://app.hrone.cloud/login" class="assreg assreg1" target="_blank">Employee Login</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                        <!--    <li><a href="pay-online.php" class="nav-link" title="Signature Global  - Pay Online">APPLY ONLINE</a></li>-->
                            <li><a href="https://www.signatureglobal.in/investor.php" class="nav-link" title="Signature Global  - Investor">Investor</a></li> 
                            <li><a href="https://www.signatureglobal.in/customer_support.php" class="nav-link" title="Signature Global  - Custome Support">Customer Support </a></li>                         
                   <!--      <li><a href="pdf/SG_Mobile_App_User_Manual.pdf" class="nav-link" target="_blank">Mobile app User Manual</a></li>-->
                         <li><a href="https://www.signatureglobal.in/signature-global-foundation.php" class="nav-link" target="_blank">Signature Global Foundation</a></li>                        
                        </ul>
                    </div>                     
                    <ul class="navbar-nav width100 dlfx ">
                   <!--     <li class="nav-item">
                          <a href="about-us.php" class="nav-link" title="Signature Global  - About Us">About US </a>
                          
                      </li>-->
                      
                       <li class="nav-item dropdown loginpage position-relative">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">About US <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#companyjourney" class="assreg scdown"> Company's Journey</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" class="assreg scdown" >Chairman's Message</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" class="assreg scdown" >Board of Directors</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" class="assreg scdown">Key Managerial Positions</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" class="assreg scdown" >Our Architects</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" class="assreg scdown">Vision & Mission</a></li>
                                     <li><a href="https://www.signatureglobal.in/career.php#life-signature" class="assreg" target="_blank"> Life @ Signature Global</a></li>
                                     <li><a href="https://www.signatureglobal.in/green-development.php" class="assreg assreg1" target="_blank">Green Development</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                      
                        <li class="nav-item dropdown">
                            <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">RESIDENTIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                            <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-5">
                                                <strong>Residential</strong>
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/residential/affordable/">Affordable Group Housing</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/premium/">Premium Independent Floors</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/plots/">Residential Plots</a></li>
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div> 
                                            </div>
                                            <div class="col-lg-8 col-md-7">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5 col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Residential</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/residential/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_6" data-name="Layer 6"><g id="Layer_1-6" data-name="Layer 6"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Resdential-nvbg.jpg" alt="Residential Projects by Signature Global
" title="Residential Projects by Signature Global
">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item dropdown">
                          <a href="#" title="Commercial projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">COMMERCIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                          <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-6 ">
                                                <strong>Commercial</strong>
                                    
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/commercial/society-shops/">Society Shops</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/malls/">Mall</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/sco-plots/">SCO</a></li> 
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-lg-8 col-md-6 ">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5  col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Commercial</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/commercial/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_7" data-name="Layer 7"><g id="Layer_1-7" data-name="Layer 7"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Commercial-nvbg.jpg" alt="Commercial Projects by Signature Global" title="Commercial Projects by Signature Global">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item"><a title="Signature Global  - Contact Us" href="https://www.signatureglobal.in/contact.php" class="nav-link">CONTACT US </a></li>
                    </ul>
                    <div class="bottommediamobwrap">
                        <ul class="pplink">
                            <li><a href="https://www.signatureglobal.in/privacy-policy.php">Privacy Policy</a></li>
                          <li><span>|</span></li>
                            <li><a href="https://www.signatureglobal.in/social-media-policy.php">Social Media Policy</a></li>
                        </ul>
                        <div class="footermedianav mtopft">
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <div class="overlaymobbg"></div>    
<style>
  .investors-sec .accordion .card h6 b{
    letter-spacing: 1px;
  }
  .table td a img{
    width: 25px;
  }
  .financial .list-year select {
    width: 75px;
  }
  
  .mterial-subsidiaries .list-year select {
    width: 75px;
  }
  
  .list-year select{
    width:75px;
    background:#203d3b;
    border: 0;
    color:#fff
   
  }
  
  .notificationtable .list-table tr td{width:90%}
  .cle .col-md-3{
    
    -ms-flex: 0 0 20%;
    flex: 0 0 20%;
    max-width: 20%
  }
  .conlefttext{text-align: center;
   text-align: center;
    background: #b9b9b970;
    padding: 20px;
    width: 100%;
    margin-top: 50px;
  }

  .conlefttext strong{margin-bottom: 10px;color: #000;}
  .conlefttext p{color: #000;opacity: 1;}
  .conlefttext p a {
    color: #000;
}
    .accordion .card h6.invertorcol{
    background-position: 99% 5px;
    }
    .card-head .mb-0:after{
        top:0px;
    }
  .accordion .innercard h6 span{
    top: 70%;
  }
  .innercard .card-head .mb-0:after{
    right: -2px;
  }
  #collapseCom2 .accordioninner .card strong{
    background-position: 95% 15px;
  }
  .celldes{
   border-left: 1px solid #dee2e6;border-right: 1px solid #dee2e6; 
  }
 
  @media (max-width: 991px){
    .accordion .card h6 span{
      top: 78%;
    }
  }
  @media(max-width: 767px){
    .accordion .card h6.invertorcol {
    background-position: 97% 5px;
}
    .accordion .card h6 span {
    top: 95%;
}
    .accordion .card h6 b {
 
    font-size: 16px;
}
    .card-head .mb-0:after{
       font-size: 16px;
      width: 108px;
    }
    .accordion .cardbighead h6 span{
       /*top: 49%;*/
      top: 95%;
    }
   .innercard .card-head .invertorcol:after {
   
    width: 119px;
}
    .accordion .card.subinnercard h6 span{
      top: 95% !important;
    }
    
    
  }
  b{
    font-weight: 600;
  }
</style>
     <!--banner section-->
    <div class="banner career-banner padd100">
        <div class="overlay"></div>
        
        <div class="container">
            <div class="row">          
               <div class="col-lg-12">
                    <div class="bannertext wow animate__ animate__fadeInUp" >
                        <div>
                        <h1 class="cr-title">Investor</h1>
                        </div>
                    </div>
               </div>
                
            </div>
        </div>
    </div>
    <!--banner-->
    
    

    <div class="notificationwrap investors-sec padb100 pd-t0">
        <div class="container">
            <div class="accordion" id="accordionExample">
              
              <div class="card">
                    <div class="card-head " id="headingOne">
                        <h6 class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapsezero" aria-expanded="false" aria-controls="collapseOne">
                            <b>INDUSTRY REPORT</b> <span class="halvar_rg"></span>
                        </h6>
                    </div>
                
                    <div id="collapsezero" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="notificationtable investor-table">
                                
                            <table class="table border-bottom mb-5" border="0">
                              
                                <tr>
                                  <td>ANAROCK PROPERTY CONSULTANTS PRIVATE LIMITED</td>
                              	<td><a href="pdf/Anarock-report-Signature-Global-Final-Industry-Report-R6.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>  <td></td>
                              </tr>
                               
                            </table>
                            
                            
                           
                            </div>
                             
                             
                        </div>
                    </div>
                </div>
              
              
                <div class="card">
                    <div class="card-head " id="headingOne">
                        <h6 class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            <b>FACT SHEET</b> <span class="halvar_rg"></span>
                        </h6>
                    </div>
                
                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="notificationtable investor-table">
                               
                            
                            <h5 class="mt-4">BOARD OF DIRECTORS</h5>
                            <table class="table border-bottom" border="0">
                                <tr class="table-dark">
                                    <th>NAME</th>
                                    <th>DESIGNATION</th>
                                </tr>
                                
                                <tr>
                                    <td>Mr. Pradeep Kumar Aggarwal</td>
                                    <td>Chairman & Executive Director</td>
                                </tr>
                                
                                <tr>
                                    <td>Mr. Lalit Kumar Aggarwal</td>
                                    <td>Vice Chairman & Executive Director</td>
                                </tr>
                                 <tr>
                                    <td>Mr. Devender Aggarwal</td>
                                    <td>Joint Managing Director</td>
                                </tr>
                                 <tr>
                                    <td>Mr. Ravi Aggarwal</td>
                                    <td>Managing Director</td>
                                </tr>
                                
                                
                                
                                <tr>
                                    <td>Mr. Chandra Wadhwa</td>
                                    <td>Independent Director </td>
                                </tr>
                                
                                 <tr>
                                    <td>Mr. K.M. Agarwal</td>
                                    <td>Independent Director</td>
                                </tr>
                               <tr>
                                    <td>Ms. Lata Pillai</td>
                                    <td>Independent Director</td>
                                </tr>
                              <tr>
                                    <td>Mr. Venkatesan Narayanan</td>
                                    <td>Independent Director</td>
                                </tr>
                            </table>
                             
                              <!--kmps-->
                              <h5 class="mt-4">KEY MANAGERIAL POSITIONS</h5>
                            <table class="table border-bottom" border="0">
                                <tr class="table-dark">
                                    <th>NAME</th>
                                    <th>DESIGNATION</th>
                                </tr>
                                
                                <tr>
                                    <td>Mr. Rajat Kathuria</td>
                                    <td>Chief Executive Officer</td>
                                </tr>
                                
                                <tr>
                                    <td>Mr. Sanjay Kumar Varshney</td>
                                    <td>Chief Operating Officer</td>
                                </tr>
                               <tr>
                                    <td>Mr. Manish Garg</td>
                                    <td>Chief Financial Officer</td>
                                </tr>
                                <tr>
                                    <td>Mr. M R Bothra</td>
                                    <td>Company Secretary</td>
                                </tr>
                               
                            </table>
                              
                              
                            </div>
                             
                             <div class="color-box">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="chairman-dis">
                                        <h5>REGISTERED OFFICE</h5>
                                        <p>13<sup>th</sup> Floor, Dr. Gopal Das Bhawan, 28<br> Barakhamba Road, Connaught Place,<br>New Delhi 110 001, India..</p>
                            <p><a  href="tel:011 4928 1700">Telephone Registered Office : +91 11 4928 1700</a></p>
                                    </div>
                                </div>
                                
                                <div class="col-md-6   border-lft">
                                    <div class="chairman-dis">
                                        <h5>CORPORATE OFFICE</h5>
                                          <p>Unit No.101, Ground Floor, Tower-A, <br> Signature Tower South City-1, Gurugram, <br>Haryana 122 001, India.</p>
                                          <p><a  href="tel:124 4398 011">Telephone Corporate Office: +91 124 4398 011</a></p>
                                    </div>
                                </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              
                <div class="card">
                    <div class="card-head " id="headingpublic">
                        <h6 class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapsepublic" aria-expanded="false" aria-controls="collapsepublic">
                            <b>INITIAL PUBLIC OFFER</b> <span class="halvar_rg"></span>
                        </h6>
                    </div>
                
                    <div id="collapsepublic" class="collapse" aria-labelledby="headingpublic" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="notificationtable investor-table">
                                
                            <table class="table border-bottom mb-5" border="0">
                              <tr>
                                  <td>Basis of allotment advertisement – September 27, 2023</td>
                              	<td><a href="pdf/SGlobal_BOA AD_R_9_web.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>  <td></td>
                              </tr>
                               <tr>
                                  <td>Prospectus – September 23, 2023</td>
                              	<td><a href="pdf/Prospectus–September-23-2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>  <td></td>
                              </tr>
                              
                                <tr>
                                  <td>Red Herring Prospectus</td>
                              	<td><a href="pdf/Red-Herring-Prospectus.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>  <td></td>
                              </tr>
                               
                            </table>
                            
                            
                           
                            </div>
                             
                             
                        </div>
                    </div>
                </div>
              
              
               <!--disclosure-->
              
              <div class="card">
                    <div class="card-head " id="headingDISCLOSURES">
                        <h6 class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapseDISCLOSURES" aria-expanded="false" aria-controls="collapseDISCLOSURES">
                            <b>DISCLOSURES UNDER REGULATION 46 OF THE LODR</b> <span class="halvar_rg"></span>
                        </h6>
                    </div>
                
                    <div id="collapseDISCLOSURES" class="collapse" aria-labelledby="headingDISCLOSURES" data-parent="#accordionExample">
                        <div class="card-body">
                            <table class="table companydetails" border="0">
                                <tr>
                                    <th><a href="https://www.signatureglobal.in/about-us.php" target="_blank">DETAILS OF COMPANY’S BUSINESS</a></th>
                                </tr>
                                <tr>
                                   <th class="appSp">
                                       <a href="https://www.signatureglobal.in/pdf/appointment/Terms-and-Conditions-of-Appointment-of-Independent-Directors.pdf" target="_blank">TERMS AND CONDITIONS OF APPOINTMENT OF INDEPENDENT DIRECTORS <img src="images/icon/pdf.svg" alt="Pdf"></a></th>
                                </tr>
                              
                              <tr>
                                   <th class="appSp">
                                       <a href="pdf/investors/BOARD-OF-DIRECTORS-AND-COMMITTEES.PDF" target="_blank">BOARD OF DIRECTORS AND COMMITTEES <img src="images/icon/pdf.svg" alt="Pdf"></a></th>
                                </tr>
                                
                            </table>
                            <!--2nd-->
         
                            <!--2nd-->
                           
                           <div class="accordion accordian_main" id="accordionExample56">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom56">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom56" aria-expanded="false" aria-controls="collapseCom56">
                                             <b class="subheading">CODE OF CONDUCT & POLICIES</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom56" class="collapse" aria-labelledby="headingCom56" data-parent="#accordionExample56">
                                    <div class="card-body">
                                            
                          <div class="notificationtable investor-table">                              
                           
                            <table class="table border-bottom mb-5" border="0">
                                 
                                <tr>
                                    <td>1. Policy on Materiality of Related Party Transaction</td>
                                    <td style="width:10%"><a href="pdf/investors/Related-Party-Transactions.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                  
                                </tr>
                                
                                <tr>
                                    <td>2. Whistle Blower Policy/Vigil Mechanism</td>
                                    <td style="width:10%"><a href="pdf/investors/Whistle-Blower-Policy.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                 
                                </tr>
                                
                                 <tr>
                                    <td>3. Familiarisation Programme for Independent Directors</td>
                                    <td style="width:10%"><a href="pdf/investors/Familiarisation-programme-for-IDs.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                  
                                </tr>
                                
                                 <tr>
                                    <td>4. Code of Conduct and Business Ethics</td>
                                    <td style="width:10%"><a href="pdf/investors/Code-of-conduct.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                   
                                </tr>
                                
                                <tr>
                                    <td>5. Archival Policy</td>
                                    <td style="width:10%"><a href="pdf/investors/Archival-Policy.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                  
                                </tr>
                                
                                 <tr>
                                    <td>6. Policy for Determination of Materiality of Events/Information</td>
                                    <td style="width:10%"><a href="pdf/investors/Policy-for-determination-of-material-events.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                 
                                </tr>
                               <tr>
                                    <td>7. Policy for Determining Material Subsidiaries</td>
                                    <td style="width:10%"><a href="pdf/investors/Policy-of-material-subsidiaries.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                  
                                </tr>
                              <tr>
                                    <td>8. CSR Policy</td>
                                    <td style="width:10%"><a href="javascript:void(0)" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                  
                                </tr>
                              <tr>
                                    <td>9. Nomination and Remuneration Policy</td>
                                    <td style="width:10%"><a href="javascript:void(0)" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                  
                                </tr>
                              <tr>
                                    <td>10. Code of practices and procedures for fair disclosure of UPSI</td>
                                    <td style="width:10%"><a href="pdf/investors/10. Code of practices and procedures for fair disclosure of UPSI.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                  
                                </tr>
                            </table>
                            </div> 
                              
                               
                                    </div>
                                </div>
                                </div>
                            </div>
                          
                            <!--3-->
                    <!--        <div class="accordion accordian_main" id="accordionExample5">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom5">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom5" aria-expanded="false" aria-controls="collapseCom5">
                                             <b class="subheading">DETAILS OF FAMILIARIZATION PROGRAMMES IMPARTED TO INDEPENDENT DIRECTORS</b> 
                                            
                                        </h6>
                                    </div>
                                <div id="collapseCom51" class="collapse" aria-labelledby="headingCom5" data-parent="#accordionExample2">
                                    <div class="card-body">
                                        
                                    </div>
                                </div>
                                </div>
                            </div> -->
                           <table class="table companydetails" border="0">                              
                                <tr>
                                   <th>
                                       <a href="pdf/investors/DETAILS-OF-FAMILIARIZATION-PROGRAMMES-IMPARTED-TO-INDEPENDENT-DIRECTORS.PDF" target="_blank">DETAILS OF FAMILIARIZATION PROGRAMMES IMPARTED TO INDEPENDENT DIRECTORS<img src="images/icon/pdf.svg" alt="Pdf"></a></th>
                                </tr>                         
                                
                            </table>
                            <!--4-->
                            <div class="accordion accordian_main" id="accordionExample6">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom6">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom6" aria-expanded="false" aria-controls="collapseCom6">
                                             <b class="subheading">CONTACT INFORMATION OF INVESTOR GRIEVANCES REDRESSAL TEAM INCLUDING E-MAIL ADDRESS</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom6" class="collapse" aria-labelledby="headingCom6" data-parent="#accordionExample6">
                                   <div class="card-body pl-3 pr-3">
                                  <table class="table annualreport" border="0">
                                <tr>
                                      <td>CONTACT INFORMATION OF INVESTOR GRIEVANCES REDRESSAL TEAM INCLUDING E-MAIL ADDRESS</td>
                                    <td style="width:10%"><a href="pdf/investors/CONTACT-INFORMATION-OF-INVESTOR-GRIEVANCES-REDRESSAL-TEAM-INCLUDING-EMAIL-ADDRESS.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                </tr>
                              
                            
                                
                            </table>
                                   </div>
                                  <!--  <div class="card-body pl-3 pr-3">
                                        <p><strong>Name: </strong> Mr. M R Bothra</p>
                                        <p><strong>Designation: </strong> Company Secretary and Compliance Officer</p>
                                        <p><strong>Address: </strong> Unit No.101, Ground Floor, Tower-A, Signature Tower South City-1, Gurugram, Haryana 122 001, India</p>
                                        <p><strong>Tel: </strong> +91 124 4398 011</p>
                                        <p><strong>E-mail: </strong> investors@signatureglobal.in</p>
                                    </div> -->
                                </div>
                                </div>
                            </div>
                            <!--5-->
                            <div class="accordion accordian_main" id="accordionExample7">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom7">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom7" aria-expanded="false" aria-controls="collapseCom7">
                                             <b class="subheading">EMAIL ADDRESS FOR GRIEVANCE REDRESSAL AND OTHER RELEVANT DETAILS</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom7" class="collapse" aria-labelledby="headingCom7" data-parent="#accordionExample7">
                                    <div class="card-body pl-3 pr-3">
                                       <table class="table annualreport" border="0">
                                <tr>
                                      <td>EMAIL ADDRESS FOR GRIEVANCE REDRESSAL AND OTHER RELEVANT DETAILS</td>
                                    <td style="width:10%"><a href="pdf/investors/EMAIL-ADDRESS-FOR-GRIEVANCE-REDRESSAL-AND-OTHER-RELEVANT-DETAILS.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                </tr>
                              
                            
                                
                            </table>
                                    <!--    <p><strong>E-mail: </strong>investors@signatureglobal.in </p> -->
                                    </div>
                                </div>
                                </div>
                            </div>

                            <!--6-->
                            <div class="accordion accordian_main" id="accordionExample71">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom71">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom71" aria-expanded="false" aria-controls="collapseCom71">
                                             <b class="subheading">CONTACT DETAILS OF KEY MANAGERIAL PERSONNEL WHO ARE AUTHORIZED FOR THE PURPOSE OF DETERMINING <br> MATERIALITY OF AN EVENT OR INFORMATION</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom71" class="collapse" aria-labelledby="headingCom71" data-parent="#accordionExample71">
                                    <div class="card-body pl-3 pr-3">
                                      <table class="table annualreport" border="0">
                                <tr>
                                      <td>CONTACT DETAILS OF KEY MANAGERIAL PERSONNEL WHO ARE AUTHORIZED FOR THE PURPOSE OF DETERMINING</td>
                                    <td style="width:10%"><a href="pdf/investors/CONTACT-DETAILS-OF-KMP-WHO-ARE-AUTHORIZED-FOR-THE-PURPOSE-OF-DETERMINING.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                </tr>
                              
                            
                                
                            </table>
                                      <!--  <ol>
                                            <li>a. Managing Director</li>
                                            <li class="mt-1">b. Company Secretary</li>
                                            <li class="mt-1">c. Chief Financial Officer</li>
                                        </ol>
                                        <p class="mt-3"><strong>Address: </strong>Unit No.101, Ground Floor, Tower-A, Signature Tower South City-1, Gurugram, Haryana 122 001, India </p>
                                        <p><strong>Tel: </strong>+91 124 4398 011</p>
                                        <p><strong>E-mail: </strong>cs@signatureglobal.in </p> -->
                                        
                                    </div>
                                </div>
                                </div>
                            </div>
                            <!--7-->
                             <div class="accordion accordian_main" id="accordionExample72">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom72">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom72" aria-expanded="false" aria-controls="collapseCom72">
                                             <b class="subheading">BOARD MEETING INTIMATIONS</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom72" class="collapse" aria-labelledby="headingCom72" data-parent="#accordionExample72">
                                    <div class="card-body pl-3 pr-3">
                                        <table class="table annualreport" border="0">
                                            <tr>
                                  
                                    <td>Notice of Board Meeting – October 11, 2023</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/Notice of Board Meeting- 11.10.2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 
                                        </table>
                                        
                                    </div>
                                </div>
                                </div>
                            </div>
                            <!--8-->
                              <div class="accordion accordian_main" id="accordionExample721">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom721">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom721" aria-expanded="false" aria-controls="collapseCom721">
                                             <b class="subheading">FINANCIAL RESULTS</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom721" class="collapse" aria-labelledby="headingCom721" data-parent="#accordionExample721">
                                    <div class="card-body pl-3 pr-3">
                                        <table class="table annualreport" border="0">
                                            <tr>                                  
                                                <td>Financial Results for the Quarter ended June 30, 2023</td>
                                                <td style="width: 13%; text-align: center"><a href="pdf/investors/Financial-Results-June-30-2023.pdf" target="_blank">														<img src="images/icon/pdf.svg" alt="Pdf"></a></td>                                    
                               				 </tr>
                                        </table>
                                        
                                    </div>
                                </div>
                                </div>
                            </div>
                            <!--9-->
                            <div class="accordion accordian_main" id="accordionExample7211">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom7211">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom7211" aria-expanded="false" aria-controls="collapseCom7211">
                                             <b class="subheading">ANNUAL REPORT</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom7211" class="collapse" aria-labelledby="headingCom7211" data-parent="#accordionExample7211">
                                    <div class="card-body pl-3 pr-3">
                                        <table class="table annualreport" border="0">
                                            <tr>
                                  
                                    <td>Annual Report FY 2022-23</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/20.1 Annual Report FY 2022-23.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 <tr>
                                  
                                    <td>Annual Report FY 2021-22</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/20.2 Annual Report FY 2021-22-new.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 <tr>
                                
                                    <td>Annual Report FY 2020-21</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/20.3 Annual Report FY 2020-21.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                        </table>
                                        
                                    </div>
                                </div>
                                </div>
                            </div>

                            <!--10-->
                          
                        <div class="accordion accordian_main" id="accordionExample09">
    <div class="card innercard">
        <div class="card-head card-head1" id="headingCom09">
            <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom09" aria-expanded="false" aria-controls="collapseCom09">
                <b class="subheading">SHAREHOLDING PATTERN</b>
                <!--<span class="halvar_rg"></span>-->
            </h6>
        </div>
        <div id="collapseCom09" class="collapse" aria-labelledby="headingCom09" data-parent="#accordionExample09">
            <div class="card-body pl-3 pr-3">
                <!-- Sub drop down -->
                <div class="accordion accordian_main" id="shareholderpattern">
                    <div class="card innercard">
                        <div class="card-head card-head1" id="shareholderpattern1">
                            <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#shareholderpatternCollapse" aria-expanded="false" aria-controls="shareholderpatternCollapse">
                                <b class="subheading">Quarterly Shareholding Pattern</b>
                                <span class="yeardata">2023-24</span>
                            </h6>
                        </div>
                        <div id="shareholderpatternCollapse" class="collapse" aria-labelledby="shareholderpattern1" data-parent="#shareholderpattern">
                            <div class="card-body pl-3 pr-3">
                                <table class="table annualreport annualreport1" border="0">
                                    <tr>
                                        <td>Q1</td>
                                        <td>Q2</td>
                                        <td>Q3</td>
                                        <td>Q4</td>
                                    </tr>
                                    <tr>
                                        <td>NA</td>
                                        <td><a href="pdf/investors/SHP-for-website.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                        <td>NA</td>
                                        <td>NA</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End of sub drop down -->
            </div>
        </div>
    </div>
</div>


                          <!--11-->
                            
                            <div class="accordion accordian_main" id="accordionExample7212">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom7212">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom7212" aria-expanded="false" aria-controls="collapseCom7212">
                                             <b class="subheading">INVESTOR MEET/ PRESENTATION</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom7210" class="collapse" aria-labelledby="headingCom7212" data-parent="#accordionExample7212">
                                    <div class="card-body pl-3 pr-3">
                                        
                                        
                                    </div>
                                </div>
                                </div>
                            </div>

                            
                            <!--11-->
                           
                            <!--12-->
                             <div class="accordion accordian_main" id="accordionExample72121">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom72121">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom72121" aria-expanded="false" aria-controls="collapseCom72121">
                                             <b class="subheading">NEWSPAPER ADVERTISEMENTS</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom72121" class="collapse" aria-labelledby="headingCom72121" data-parent="#accordionExample72121">
                                    <div class="card-body pl-3 pr-3">
                                         <table class="table annualreport" border="0">
                                              <tr>                                  
                                                <td>Financial Results for the Quarter ended June 30, 2023 </td>
                                                <td style="width: 13%; text-align: center"><a href="pdf/investors/Financial-Results-for-the-Quarter-ended-June-30-2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>                                    
                               				 </tr>
                                           
                                        </table>
                                        
                                        
                                    </div>
                                </div>
                                </div>
                            </div>
                            <!--13-->
                            <div class="accordion accordian_main" id="accordionExample721212">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom721212">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom721212" aria-expanded="false" aria-controls="collapseCom721212">
                                             <b class="subheading">CREDIT RATINGS</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom7210" class="collapse" aria-labelledby="headingCom721212" data-parent="#accordionExample721212">
                                    <div class="card-body pl-3 pr-3">
                                        
                                        
                                    </div>
                                </div>
                                </div>
                            </div>
                          <!---->
                           <div class="accordion accordian_main" id="accordionExampleSUBSIDIARIES">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingComSUBSIDIARIES">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseComSUBSIDIARIES" aria-expanded="false" aria-controls="collapseComSUBSIDIARIES">
                                             <b class="subheading">SUBSIDIARIES FINANCIALS</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseComSUBSIDIARIES" class="collapse" aria-labelledby="headingComSUBSIDIARIES" data-parent="#accordionExampleSUBSIDIARIES">
                                    <div class="card-body pl-3 pr-3">
                                        
                                        No Data
                                    </div>
                                </div>
                                </div>
                            </div>
                            <!--14-->
                            <div class="accordion accordian_main" id="accordionExample7212121">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom7212121">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom7212121" aria-expanded="false" aria-controls="collapseCom7212121">
                                             <b class="subheading">SECRETARIAL COMPLIANCE REPORT</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom7210" class="collapse" aria-labelledby="headingCom7212121" data-parent="#accordionExample7212121">
                                    <div class="card-body pl-3 pr-3">
                                        
                                        
                                    </div>
                                </div>
                                </div>
                            </div>

                            <!--15-->
                          
                            <!--16-->
                            <div class="accordion accordian_main" id="accordionExample_sep27">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom_sep27">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom_sep27" aria-expanded="false" aria-controls="collapseCom_sep27">
                                             <b class="subheading">DISCLOSURES UNDER REGULATION 30</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom_sep27" class="collapse" aria-labelledby="headingCom_sep27" data-parent="#accordionExample_sep27">
                                    <div class="card-body pl-3 pr-3">
                                         <table class="table annualreport" border="0">
                                           <tr>                                  
                                                <td>Intimation about Acquisition of Land – October 23, 2023 </td>
                                                <td style="width: 13%; text-align: center"><a href="pdf/investors/Regu30.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>                                    
                               				 </tr>
                                              <tr>                                  
                                                <td>Press Release UFR Q1 - 24 </td>
                                                <td style="width: 13%; text-align: center"><a href="pdf/investors/pressuploading.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>                                    
                               				 </tr>
                                           <tr>                                  
                                                <td>Outcome of Board Meeting (Financial Results) – October 11, 2023</td>
                                                <td style="width: 13%; text-align: center"><a href="pdf/investors/Outcome-of-Board-Meeting-(Financial-Results)-October-11-2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>                                    
                               				 </tr>
                                           <tr>                                  
                                                <td>Key Operational Updates For H1FY24 & Q2FY24</td>
                                                <td style="width: 13%; text-align: center"><a href="pdf/investors/Key-Operational-Updates-For-H1FY24-&-Q2FY24.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>                                    
                               				 </tr>
                                           <tr>                                  
                                                <td>Key Operational Updates For Q1FY24</td>
                                                <td style="width: 13%; text-align: center"><a href="pdf/investors/Key-Operational-Updates-For-Q1FY24.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>                                    
                               				 </tr>
                                            <tr>                                  
                                                <td>Financial Performance For Q1FY24</td>
                                                <td style="width: 13%; text-align: center"><a href="pdf/investors/Financial-Performance-For-Q1FY24.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>                                    
                               				 </tr>
                                           <tr>                                  
                                                <td>Trading Window Closure – September 27, 2023</td>
                                                <td style="width: 13%; text-align: center"><a href="pdf/investors/Trading-Window-Closure–September-27- 2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>                                    
                               				 </tr>
                                        </table>
                                        
                                    </div>
                                </div>
                                </div>
                            </div>

                            <!--17-->
                             <div class="accordion accordian_main" id="accordionExample73">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom73">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom73" aria-expanded="false" aria-controls="collapseCom73">
                                             <b class="subheading">STATEMENTS OF DEVIATIONS OR VARIATIONS</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom730" class="collapse" aria-labelledby="headingCom73" data-parent="#accordionExample73">
                                    <div class="card-body pl-3 pr-3">
                                        
                                        
                                    </div>
                                </div>
                                </div>
                            </div>
                            <!--18-->
                            <div class="accordion accordian_main" id="accordionExample731">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom731">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom731" aria-expanded="false" aria-controls="collapseCom731">
                                             <b class="subheading">ANNUAL RETURNS</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom731" class="collapse" aria-labelledby="headingCom731" data-parent="#accordionExample731">
                                    <div class="card-body pl-3 pr-3">
                                        <table class="table annualreport" border="0">
                                            <tr>
                                  
                                    <td>Annual Returns FY 2021-22</td>
                                    <td style="width: 13%; text-align: center"><a href="pdf/investors/Annual-Return-2021-22.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 <tr>
                                 
                                    <td>Annual Returns FY 2020-21</td>
                                    <td style="width: 13%; text-align: center"><a href="pdf/investors/Annual-Return-2020-21.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 <tr>
                                 
                                    <td>Annual Returns FY 2019-20</td>
                                    <td style="width: 13%; text-align: center"><a href="pdf/investors/Annual-Return-2019-20.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                        </table>
                             
                                        
                                    </div>
                                </div>
                                </div>
                            </div>
                            <!--19-->
                        <div class="accordion accordian_main" id="accordionExample73101">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom73101">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom73101" aria-expanded="false" aria-controls="collapseCom73101">
                                             <b class="subheading">PRESS RELEASE</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom73101" class="collapse" aria-labelledby="headingCom73101" data-parent="#accordionExample73101">
                                    <div class="card-body pl-3 pr-3">
                                         <table class="table annualreport" border="0">
                                              <tr>                                  
                                                <td>Press Release UFR Q1 - 24 </td>
                                                <td style="width: 13%; text-align: center"><a href="pdf/investors/pressuploading.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>                                    
                               				 </tr>
                                           
                                        </table>
                                        
                                    </div>
                                </div>
                                </div>
                            </div>
                            
                            <!--20-->
                           
                            <!--21-->
                             <div class="accordion accordian_main" id="accordionExample73121">
                                <div class="card innercard">
                                    <div class="card-head card-head1" id="headingCom73121">
                                        <h6 class="mb-0 collapsed compositionHd" data-toggle="collapse" data-target="#collapseCom73121" aria-expanded="false" aria-controls="collapseCom73121">
                                             <b class="subheading">COMPANY DETAILS</b> 
                                             <!--<span class="halvar_rg"></span>-->
                                        </h6>
                                    </div>
                                <div id="collapseCom73121" class="collapse" aria-labelledby="headingCom73121" data-parent="#accordionExample73121">
                                    <div class="card-body pl-3 pr-3">
                                        
                                      
                                      
                                       <table class="table annualreport" border="0">
                                            <tr>                                  
                                                <td>Listed at:</td>
                                                <td class="celldes">National Stock Exchange of India Limited (NSE)</td>       
                                              	<td class="celldes">BSE Limited (BSE)</td>
                               				 </tr>
                                         <tr>                                  
                                                <td>Stock Code:</td>
                                                <td class="celldes">Trading symbol at NSE - SIGNATURE</td>       
                                              	<td class="celldes">Trading scrip code at BSE - 543990</td>
                               				 </tr>
                                          <tr>                                  
                                                <td>ISIN:</td>
                                                <td colspan="2" class="celldes">INE903U01023</td>                                                     
                               				 </tr>
                                          <tr>                                  
                                                <td>CIN:</td>
                                                <td colspan="2" class="celldes">U70100DL2000PLC104787</td>   
                               				 </tr>
                                        </table>
                                      
                                    </div>
                                </div>
                                </div>
                            </div>
                            <!--22-->
                               <table class="table companydetails" border="0">
                               
                                <tr>
                                   <th>
                                       <a href="https://www.signatureglobal.in/pdf/investor/Memorandum%20and%20Articles%20of%20Association%20with%20Incorporation%20Certificates.pdf" target="_blank">MEMORANDUM AND ARTICLES OF ASSOCIATION <img src="images/icon/pdf.svg" alt="Pdf"></a></th>
                                </tr>
                                
                            </table>                        
                            <!--23-->
                        </div>
                    </div>
                </div>
              <!--disclosure-->
              
                
        <div class="card">
                    <div class="card-head" id="headingTwo">
                        <h6 class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            <b>FINANCIALS</b> <span class="halvar_rg"></span>
                        </h6>
                    </div>
                
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                        <div class="card-body pb-0">
                           
                            
                            <div class="notificationtable quterly-table financial">
                           <table class="table border-bottom" border="0">
                                <tr class="table-dark">
                                    <th>FINANCIALS</th>
                                    <th><span class="pull-right list-year">
                                      <select onchange="change_year('financial')" id="financial_value">
                                        <option value="4">2022-23</option>
                                        <option value="3">2021-22</option>
                                        <option value="2">2020-21</option>
                                        <option value="1">2019-20</option>
                                      </select>
                                      </span></th>
                                </tr>
                                
                             
                             
                             
                            </table> 
                             
                             <table class="table border-bottom list-table" border="0" id="financial_tab">
                               
                               
                              
                            </table> 
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                
              
                <div class="card">
                    <div class="card-head" id="headingThirty">
                        <h6 class="mb-0 collapsed invertorcol text-uppercase" data-toggle="collapse" data-target="#collapseThirty" aria-expanded="false" aria-controls="collapseThirty">
                            <b>Financial for Group Companies</b> <span class="halvar_rg"></span>
                        </h6>
                    </div>
                
                    <div id="collapseThirty" class="collapse" aria-labelledby="headingThirty" data-parent="#accordionExample">
                        <div class="card-body pb-0">
                               <div class="notificationtable investor-table">
                                <h5 class="mt-0">SOUTHERN GURUGRAM FARMS PRIVATE LIMITED</h5>   
                                 <p>
                                   (CIN U70100DL1994PTC062938)

                                 </p>
                            
                           <p>
                             INFORMATION BASED ON AUDITED STANDALONE FINANCIAL STATEMENT FOR THE PRECEEDING THREE YEARS <br>
                             (Rs. in million except per share data)

                                 </p>
                            <table class="table border-bottom mb-5" border="0">
                                 <tr class="table-dark">
                                  <th></th>
                                    <th>Financial Year 2023</th>
                                    <th>Financial Year 2022</th>
                                  <th>Financial Year 2021</th>
                                </tr>
                                <tr>
                                    <td>Equity Capital</td>
                                    <td>32.90</td>
                                  <td>32.90</td>
                                  <td>32.90</td>
                                </tr>
                                
                                <tr>
                                    <td>Reserves (Excluding Revaluation Reserve)</td>
                                    <td>94.66 </td>
                                  <td>98.28</td>
                                  <td>101.74</td>
                                </tr>
                                
                                 <tr>
                                    <td>Sales</td>
                                    <td>0.49</td>
                                   <td>14.17</td>
                                   <td>85.29</td>
                                </tr>
                                
                                 <tr>
                                    <td>Profit/(Loss) after Tax</td>
                                    <td>(3.62)</td>
                                   <td>(3.47)</td>
                                   <td>1.28</td>
                                </tr>
                                
                                <tr>
                                    <td>Earnings per Share (Basic) (Face Value of Rs.10)</td>
                                    <td>(1.10)</td>
                                  <td>(1.05)</td>
                                  <td>0.39</td>
                                </tr>
                                
                                 <tr>
                                    <td>Earnings per Share (Diluted) (Face Value of Rs.10)</td>
                                    <td>(1.10)</td>
                                  <td>(1.05)</td>
                                  <td>0.39</td>
                                </tr>
                               <tr>
                                    <td>Net Asset Value per share</td>
                                    <td>38.77</td>
                                  <td>39.87</td>
                                  <td>40.92</td>
                                </tr>
                            </table>
                            </div>   
                           <div class="notificationtable investor-table">
                                <h5 class="mt-0">SKYFULL MAINTENANCE SERVICES PRIVATE LIMITED</h5>   
                             <p>
                               (CIN U93090HR2018PTC073615))

                             </p>
                            <p>
                              INFORMATION BASED ON AUDITED STANDALONE FINANCIAL STATEMENT FOR THE PRECEEDING THREE YEARS  <br>
                               (Rs. in million except per share data)
                             </p>
                           
                            <table class="table border-bottom mb-5" border="0">
                                 <tr class="table-dark">
                                  <th></th>
                                    <th>Financial Year 2023</th>
                                    <th>Financial Year 2022</th>
                                  <th>Financial Year 2021</th>
                                </tr>
                                <tr>
                                    <td>Equity Capital</td>
                                    <td> 0.50</td>
                                  <td>0.50</td>
                                  <td>0.50</td>
                                </tr>
                                
                                <tr>
                                    <td>Reserves (Excluding Revaluation Reserve)</td>
                                    <td>8.60</td>
                                  <td>1.42 </td>
                                  <td>(0.58)</td>
                                </tr>
                                
                                 <tr>
                                    <td>Sales</td>
                                    <td>233.57</td>
                                   <td>121.46</td>
                                   <td>62.39</td>
                                </tr>
                                
                                 <tr>
                                    <td>Profit/(Loss) after Tax</td>
                                    <td>7.19</td>
                                   <td>2.00</td>
                                   <td>0.83</td>
                                </tr>
                                
                                <tr>
                                    <td>Earnings per Share (Basic) (Face Value of Rs.10)</td>
                                    <td>143.71</td>
                                  <td>39.93 </td>
                                  <td>16.66</td>
                                </tr>
                                
                                 <tr>
                                    <td>Earnings per Share (Diluted) (Face Value of Rs.10)</td>
                                    <td>143.71</td>
                                  <td>39.93</td>
                                  <td>16.66</td>
                                </tr>
                               <tr>
                                    <td>Net Asset Value per share</td>
                                    <td>182.02</td>
                                  <td>38.30</td>
                                  <td>(1.63)</td>
                                </tr>
                            </table>
                            </div>          
                          <div class="notificationtable investor-table">
                                <h5 class="mt-0">PULIN INVESTMENTS PRIVATE LIMITED</h5>       
                            <p>
                              (CIN U74899DL1995PTC074891)
                            </p>
                            <p>
                              INFORMATION BASED ON AUDITED STANDALONE FINANCIAL STATEMENT FOR THE PRECEEDING THREE YEARS <br>
                              (Rs. in million except per share data)

                             </p>
                           
                            <table class="table border-bottom mb-5" border="0">
                                 <tr class="table-dark">
                                  <th></th>
                                    <th>Financial Year 2022</th>
                                    <th>Financial Year 2021</th>
                                  <th>Financial Year 2020</th>
                                </tr>
                                <tr>
                                    <td>Equity Capital</td>
                                    <td> 4.57</td>
                                  <td>4.57</td>
                                  <td>4.57</td>
                                </tr>
                                
                                <tr>
                                    <td>Reserves (Excluding Revaluation Reserve)</td>
                                    <td>37.42</td>
                                  <td>(43.67)</td>
                                  <td>28.0</td>
                                </tr>
                                
                                 <tr>
                                    <td>Sales</td>
                                    <td>149.71</td>
                                   <td>25.68</td>
                                   <td>4.23</td>
                                </tr>
                                
                                 <tr>
                                    <td>Profit/(Loss) after Tax</td>
                                    <td>81.09</td>
                                   <td>(71.67)</td>
                                   <td>(24.35)</td>
                                </tr>
                                
                                <tr>
                                    <td>Earnings per Share (Basic) (Face Value of Rs.10)</td>
                                    <td>177.25</td>
                                  <td>(156.67)</td>
                                  <td>(57.65)</td>
                                </tr>
                                
                                 <tr>
                                    <td>Earnings per Share (Diluted) (Face Value of Rs.10)</td>
                                    <td>177.25</td>
                                  <td>(156.67)</td>
                                  <td>(57.65)</td>
                                </tr>
                               <tr>
                                    <td>Net Asset Value per share</td>
                                    <td>91.80</td>
                                  <td>(85.45)</td>
                                  <td>71.21</td>
                                </tr>
                            </table>
                            </div>  
                  <!--        <div class="notificationtable investor-table">
                                <h5 class="mt-0">SIGNATUREGLOBAL MARKETING SOLUTIONS PRIVATE LIMITED</h5> 
                            <p>
                              (CIN U70200DL2017PTC325398)
                            </p>
                            <p>
                              INFORMATION BASED ON AUDITED STANDALONE FINANCIAL STATEMENT FOR THE PRECEDING THREE YEARS <br>
                              (Rs. in million except per share data)

                             </p>
                           
                            <table class="table border-bottom mb-5" border="0">
                                 <tr class="table-dark">
                                  <th></th>
                                    <th>Financial Year 2022</th>
                                    <th>Financial Year 2021</th>
                                  <th>Financial Year 2020</th>
                                </tr>
                                <tr>
                                    <td>Equity Capital</td>
                                    <td>0.10</td>
                                  <td>0.10</td>
                                  <td>0.10</td>
                                </tr>
                                
                                <tr>
                                    <td>Reserves (Excluding Revaluation Reserve)</td>
                                    <td>0.96</td>
                                  <td>0.63</td>
                                  <td>(0.18)</td>
                                </tr>
                                
                                 <tr>
                                    <td>Sales</td>
                                    <td>7.90</td>
                                   <td>24.95</td>
                                   <td>23.21</td>
                                </tr>
                                
                                 <tr>
                                    <td>Profit/(Loss) after Tax</td>
                                    <td>0.32</td>
                                   <td>0.81</td>
                                   <td>0.37</td>
                                </tr>
                                
                                <tr>
                                    <td>Earnings per Share (Basic) (Face Value of Rs.10)</td>
                                    <td>32.35</td>
                                  <td>81.28</td>
                                  <td>36.91</td>
                                </tr>
                                
                                 <tr>
                                    <td>Earnings per Share (Diluted) (Face Value of Rs.10)</td>
                                    <td>32.35</td>
                                  <td>81.28</td>
                                  <td>36.91</td>
                                </tr>
                               <tr>
                                    <td>Net Asset Value per share</td>
                                    <td>105.84</td>
                                  <td>73.49</td>
                                  <td>(7.79)</td>
                                </tr>
                            </table>
                            </div>   -->       
                          
                          <!--unistay start-->
                   <!--       <div class="notificationtable investor-table">
                                <h5 class="mt-0">UNISTAY HOSPITALITY PRIVATE LIMITED </h5>  
                            <p>
                              (CINU55200DL2019PTC348715)
                            </p>
                            <p>
                              INFORMATION BASED ON AUDITED STANDALONE FINANCIAL STATEMENT FOR THE PRECEDING THREE YEARS<br> (Rs. in million except per share data)

                             </p>
                           
                            <table class="table border-bottom mb-5" border="0">
                                 <tr class="table-dark">
                                  <th>Particulars</th>
                                    <th>Financial Year 2022</th>
                                    <th>Financial Year 2021</th>
                                  <th>Financial Year 2020</th>
                                </tr>
                                <tr>
                                    <td>Equity Capital</td>
                                    <td>0.10</td>
                                  <td>0.10</td>
                                  <td>0.10</td>
                                </tr>
                                
                                <tr>
                                    <td>Reserves (Excluding Revaluation Reserve)</td>
                                    <td>25.55</td>
                                  <td>  24.25 </td>
                                  <td> 13.32 </td>
                                </tr>
                                
                                 <tr>
                                    <td>Sales</td>
                                    <td> 0.22 </td>
                                   <td> 12.00</td>
                                   <td>11.00</td>
                                </tr>
                                
                                 <tr>
                                    <td>Profit/(Loss) after Tax</td>
                                    <td>1.30 </td>
                                   <td>10.93 </td>
                                   <td> 13.32 </td>
                                </tr>
                                
                                <tr>
                                    <td>Basic earnings per share and diluted earnings per share before extra-ordinary items </td>
                                    <td>130.20 </td>
                                  <td>1,093.08 </td>
                                  <td>1,389.14 </td>
                                </tr>
                                
                                 <tr>
                                    <td>Basic earnings per share and diluted earnings per share after extra-ordinary items</td>
                                    <td>130.20 </td>
                                  <td>1,093.08 </td>
                                  <td> 1,389.14</td>
                                </tr>
                               <tr>
                                    <td>Net asset value</td>
                                    <td> 2,565.33 </td>
                                  <td>2,435.13</td>
                                  <td> 1,342.05 </td>
                                </tr>
                            </table>
                            </div>     -->     
                          <!--unistay end-->
                          
                          
                          
                           <!--unistay start-->
                          <div class="notificationtable investor-table">
                                <h5 class="mt-0">GLOBAL TELECOMMUNICATION PVT. LTD. </h5>  
                            <p>
                              (CIN: U93030DL1999PTC099063)
                            </p>
                            <p>
                              INFORMATION BASED ON AUDITED STANDALONE FINANCIAL STATEMENT FOR THE PRECEDING THREE YEARS<br> (Rs. in million except per share data)

                             </p>
                           
                            <table class="table border-bottom mb-5" border="0">
                                 <tr class="table-dark">
                                  <th>Particulars</th>
                                    <th>Financial Year 2022</th>
                                    <th>Financial Year 2021</th>
                                  <th>Financial Year 2020</th>
                                </tr>
                                <tr>
                                    <td>Equity Capital</td>
                                    <td>7.04</td>
                                  <td>9.33</td>
                                  <td>9.33</td>
                                </tr>
                                
                                <tr>
                                    <td>Reserves (Excluding Revaluation Reserve)</td>
                                    <td>22.83</td>
                                  <td> 15.73 </td>
                                  <td> 12.31</td>
                                </tr>
                                
                                 <tr>
                                    <td>Sales</td>
                                    <td> 13.86</td>
                                   <td>Nil</td>
                                   <td>73.87</td>
                                </tr>
                                
                                 <tr>
                                    <td>Profit/(Loss) after Tax</td>
                                    <td>12.76</td>
                                   <td>3.42 </td>
                                   <td>4.34</td>
                                </tr>
                                
                                <tr>
                                    <td>Basic earnings per share and diluted earnings per share before extra-ordinary items</td>
                                    <td>18.12 </td>
                                  <td>3.66</td>
                                  <td>4.65</td>
                                </tr>
                                
                                 <tr>
                                    <td>Basic earnings per share and diluted earnings per share after extra-ordinary items</td>
                                    <td>18.12 </td>
                                  <td>3.66</td>
                                  <td>4.65</td>
                                </tr>
                               <tr>
                                    <td>Net asset value</td>
                                    <td> 42.43</td>
                                  <td>26.85</td>
                                  <td> 23.19</td>
                                </tr>
                            </table>
                            </div>          
                          <!--unistay end-->
                          
              <!--            	<div class="notificationtable investor-table">
                                <h5 class="mt-0">Audit financial for 2021-22</h5>                          
                            
                           <table class="table border-bottom mb-5" border="0">
                              
                                <tr>
                                  <td>Nagar a and associates</td>
                              	<td><a href="pdf/Audited-financial-for-2022-(Unistay).pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>  <td></td>
                              </tr>
                               
                            </table>
                            </div>   
                          
                          	<div class="notificationtable investor-table">
                                <h5 class="mt-0">Audit financial for 2020-21</h5>                          
                            
                           <table class="table border-bottom mb-5" border="0">
                              
                                <tr>
                                  <td>Nagar a and associates</td>
                              	<td><a href="pdf/FY2021-20.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>  <td></td>
                              </tr>
                               
                            </table>
                            </div>       --> 
                          
                        </div>
                    </div>
                </div>
              
               
              
     <div class="card">
                    <div class="card-head" id="headingThirtytwo">
                        <h6 class="mb-0 collapsed invertorcol text-uppercase" data-toggle="collapse" data-target="#collapseThirtytwo" aria-expanded="false" aria-controls="collapseThirty">
                            <b> Financial of Material Subsidiary Companies</b> <span class="halvar_rg"></span>
                        </h6>
                    </div>
                
                    <div id="collapseThirtytwo" class="collapse" aria-labelledby="headingThirtytwo" data-parent="#accordionExample">
                        <div class="card-body pb-0">
                            <div class="notificationtable quterly-table mterial-subsidiaries">
                              <table class="table border-bottom" border="0">
                                <tr class="table-dark">
                                    <th>Financial of Material Subsidiary Companies</th>
                                    <th><span class="pull-right list-year">
                                      <select onchange="change_year('subsidiaries')" id="subsidiaries_value">
                                        <option value="3">2021-22</option>
                                        <option value="2">2020-21</option>
                                        <option value="1">2019-20</option>
                                      </select>
                                      </span></th>
                                </tr>
                                
                             
                             
                             
                            </table> 
                             
                             <table class="table border-bottom list-table" border="0" id="subsidiaries_tab">
                               

                              
                            </table> 
                           
                            </div>
                        </div>
                    </div>
                </div> 
              
      <div class="card">
                    <div class="card-head" id="headingThirtythree">
                        <h6 class="mb-0 collapsed invertorcol text-uppercase" data-toggle="collapse" data-target="#collapseThirtythree" aria-expanded="false" aria-controls="collapseThirty">
                            <b>Material Contracts and Documents  </b> <span class="halvar_rg"></span>
                        </h6>
                    </div>
                
                    <div id="collapseThirtythree" class="collapse" aria-labelledby="headingThirtythree" data-parent="#accordionExample">
                        <div class="card-body pb-0">
                           <div class="notificationtable corporate">
                           <table class="table border-bottom" border="0">
                                <tbody><tr class="table-dark">
                                    <th> MATERIAL CONTRACTS </th>
                                    
                                </tr>                             
                             
                             
                             
                            </tbody>
                              </table> 
                             
                             <table class="table border-bottom list-table" border="0">
                               <tbody>
                                 <tr>
                                 	<td style="width: 20%;"><b>Sr. No.</b></td>
                                   <td  style="width: 80%;" colspan="2"><b>File Name</b></td>
                                 
                                 </tr>
                                 
                                 <tr>
                                   <td style="width: 20%;">1</td>
                                    <td style="width: 80%;">Offer Agreement</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/1-Offer-Agreement.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                <tr>
                                   <td style="width:20%;">2</td>
                                    <td>Registrar Agreement and termination letter issued by Sarvpriya Securities</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/2. Registrar Agreement and termination letter issued by Sarvpriya Securities.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                  <tr>
                                   <td style="width:20%;">3</td>
                                    <td>Cash Escrow and Sponsor Bank(s) Agreement -12.09.2023</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/3. Cash Escrow and Sponsor Bank(s) Agreement -12.09.2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                  <tr>
                                   <td style="width:20%;">4</td>
                                    <td>Share Escrow Agreement -11.09.2023</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/4. Share Escrow Agreement -11.09.2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                  <tr>
                                   <td style="width:20%;">5</td>
                                    <td>Syndicate Agreement - 12.09.2023</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/5. Syndicate Agreement - 12.09.2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                               <!--   <tr>
                                   <td style="width:20%;">6</td>
                                    <td>Monitoring Agency Agreement - 08.09.2023</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/7. Monitoring Agency Agreement - 08.09.2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>-->
                             <tr>
                                   <td style="width: 20%;">6</td>
                                    <td style="width: 80%;">Monitoring Agency Agreement - 08.09.2023</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investors/7-Monitoring-Agency-Agreement-08.09.2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                               
                             
                            </tbody>
                            </table> 
                             
                             
                          
                            </div>
                           <div class="notificationtable corporate mt-5">
                           <table class="table border-bottom" border="0">
                                <tbody><tr class="table-dark">
                                    <th> MATERIAL DOCUMENTS </th>
                                    
                                </tr>                             
                             
                             
                             
                            </tbody>
                              </table> 
                             
                             <table class="table border-bottom list-table" border="0">
                               <tbody>
                                 <tr>
                                 	<td style="width: 20%;"><b>Sr. No.</b></td>
                                   <td  style="width: 80%;" colspan="2"><b>File Name</b></td>
                                 
                                 </tr>
                                 <tr>
                                   <td style="width: 20%;">1 to 4</td>
                                    <td style="width: 80%;">Memorandum and Articles of Association with Incorporation Certificates</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/Memorandum and Articles of Association with Incorporation Certificates.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                <tr>
                                   <td style="width:20%;">5</td>
                                    <td>Investors common agreement</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/Investors common agreement.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                <tr>
                                   <td style="width: 20%;">6</td>
                                    <td>Investor Rights Agreement – HCARE</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/Investor Rights Agreement -HCARE.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                               
                                  <tr>
                                   <td style="width: 20%;">7</td>
                                    <td>Investor Rights Agreement – IFC</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/Investor Rights Agreement - IFC.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                               
                                  <tr>
                                   <td style="width: 20%;">8</td>
                                    <td>HCARE Letter Agreement</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/8. HCARE Letter Agreement.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                               
                                 
                                  <tr>
                                   <td style="width: 20%;">9</td>
                                    <td>IFC Letter Agreement</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/9. IFC LETTER AGREEMENT.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                               
                                 
                                  <tr>
                                   <td style="width: 20%;">10</td>
                                    <td>Put Option Agreement – IFC</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/10. Put Option Agreement -IFC.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                               
                                 
                                  <tr>
                                   <td style="width: 20%;">11</td>
                                    <td>Termination Agreement to the Put Option Agreement – IFC</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/11. Termination Agreement to the Put Option Agreement - IFC.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                               
                                 
                                  <tr>
                                   <td style="width: 20%;">12</td>
                                    <td>Put Option Agreement – HACRE</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/12. HACRE Put Option Agreement.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                     
                                </tr>
                               
                                 
                                  <tr>
                                   <td style="width: 20%;">13</td>
                                    <td>Termination Agreement to the Put Option Agreement - HCARE</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/13. Termination Agreement to the Put Option Agreement - HCARE.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                    <tr>
                                   <td style="width: 20%;">14</td>
                                    <td>Policy Right Agreement</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/14. Policy right Agreement.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 <tr>
                                   <td style="width: 20%;">15</td>
                                    <td>Board Resolution and IPO Committee Resolution authorisation for the Offer & other related matters</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investors/15-Board-Resolution-and-IPO-Committee-Resolution-authorisation-for-the-Offer-&-other-related-matters.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                  <tr>
                                   <td style="width: 20%;">16</td>
                                    <td>IPO committee resolution approving the Fresh Issue and other related matters</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investors/16-IPO-committee-resolution-approving-the-Fresh-Issue-and-other-related-matters.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 <tr>
                                   <td style="width: 20%;">17</td>
                                    <td>Shareholders' resolution approving the Fresh Issue and other related matters</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investors/17-Shareholders-resolution-approving-the-Fresh-Issue-and-other-related-matters.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 <tr>
                                   <td style="width: 20%;">18</td>
                                    <td>Board Resolution and IPO Committee Resolution approving the Draft Red Herring Prospectus</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/18. Board Resolution and IPO Committee Resolution approving the Draft Red Herring Prospectus.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                   <tr>
                                   <td style="width: 20%;">19</td>
                                    <td>Board Resolution approving Red Herring Prospectus - 12.09.2023</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investors/19-Board-Resolution-approving-Red-Herring-Prospectus-12.09.2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 <tr>
                                   <td style="width: 20%;">20.1</td>
                                    <td>Annual Report FY 2022-23</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/20.1 Annual Report FY 2022-23.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 <tr>
                                   <td style="width: 20%;">20.2</td>
                                    <td>Annual Report FY 2021-22</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/20.2 Annual Report FY 2021-22-new.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 <tr>
                                   <td style="width: 20%;">20.3</td>
                                    <td>Annual Report FY 2020-21</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/20.3 Annual Report FY 2020-21.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 <tr>
                                   <td style="width: 20%;">21</td>
                                    <td>Restated Financials & Examination Report 2023</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/21. Restated Financials & Examination Report 2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                   <tr>
                                   <td style="width: 20%;">22</td>
                                    <td>Statement of special tax benefits from Statutory Auditors - 11.09.2023</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/22. Statement of special tax benefits from Statutory Auditors - 11.09.2023 (1).pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                  <tr>
                                   <td style="width: 20%;">23</td>
                                    <td>Consent - Directors, Selling Shareholder, BRLMs, Legal counsels, RTA, CS</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/23-Consent-Directors-Selling-Shareholder-BRLMs-Legal-counsels-RTA-CS.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                   <tr>
                                   <td style="width: 20%;">24</td>
                                    <td>Consent from Walker Chandiok & Co LLP to include their name in RHP - 28.08.2023</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/24. Consent from Walker Chandiok & Co LLP to include their name in RHP - 28.08.2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                  <tr>
                                   <td style="width: 20%;">25</td>
                                    <td>Consent Letter - ARAJ & Associates LLP</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/25. Consent letter - ARAJ & Associates LLP.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                   <tr>
                                   <td style="width: 20%;">26</td>
                                    <td>Consent Letter –Quantum ProjectInfra Limited</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/26. Consent letter - Quantum ProjectInfra Limited.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 
                                   <tr>
                                   <td style="width: 20%;">27</td>
                                    <td>Certificate from Bajaj & Bajaj Associates

</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/27. Certificate from Bajaj & Bajaj Associates.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                  <tr>
                                   <td style="width: 20%;">28</td>
                                    <td>Consent from SNG & Partners Advocates & Solicitors to include their name in RHP</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/28. Consent from SNG & Partners Advocates & Solicitors to include their name in RHP.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                   <tr>
                                   <td style="width: 20%;">29</td>
                                    <td>Anarock Report</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/29. Anarock Report.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 <tr>
                                   <td style="width: 20%;">30</td>
                                    <td>Consent Letter – Anarock</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/30. Consent of Anarock.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                 <tr>
                                   <td style="width: 20%;">31</td>
                                    <td>Due diligence certificate addressed to SEBI from the BRLMs

</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/31. Due diligence certificate addressed to SEBI from the BRLMs.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                   <tr>
                                   <td style="width: 20%;">32</td>
                                    <td>Certificate from ARAJ & Associates LLP



</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/32. Certificate from ARAJ & Associates LLP.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                   <tr>
                                   <td style="width: 20%;">33</td>
                                    <td>In-principle approvals (NSE- 09.09.2022)(BSE - 12.09.2022)

</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/33. In-principle approvals (NSE- 09.09.2022)(BSE - 12.09.2022).pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                   <tr>
                                   <td style="width: 20%;">34</td>
                                    <td>SEBI observation letter – 03.08.2022



</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/34. SEBI observation letter – 03.08.2022.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                   <tr>
                                   <td style="width: 20%;">35</td>
                                    <td>Tripartite agreement between Company, NSDL and Registrar to the Offer



</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investors/35-Tripartite-agreement-Company-NSDL-and-Registrar-to-the-Offer.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                   <tr>
                                   <td style="width: 20%;">36</td>
                                    <td>Tripartite agreement between Company, CDSL and Registrar to the Offer</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/36. Tripartite agreement Company, CDSL and Registrar to the Offer (1).pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                                   <tr>
                                   <td style="width: 20%;">37</td>
                                    <td>SEBI final observation letter – 24.11.2022


</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/37. SEBI final observation letter – 24.11.2022.PDF" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                               
                                 <tr>
                                   <td style="width: 20%;">38</td>
                                    <td>IFC Consent letter pursuant to Investors Common Agreement - 11.09.2023</td>
                                    <td style="width: 20%; text-align: center"><a href="pdf/investor/38. IFC Consent letter pursuant to Investors Common Agreement - 11.09.2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    
                                </tr>
                             
                             
                             
                             
                            </tbody></table> 
                             
                             
                          
                            </div>
                          
                         
                          
                          
                        </div>
                    </div>
                </div>
              
              <div class="card cardbighead">
                    <div class="card-head" id="headingTen">
                        <h6 class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">
                            <b>MATERIAL CREDITORS </b> <span class="halvar_rg"></span>
                        </h6>
                    </div>
                
                    <div id="collapseTen" class="collapse" aria-labelledby="headingTen" data-parent="#accordionExample">
                        <div class="card-body">
                          <div class="notificationtable corporate">
                            
                          
                            <table class="table border-bottom mb-5" border="0">
                                 <tbody><tr class="table-dark">
                                  
                                    <th style="width:auto">Particulars</th>
                                    <th style="width:auto">No. of Creditors</th>
                                  <th style="width:auto">Amount (₹ in million)</th>
                                </tr>
                                <tr>
                                    <td>Material Creditors</td>
                                    <td>5</td>
                                  <td>6591.14 (31 March, 2023)</td>
                               
                                </tr>
                                
                       
                                
                                
                            </tbody></table>
                            
                            <p class="mt-5 mb-3">
                              <b>Name of Material Creditors and Amount owned for each Material
Creditors</b>
                            </p>
                            <table class="table border-bottom mb-5" border="0">
                                 <tbody><tr class="table-dark">
                                  
                                    <th style="width:60%">Name of Party</th>
                                   
                                  <th style="width:40%">Balance as on 31 March, 2023 (in ₹ millions)</th>
                                </tr>
                                <tr>
                                    <td>Yesha Developers-Llp</td>
                                   
                                  <td>2,217.26</td>
                               
                                </tr>
                                   <tr>
                                    <td>DGTCP</td>
                                    
                                  <td>1,452.29</td>
                               
                                </tr>
                                   <tr>
                                    <td>Yohaan Buildcon Llp</td>
                                   
                                  <td>1,195.92</td>
                               
                                </tr>
                                   <tr>
                                    <td>Emaar Mgf India Limited</td>
                                   
                                  <td>1,000.00</td>
                               
                                </tr>
                                   <tr>
                                    <td>Lalwani Brothers Buildcon Llp</td>
                                   
                                  <td>725.68</td>
                               
                                </tr>
                                  
                                   <tr>
                                    <td><strong>Total</strong></td>
                                   
                                  <td><strong>6,591.14</strong></td>
                               
                                </tr>
                    
                                
                            </tbody></table>
                            
                          <p>
                          *includes provisions on account of different expenses which are not been recorded/ credited in the books of accounts to creditor ledger.
                          </p>
                            </div>
                        </div>
                    </div>
                </div> 
              

                
                <div class="card cardbighead">
                    <div class="card-head" id="headingSix">
                        <h6 class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                            <b>CORPORATE GOVERNANCE</b> <span class="halvar_rg"></span>
                        </h6>
                    </div>
                
                    <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="accordion" id="accordionExample2">
                  
                        
                        <div class="card innercard">
                                <div class="card-head" id="headingSubtab2">
                            <h6 class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapseSubtab2" aria-expanded="false" aria-controls="collapseSubtab2">
                                <b>COMPOSITION OF COMMITTEES</b> <span class="halvar_rg"></span>
                            </h6>
                              </div>
                            <div id="collapseSubtab2" class="collapse" aria-labelledby="headingSubtab2" data-parent="#accordionExample2">
                            <div class="card-body">
                                <div class="accordioninner" id="accordionExamplefaq">
                                <div class="card">
                                    <div class="card-head" id="faq1">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq1" aria-expanded="false" aria-controls="collapsefaq1">
                                              <b>AUDIT COMMITTEE</b>
                                        </strong>
                                    </div>
                                
                                    <div id="collapsefaq1" class="collapse" aria-labelledby="faq1" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                          <div class="notificationtable investor-table">
                                                
                                              <table class="table border-bottom mb-5" border="0">
                                                  <tr class="table-dark">
                                                      <th>NAME</th>
                                                      <th>DESIGNATION</th>
                                                  </tr>

                                                  <tr>
                                                      <td>Mr. K.M. Agarwal</td>
                                                      <td>Chairman</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Chandra Wadhwa</td>
                                                      <td>Member</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Ravi Aggarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                              </table>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq2">
                                        <strong class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapsefaq2" aria-expanded="false" aria-controls="collapsefaq2">
                                           <b> STAKEHOLDERS RELATIONSHIP COMMITTEE</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq2" class="collapse" aria-labelledby="faq2" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                   <div class="notificationtable investor-table">
                                                
                                              <table class="table border-bottom mb-5" border="0">
                                                  <tr class="table-dark">
                                                      <th>NAME</th>
                                                      <th>DESIGNATION</th>
                                                  </tr>

                                                  <tr>
                                                      <td>Mr. Chandra Wadhwa</td>
                                                      <td>Chairman</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Pradeep Kumar Aggarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Ravi Aggarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                                
                                              </table>
                                          </div>
                                        </div>
                                    </div>
                                </div>   
                                <div class="card">
                                    <div class="card-head" id="faq3">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq3" aria-expanded="false" aria-controls="collapsefaq3">
                                              <b>NOMINATION AND REMUNERATION COMMITTEE</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq3" class="collapse" aria-labelledby="faq3" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="notificationtable investor-table">
                                                
                                              <table class="table border-bottom mb-5" border="0">
                                                  <tr class="table-dark">
                                                      <th>NAME</th>
                                                      <th>DESIGNATION</th>
                                                  </tr>

                                                  <tr>
                                                      <td>Mr. Chandra Wadhwa</td>
                                                      <td>Chairman</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. K.M. Agarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Pradeep Kumar Aggarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Vekatesan Narayanan</td>
                                                      <td>Member</td>
                                                  </tr>
                                              </table>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq4">
                                        <strong class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapsefaq4" aria-expanded="false" aria-controls="collapsefaq4">
                                             <b>BANKING AND FINANCE COMMITTEE
</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq4" class="collapse" aria-labelledby="faq4" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                      <div class="notificationtable investor-table">
                                                
                                              <table class="table border-bottom mb-5" border="0">
                                                  <tr class="table-dark">
                                                      <th>NAME</th>
                                                      <th>DESIGNATION</th>
                                                  </tr>

                                                  <tr>
                                                      <td>Mr. Pradeep Kumar Aggarwal</td>
                                                      <td>Chairman</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Lalit Kumar Aggarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Ravi Aggarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                                
                                              </table>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                                 <div class="card">
                                    <div class="card-head" id="faq5">
                                        <strong class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapsefaq5" aria-expanded="false" aria-controls="collapsefaq5">
                                              <b>Project Committee</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq5" class="collapse" aria-labelledby="faq5" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                      <div class="notificationtable investor-table">
                                                
                                              <table class="table border-bottom mb-5" border="0">
                                                  <tr class="table-dark">
                                                      <th>NAME</th>
                                                      <th>DESIGNATION</th>
                                                  </tr>

                                                  <tr>
                                                      <td>Mr. Ravi Aggarwal</td>
                                                      <td>Chairman</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Lalit Kumar Aggarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Devender Aggarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                                
                                              </table>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                               
                                <div class="card">
                                    <div class="card-head" id="faq6">
                                        <strong class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapsefaq6" aria-expanded="false" aria-controls="collapsefaq6">
                                             <b>CORPORATE SOCIAL RESPONSIBILITY COMMITTEE</b> 
                                        </strong>
                                    </div>
                                    <div id="collapsefaq6" class="collapse" aria-labelledby="faq6" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                          <div class="notificationtable investor-table">
                                                
                                              <table class="table border-bottom mb-5" border="0">
                                                  <tr class="table-dark">
                                                      <th>NAME</th>
                                                      <th>DESIGNATION</th>
                                                  </tr>

                                                  <tr>
                                                      <td>Mr. Pradeep Kumar Aggarwal</td>
                                                      <td>Chairman</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. K.M. Agarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Lalit Kumar Aggarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                                
                                              </table>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq7">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq7" aria-expanded="false" aria-controls="collapsefaq7">
                                            <b>IPO Committee</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq7" class="collapse" aria-labelledby="faq7" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                 <div class="notificationtable investor-table">
                                                
                                              <table class="table border-bottom mb-5" border="0">
                                                  <tr class="table-dark">
                                                      <th>NAME</th>
                                                      <th>DESIGNATION</th>
                                                  </tr>

                                                  <tr>
                                                      <td>Mr. Pradeep Kumar Aggarwal</td>
                                                      <td>Chairman</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Lalit Kumar Aggarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Devender Aggarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                                <tr>
                                                      <td>Mr. Ravi Aggarwal</td>
                                                      <td>Member</td>
                                                  </tr>
                                                
                                              </table>
                                          </div>
                                        </div>
                                    </div>
                                </div>
                            </div><!--accordionExamplefaq-->
                            </div>
                           
                            </div>
                        </div>
                        
            <!--            <div class="card innercard subinnercard">
                                <div class="card-head" id="headingSubtab3">
                            <h6 class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapseSubtab3" aria-expanded="false" aria-controls="collapseSubtab3">
                                <b>BOARD MEETING NOTICES</b> <span class="halvar_rg"></span>
                            </h6>
                              </div>
                            <div id="collapseSubtab3" class="collapse" aria-labelledby="headingSubtab3" data-parent="#accordionExample2">
                            <div class="card-body">
                                <div class="notificationtable corporate">
                           <table class="table border-bottom" border="0">
                                <tbody><tr class="table-dark">
                                    <th colspan="3">BOARD MEETING NOTICES</th>
                                    <th>2022-23</th>
                                </tr>
                                
                            </tbody></table> 
                            
                            <div class="row">
                                    
                                    <div class="col-md-3">
                                        <div class="meeting-box">
                                        <a href="#" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a>
                                    May 10, 2022</div>
                                    </div>
                                    
                                    <div class="col-md-3">
                                        <div class="meeting-box">
                                        <a href="#" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a>
                                    May 10, 2022</div>
                                    </div>
                                    
                                    <div class="col-md-3">
                                        <div class="meeting-box">
                                        <a href="#" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a>
                                    May 10, 2022</div>
                                    </div>
                                    
                                    <div class="col-md-3">
                                        <div class="meeting-box">
                                        <a href="#" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a>
                                    May 10, 2022</div>
                                    </div>
                                    
                                    
                                </div>
                            </div>
                            </div>
                           
                            </div>
                    
                    
                        </div>  -->
                        
           <!--             <div class="card innercard subinnercard">
                                <div class="card-head" id="headingSubtab4">
                            <h6 class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapseSubtab4" aria-expanded="false" aria-controls="collapseSubtab4">
                                <b>STATUTORY FILINGS</b> <span class="halvar_rg"></span>
                            </h6>
                              </div>
                            <div id="collapseSubtab4" class="collapse" aria-labelledby="headingSubtab4" data-parent="#accordionExample2">
                            <div class="card-body pb-0">
                                <div class="quterly-tab">
                                <h5>Shareholding Pattern</h5>
                                <span class="year">2021-22</span>
                            </div>
                            
                            <div class="notificationtable quterly-table">
                           <table class="table border-bottom mt-3" border="0" >
                                <tbody><tr class="table-dark" align="center">
                                     
                                    <th>Q1</th>
                                    <th >Q2</th>
                                    <th>Q3</th>
                                    <th >Q4</th>
                                </tr>
                                <tr>
                                   	

                                    <td><a href="#" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    <td><a href="#" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    <td><a href="#" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                    <td><a href="#" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                </tr>
                            </tbody></table>  
                            </div>
                            </div>
                           
                            </div>
                    
                    
                        </div>  -->
                              
                              
                         <div class="card innercard subinnercard">
                                <div class="card-head" id="headingSubtab5">
                            <h6 class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapseSubtab5" aria-expanded="false" aria-controls="collapseSubtab5">
                                <b>POLICIES</b> <span class="halvar_rg"></span>
                            </h6>
                              </div>
                            <div id="collapseSubtab5" class="collapse" aria-labelledby="headingSubtab5" data-parent="#accordionExample2">
                            <div class="card-body">                             
                              
                          <div class="notificationtable investor-table">                              
                           
                            <table class="table border-bottom mb-5" border="0">
                                 
                                <tr>
                                    <td>1. Policy on Materiality of Related Party Transaction</td>
                                    <td><a href="pdf/investors/Related-Party-Transactions.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                  
                                </tr>
                                
                                <tr>
                                    <td>2. Whistle Blower Policy/Vigil Mechanism</td>
                                    <td><a href="pdf/investors/Whistle-Blower-Policy.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                 
                                </tr>
                                
                                 <tr>
                                    <td>3. Familiarisation Programme for Independent Directors</td>
                                    <td><a href="pdf/investors/Familiarisation-programme-for-IDs.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                  
                                </tr>
                                
                                 <tr>
                                    <td>4. Code of Conduct and Business Ethics</td>
                                    <td><a href="pdf/investors/Code-of-conduct.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                   
                                </tr>
                                
                                <tr>
                                    <td>5. Archival Policy</td>
                                    <td><a href="pdf/investors/Archival-Policy.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                  
                                </tr>
                                
                                 <tr>
                                    <td>6. Policy for Determination of Materiality of Events/Information</td>
                                    <td><a href="pdf/investors/Policy-for-determination-of-material-events.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                 
                                </tr>
                               <tr>
                                    <td>7. Policy for Determining Material Subsidiaries</td>
                                    <td><a href="pdf/investors/Policy-of-material-subsidiaries.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                  
                                </tr>
                              <tr>
                                    <td>8. CSR Policy</td>
                                    <td><a href="javascript:void(0)" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                  
                                </tr>
                              <tr>
                                    <td>9. Nomination and Remuneration Policy</td>
                                    <td><a href="javascript:void(0)" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"></a></td>
                                  
                                </tr>
                            </table>
                            </div> 
                              
                              
                              
                              
                              
                              
                              
                           	 </div>
                           
                            </div>
                    
                    
                        </div>
                              
                                            
                      <div class="card innercard subinnercard">
                                <div class="card-head" id="headingSubtab6">
                            <a href="pdf/appointment/Terms-and-Conditions-of-Appointment-of-Independent-Directors.pdf" target="_blank" class="appointment_btn">
                              <h6 class="mb-0 collapsed invertorcol">
                                <b>TERMS AND CONDITIONS OF APPOINTMENT OF INDEPENDENT DIRECTORS</b> <span class="halvar_rg"></span>
                            	</h6>
                             </a>
                              </div>                          
                    
                    
                        </div>  
                    
                    </div>
                           
                        </div>
                    </div>
                </div>
                
                
            <div class="card">
                    <div class="card-head" id="headingSeven">
                        <h6 class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">
                            <b>ANNUAL DOCKET</b> <span class="halvar_rg"></span>
                        </h6>
                    </div>
                
                    <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordionExample">
                        <div class="card-body">
                           <div class="notificationtable corporate">
                           <table class="table border-bottom" border="0">
                                <tr class="table-dark">
                                    <th>ANNUAL DOCKET</th>
                                    <th><span class="pull-right list-year">
                                      <select id="annual_docket_value" onchange="change_year('annual_docket')">
                                         <option value="4">2022-23</option>
                                        <option value="3">2021-22</option>
                                        <option value="2">2020-21</option>
                                        <option value="1">2019-20</option>
                                      </select>
                                      </span></th>
                                </tr>
                                
                             
                             
                             
                            </table> 
                             
                             <table class="table border-bottom list-table" border="0" id="annual_docket_tab">
                               
                            </table> 
                             
                             
                          
                            </div>
                        </div>
                    </div>
                </div> 
                
        
                
                
                
                <div class="card cardbighead">
                    <div class="card-head" id="headingEleven">
                        <h6 class="mb-0 collapsed invertorcol" data-toggle="collapse" data-target="#collapseEleven" aria-expanded="false" aria-controls="collapseEleven">
                            <b>REGISTRAR & SHARE TRANSFER AGENT</b> <span class="halvar_rg"></span>
                        </h6>
                    </div>
                
                    <div id="collapseEleven" class="collapse" aria-labelledby="headingEleven" data-parent="#accordionExample">
                        <div class="card-body">
                          <div class="notificationtable investor-table">                           
                           
                            <table class="table border-bottom mb-5" border="0">
                                 <tr class="table-dark">                                 
                                    <th>Link Intime India Private Limited</th>                                   
                                </tr>
                              <tr>                                 
                                    <td>Address: C-101, 1st Floor, 247 Park, L.B.S. Marg, Vikhroli (West), Mumbai 400 083 Maharashtra, India </td>                                 
                                </tr>
                              <tr>                                 
                                     <td style="display: flex;">Tel: <a href="tel:+91 22 4918 6200"> +91 22 4918 6200</a></td>                                   
                                </tr>
                              <tr>                                 
                                    <td> Contact person: Shanti Gopalkrishnan</td>                                   
                                </tr>
                            </table>
                          </div>
                            
                        </div>
                    </div>
                </div>
                
       
                
            </div>
          
          	<div class="conlefttext wow animate__ animate__fadeInUp">
                                <strong>CONTACT PERSON</strong>
                                <p>Meghraj Bothra <br> <i>Company Secretary and Compliance Officer</i></p>
                              	<p>E-mail: <a class="mt-2" href="mailto: cs@signatureglobal.in"> cs@signatureglobal.in</a></p> 
                            </div>
          
          
          
        </div>
    </div>
  	
	 
   
    

<!--Footer-->
    <footer class="footerbg padd100">
       <div class="width100">
            <div class="container">
                <div class="row paddb60">
                   <div class="col-12">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt m-0 wow animate__ animate__fadeInUp">
                                    <strong>SIGNATURE GLOBAL</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/residential/" title="Residentential projects by Signature Global">Residential</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/" title="Commercial projects by Signature Global">Commercial</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/">Retail</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class=" footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>OUR PRESENCE</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/commercial/society-shops/gurugram/" title="Signature Global in Gurugram">Gurugram</a></li>
                                        <li><a href="https://www.signatureglobal.in/residential/plots/karnal" title="Signature Global in Karnal">Karnal</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/ghaziabad" title="Signature Global in Ghaziabad">Ghaziabad</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>ABOUT US</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" title="Signature Global - Chairman's message" class="scdown">Chairman’s Message</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" title="Signature Global - Board of Director" class="scdown">Board of Directors</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" title="Signature Global - Key Managerial Positions" class="scdown">Key Managerial Positions</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" title="Our Architect" class="scdown">Our Architects</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" title="Signature Global - Vission & Mission of Signature Global" class="scdown">Vision & Mission</a></li>
                                    <!--    <li><a href="signature-global-foundation.php" title="Signature Global Foundation">Signature Global Foundation</a></li>-->
                                    </ul>
                                </div>
                           </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>CAREERS</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/career.php#as-associate" title="Careers at Signature Global">As Associate</a></li>
                                        <li><a href="https://www.signatureglobal.in/career.php#life-signature" title="Life At Signature Global">Life @ Signature Global </a></li>
                                        <li><a href="#"></a></li>
                                    </ul>
                                </div>
                              
                                <div class="footernav halvar_lt wow animate__ animate__fadeInUp publicnoticehome">
                                  <ul>
                                    <li><a href="https://www.signatureglobal.in/public-notice.php" title="Signature Global Public Notice"><strong>Public Notice</strong></a></li>
                                  </ul>                                  
                             	</div>
                                          
                           </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong style="margin-bottom: 15px;">GALLERY</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/gallery.php" title="Signature Global Gallery">Picture Library</a></li>
                                        <li><a href="https://www.signatureglobal.in/video-gallery.php" title="Signature Global Video Gallery">Video Library</a></li>
                                    </ul>
                                </div>   
                            </div>
                           <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/media.php" title="Signature Global Blogs">MEDIA</a></strong> 
                                    <ul>
                                     <li><a href="https://www.signatureglobal.in/media-coverage.php" title="Signature Global Gallery">Media Coverage</a></li>
                                        <!--<li><a href="https://www.signatureglobal.in/press-release.php" title="Signature Global Video Gallery">Press Release</a></li> -->
                                         <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Gallery">Press Kit</a></li>
                                        <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Video Gallery">Media Contact</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                   <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/blog" title="Signature Global Blogs">Blog</a></strong>
                                <!--    <strong class="mb-2"><a class="clrwh opctext" href="https://online.anyflip.com/dhkmm/nalj/mobile/index.html" target="_blank" title="Signature Global Newsletter ">NEWSLETTER</a></strong> -->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/home-loans.php" title="Signature Global - Home Loans">Home Loans</a></strong>
                                  <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/pay-online.php" title="Signature Global - APPLY ONLINE">PAY ONLINE</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/award.php" title="Signature Global Certificates">AWARD</a></strong>                                  
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                 <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" target="_blank" title="Signature Global Login">MBDA/BDA Login</a></strong>
                                   <!-- <strong class="mb-2"><a class="clrwh opctext" href="http://signatureglobal04.realboost.in/add_appointment.aspx" target="_blank" title="Signature Global Appointments">Appointment</a></strong>-->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/terms-of-appointment.php" title="Signature Global - Terms of appointment">Terms of Appointment</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/green-development.php" title="Signature Global - Green Development">Green Development</a></strong>
                                </div>     
                            </div>
                        </div>
                        
                   </div>
                </div>
            </div>
        </div>
      
        
        <div class="width100 bordertop padt60 wow animate__ animate__fadeInUp">
            <div class="container">
                <div class="row">    
                    <div class="col-lg-3">
                       <div class="footerlogo wow animate__ animate__fadeInUp">
                           <img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/>
                       </div> 
                    </div>
                    <div class="col-lg-4">
                        <div class="footernav pl-65 wow animate__ animate__fadeInUp">
                            <strong>REGISTERED OFFICE</strong>
                            <p>13<sup>th</sup> Floor, Dr. Gopal Das Bhawan, 28<br class="ftmb"/> Barakhamba Road, Connaught Place,<br class="ftmb"/> New Delhi 110 001, India.</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Registered Office: +91 11 4928 1700</a>
                        </div>
                    </div>
                    <div class="col-lg-3 pl-00">
                        <div class="footernav wow animate__ animate__fadeInUp">
                            <strong>CORPORATE OFFICE</strong>
                            <p>Unit No.101, Ground Floor, Tower-A,<br class="ftmb"/>Signature Tower South City-1, Gurugram,<br class="ftmb"/>Haryana 122 001, India</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Corporate Office: +91 124 4398 011</a>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="footermedianav mtopft wow animate__ animate__fadeInUp">
                            <strong>FOLLOW US</strong>
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </footer>
     <!--policytab-->
     <div class="policywraper">
         <div class="container">
             <div class="row">
                 <div class="col-lg-10 col-md-10">
                     <div class="policylink text-left">
                        <p>© 2023 Signature Global. All Rights Reserved <br class="mobhidebr"/><span class="clrwh mobhide">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/advertising-policy-for-channel-partners.php"  >Advertising Policy For Channel Partners</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/privacy-policy.php" title="Signature Global - Privacy Policy">Privacy Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/social-media-policy.php" title="Signature Global - Social Media Policy">Social Media Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/generic-faqs-for-haryana-affordable-housing-policy.php">Generic Faq's</a>                        
                       </p>
                       
                     </div>
                  
                 </div>
             <!--     <div class="col-lg-2 col-md-2 cclogo ">
                     <img src="https://www.signatureglobal.in/images/cogdigital.svg" alt="" width="15">
                   </div> -->
             </div>
         </div>
     </div>
   
    <script>
         $.urlParam = function (name) {
            var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);
            return (results !== null) ? results[1] || 0 : false;
            }
            
            var utmSource = $.urlParam('utm_source') ? $.urlParam('utm_source') : 'direct';
            var utmMedium = $.urlParam('utm_medium') ? $.urlParam('utm_medium') : '';
            var utmCampaign = $.urlParam('utm_campaign') ? $.urlParam('utm_campaign') : '';
            var utmId = $.urlParam('utm_id') ? $.urlParam('utm_id') : '';
             
            var enq_url = new URL("https://enquiry.signatureglobal.in/?projectName=ContactUs&enquiryFrom=Online");
            $(function() {
                    enq_url.searchParams.set('utm_source',utmSource);
                    if(utmMedium!=""){enq_url.searchParams.set('utm_medium',utmMedium);}
                    if(utmCampaign!=""){enq_url.searchParams.set('utm_campaign',utmCampaign);}
                    if(utmId!=""){enq_url.searchParams.set('utm_id',utmId);}
                    
              if($('#main_frame').length > 0)
                    $('#main_frame').attr('src', enq_url)
            
            });

    </script>


<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/animate.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/jquery.fancybox.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/slick.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>


<script src="https://www.signatureglobal.in/js/wow.min.js"></script>
<script src="https://www.signatureglobal.in/js/slick.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.fancybox.min.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.validate.min.js"></script>
<script src="https://www.signatureglobal.in/js/additional-methods.js"></script>
<script src="https://www.signatureglobal.in/js/custom.js"></script> 
<script src="https://www.signatureglobal.in/js/app.js"></script> 
<!-- Start of  Zendesk Widget script -->
<script>
   setTimeout(function(){
      var chatScript = '<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"/>';
      $('body').append(chatScript);
   },  
 5000);
</script>

<script>
  window.addEventListener('load', function() {
    jQuery('body').on('mousedown', '[href*="tel:"]', function() {
      gtag('event', 'phone_call')
    })
    jQuery('body').on('mousedown', '[href*="api.whatsapp.com"]', function() {
      gtag('event', 'whatsapp_click')
    })
    jQuery('body').on('mousedown', '.btnrt:contains(Enquire Now)', function() {
      gtag('event', 'enquire_now')
    })
    jQuery('body').on('mousedown', '.contact100-form-btn:contains(Submit)', function() {
      gtag('event', 'Submit_btn')
    })
  });

</script>
<!--<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"> </script>-->
<!-- End of  Zendesk Widget script -->





 


</body>
</html><script>

$(document).ready(function() {
   change_year('financial');
   change_year('subsidiaries');
   change_year('annual_docket');
   change_year('annual_return');
});
  
function change_year($type){
  
  $id = '#'+ $type + '_value';
  $year = $($id).val()
  $.ajax({ url:"https://www.signatureglobal.in/investor_info.php", method:"POST", 
                data: 'type='+ $type + '&year=' + $year,
                success:function(response){
                $('#'+ $type + '_tab').html(response)
    		}
  });
}
</script>
<style>
     .investors-sec .notificationtable h5{
         font-family: 'Halvar Eng Lt' !important;
         font-size:30px;
         margin: 20px 0;
     }
     .investor-table table td{font-size:22px;}
     
     .border-bottom{border-bottom: 1px solid #908e8e;}
     .color-box{background: #203D3B;color: #fff;padding:30px;margin-top:60px;}
     .border-lft {
         padding-left:235px;
         position:relative;
         
     }
     
     .border-lft:after{content: '';width:1px;height:100%;background:#919392;left:0;position:absolute;top:0;}
     .chairman-dis h5{
         font-family: 'Halvar Eng Lt' !important;
         font-size:30px;
         margin-bottom:25px ;
         color:#fff;
     }
     
     .chairman-dis p{font-size:17px;}
     .chairman-dis a{color:#fff;}
    .pd-t0{padding-top:60px !important;}
    .investors-sec .accordion .card h6{font-size:32px;}
    .investors-sec .accordion .card h6 b{display: inline-block;}
    .investors-sec .accordion .card h6{display: flex;align-items: center;}
   
    .black_td b{font-weight:600;}
  .corporate th,.financial th,.mterial-subsidiaries th{width:90%}
    .meeting-box{text-align:center;margin-top:15px;}
    .meeting-box img{width: 30px;margin: 10px auto;display: block;}
    .quterly-tab{display:flex;align-items:center;justify-content:space-between;}
    .quterly-tab h5{font-family: 'Halvar Eng Lt' !important;font-size: 30px;margin:0;text-transform:uppercase;}
    .quterly-tab .year{margin-right:0;font-size:18px;color:#000;}
    #accordionExample2  .card h6, #accordionExample3  .card h6, #accordionExample4  .card h6{
        opacity: 0.7;
        font-size: 22px;
        background-size: 16px;
    }
    
    #accordionExample2 .card h6 span, #accordionExample3 .card h6 span,#accordionExample4 .card h6 span {
    font-size: 16px;
    width: 105px;
    }
    
    #accordionExample2 img,#accordionExample3 img,#accordionExample4 img{width:30px;}
    #accordionExample2 .block_fix,#accordionExample3 .block_fix,#accordionExample4 .block_fix{float:right;}
    #collapseSubtab4 img,#collapseSubtab7 img,#collapseSubtab10 img{margin:0 auto;display:block;}
    #accordionExample2 .accordioninner .card strong b{font-family: 'Halvar Eng Lt' !important;
    font-size:19px;letter-spacing:2px;}
    #accordionExample2 .accordioninner .card strong {
    padding: 10px 0;
    }
    
    .repeat_box{
        margin-bottom: 15px;
    border-bottom: 1px solid #000;
    padding-bottom: 15px;
    }
    
    #accordionExample2 .accordioninner .card-body {
    padding: 10px 0;
    background:transparent;
}
    
    .data_comp {
    border-right: solid 1px #000;
    border-top: solid 1px #000;
    margin-top:20px;
}

.investors-sec .accordion .card-body{padding-bottom:0;}

    .data_comp .data_comp_mb span {
    border: solid 1px #000;
    display: block;
    width: 100%;
    color: #000;
    padding: 10px;
    margin: 0;
    border-top: 1px;
    border-right: 1px;
    font-size: 16px;
    letter-spacing: 2px;
}
    
    @media(max-width:991px){
        .investors-sec .accordion .card h6 {font-size: 20px;}
        .border-lft {
    padding-left: 75px;
        }
        
    .repeat_box .col-md-10 {
    width: 100%;
} 

.repeat_box .col-md-2 {
    width: 26%;
}

.repeat_box .row.align-items-center {
    -ms-flex-wrap: inherit;
    flex-wrap: inherit;
}

.corporate th,.financial th,.mterial-subsidiaries th{
    width: 88%;
}
      
        
    }
    
    @media(max-width:560px){
        .border-lft {
        padding-left: 15px;
        margin-top: 40px;
    }
    
    .border-lft:after{display:none}
    .corporate th,.financial th,.mterial-subsidiaries th{
    width: 77%;
}

.investors-sec .accordion .card h6 {
    font-size: 1.4rem;
}

.investors-sec .card-body .col-md-3 {
    width: 50%;
}
      
      .investors-sec .card-body .col-md-4 {
    width: 50%;
}

#accordionExample2 .card h6, #accordionExample3 .card h6, #accordionExample4 .card h6 {
    
    font-size: 18px;
}

.quterly-tab h5 {
    
    font-size: 22px;
}
      .accordion .card h6 b {
 
    width: 70%;
}
    
    }
    
</style>