<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="facebook-domain-verification" content="zqv18clg4hyd5synd83cbrczwv588t" />
<title> Signature Global Proxima II - Affordable Housing Project, Gurugram</title>
<meta name=description content="Signature Global is a brand which stands for Making India Affordable, providing best affordable housing & commercial projects in Gurugram." />
<meta name=keywords content="Signature Global Proxima II, Residential 2 Bhk Apartments in Sector 89, 2 Bhk Flats in Gurgaon, Residential Flats in Gurgaon, Affordable Apartments in Gurugram" />
<link rel="canonical" href="https://www.signatureglobal.in/proxima-ii.php" />
<meta name="robots" content="noodp" />
 

    
  
  
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5S8ZC8X');</script>
<!-- End Google Tag Manager -->
  
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-90138100-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-90138100-1');
</script>
  
  

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-MRPZNF8ZD2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-MRPZNF8ZD2');
</script>
  
<!-- Global site tag (gtag.js) - Google Ads: 962082073 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-962082073"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config','AW-962082073', {'allow_enhanced_conversions':true});
</script>
<script>
  gtag('config', 'AW-962082073/BUgQCILmzakDEJnq4MoD', {
    'phone_conversion_number': '7053-121-121'
  });
</script>
  
  

  
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '359225061117882');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=359225061117882&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<link href=https://www.signatureglobal.in/images/favicon1.png rel="shortcut icon" type=image/x-icon>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/bootstrap.min.css"/>
<link  rel="stylesheet"  href="https://www.signatureglobal.in/css/fontawesome/css/all.min.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/style.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/responsive.css"/>
<script src="https://www.signatureglobal.in/js/jquery.min.js"></script>
<script  src="https://www.signatureglobal.in/js/bootstrap.min.js"></script>
<style>
  .shhhow{display:block !important; opacity:1 !important;}
  }
</style>

</head>
<body>
  <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5S8ZC8X"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

        
    <header class="header-area">
        <div class="overlayhd"></div>
        <nav class="navbar navbar-expand-md navbar-dark">
            <div class="container">
                <a href="https://www.signatureglobal.in/" class="navbar-brand"><img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/></a> 
                <div class="mobiconbtn">
                    <a href="tel:+91-7053121121">
                        <svg id="Layer_4" data-name="Layer 4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><circle class="cls-1 cls2" cx="75" cy="75" r="73.55"/><path d="M54.68,41.25,50,41a5.64,5.64,0,0,0-4,1.36c-2.25,2-5.86,5.76-7,10.69-1.66,7.37.9,16.39,7.51,25.4S65.5,101.9,87.29,108.06c7,2,12.55.65,16.81-2.08a15,15,0,0,0,6.54-9.54l.75-3.47a2.43,2.43,0,0,0-1.35-2.7L94.3,83a2.41,2.41,0,0,0-2.92.71l-6.18,8a1.78,1.78,0,0,1-2,.6C79,90.85,64.81,84.91,57,69.93a1.77,1.77,0,0,1,.23-2l5.9-6.83a2.41,2.41,0,0,0,.39-2.53L56.77,42.71A2.42,2.42,0,0,0,54.68,41.25Z"/></svg>
                    </a>
                    <a id="forother" href="https://api.whatsapp.com/send?phone=%2B917303918365&text=Hii%2C+I+am+interested+in+Signature%20Global+Affordable+Housing">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>
                  	<a id="forwhatsapp" href="https://api.whatsapp.com/send?phone=919311144622&amp;text=">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>	
                  
                </div>
                <button type="button" class="navbar-toggler collapsed" data-target="#main-nav">
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                </button>                
                <div id="main-nav" class="navbar-collapse">
                    <div class="topnavbaxy">
                        <ul class="navbar-nav width100 dlfx">                         
                         <!--   <li><a href="career.php" class="nav-link" title="Signature Global - Carrer">Career </a></li> -->
                            <li class="dropdown loginpage">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">LOGIN <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://signatureglobal2.my.salesforce-sites.com/sg?cpForm=true" class="assreg" target="_blank">Associate Registration</a></li>
                                     <li><a href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" class="assreg" target="_blank">MBDA/BDA Login</a></li>
                                     <li><a href="https://app.hrone.cloud/login" class="assreg assreg1" target="_blank">Employee Login</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                        <!--    <li><a href="pay-online.php" class="nav-link" title="Signature Global  - Pay Online">APPLY ONLINE</a></li>-->
                            <li><a href="https://www.signatureglobal.in/investor.php" class="nav-link" title="Signature Global  - Investor">Investor</a></li> 
                            <li><a href="https://www.signatureglobal.in/customer_support.php" class="nav-link" title="Signature Global  - Custome Support">Customer Support </a></li>                         
                   <!--      <li><a href="pdf/SG_Mobile_App_User_Manual.pdf" class="nav-link" target="_blank">Mobile app User Manual</a></li>-->
                         <li><a href="https://www.signatureglobal.in/signature-global-foundation.php" class="nav-link" target="_blank">Signature Global Foundation</a></li>                        
                        </ul>
                    </div>                     
                    <ul class="navbar-nav width100 dlfx ">
                   <!--     <li class="nav-item">
                          <a href="about-us.php" class="nav-link" title="Signature Global  - About Us">About US </a>
                          
                      </li>-->
                      
                       <li class="nav-item dropdown loginpage position-relative">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">About US <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#companyjourney" class="assreg scdown"> Company's Journey</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" class="assreg scdown" >Chairman's Message</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" class="assreg scdown" >Board of Directors</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" class="assreg scdown">Key Managerial Positions</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" class="assreg scdown" >Our Architects</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" class="assreg scdown">Vision & Mission</a></li>
                                     <li><a href="https://www.signatureglobal.in/career.php#life-signature" class="assreg" target="_blank"> Life @ Signature Global</a></li>
                                     <li><a href="https://www.signatureglobal.in/green-development.php" class="assreg assreg1" target="_blank">Green Development</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                      
                        <li class="nav-item dropdown">
                            <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">RESIDENTIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                            <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-5">
                                                <strong>Residential</strong>
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/residential/affordable/">Affordable Group Housing</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/premium/">Premium Independent Floors</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/plots/">Residential Plots</a></li>
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div> 
                                            </div>
                                            <div class="col-lg-8 col-md-7">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5 col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Residential</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/residential/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_6" data-name="Layer 6"><g id="Layer_1-6" data-name="Layer 6"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Resdential-nvbg.jpg" alt="Residential Projects by Signature Global
" title="Residential Projects by Signature Global
">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item dropdown">
                          <a href="#" title="Commercial projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">COMMERCIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                          <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-6 ">
                                                <strong>Commercial</strong>
                                    
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/commercial/society-shops/">Society Shops</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/malls/">Mall</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/sco-plots/">SCO</a></li> 
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-lg-8 col-md-6 ">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5  col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Commercial</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/commercial/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_7" data-name="Layer 7"><g id="Layer_1-7" data-name="Layer 7"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Commercial-nvbg.jpg" alt="Commercial Projects by Signature Global" title="Commercial Projects by Signature Global">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item"><a title="Signature Global  - Contact Us" href="https://www.signatureglobal.in/contact.php" class="nav-link">CONTACT US </a></li>
                    </ul>
                    <div class="bottommediamobwrap">
                        <ul class="pplink">
                            <li><a href="https://www.signatureglobal.in/privacy-policy.php">Privacy Policy</a></li>
                          <li><span>|</span></li>
                            <li><a href="https://www.signatureglobal.in/social-media-policy.php">Social Media Policy</a></li>
                        </ul>
                        <div class="footermedianav mtopft">
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <div class="overlaymobbg"></div>    
    <!--Download Brochure-->
    <div class="downloadbtnwrap">
        <a href="pdf/proxima-ii/SG-Proxima-2-Multipager.pdf" target="_blank" class="btnrt" alt="">Download Brochure</a>
    </div>
    <!--Download Brochure-->
    <!--Enquire Now Iframe-->
    <div class="registerform">
        <div class="fixedbtn">
            <span class="btnrt">Enquire Now</span>
        </div>
        <div class="innerform">
            <iframe  frameborder="0" width="100%" height="400px" id="abc_frame"></iframe>
        </div>
    </div>
    <!--Enquire Now Iframe-->
    <!--banner section-->
    <div class="banner proxima-ii-banner padd100">
        <div class="overlaybottom"></div>
        <div class="container">
            <div class="cpationlogo" style="width:215px">
                <span><img src="images/logo/SG-Proxima-2.png" alt="Logo"/ style="max-width:215px"></span>
            </div>
           <div class="edgelogo">
                <img src="images/projects/proxima-i/EDGE-Logo-Hi-Res.png" alt="Delevered Stam">
           </div>
          <div class="delevered-stam">
                <img src="images/projects/signum37d-iv/Banner/logo.svg" alt="" class="igbc-logo">
            </div>
        </div>
    </div>
    <!--banner-->
    <!--rera no-->
    <div class="afterimg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        <span>License No.: 121 of 2019 Dated 14.09.2019 RERA Number. RC/REP/HARERA/GGM/386/118/2020/02</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--rera no-->
    <!--Welcome Section-->
    <div class="sectionbg-one">
        <div class="innerprobannerbg">
            <div class="container">
                <div class="row padd100">
                    <div class="col-lg-12">
                          <span class="captext wow animate__ animate__fadeInUp">WELCOME TO </span>
                          <h1 class="headingtag clrwh mb-5 wow animate__ animate__fadeInUp">Signature Global Proxima II</h1>
                    </div>
                    <div class="col-lg-12">
                        <p class="clrwh wow animate__ animate__fadeInUp">Signature Global is India’s No.1 Affordable Housing Company*. Our mission is to provide “Har Parivar Ek Ghar”, because we believe in the philosophy “Kyuki Apna Ghar Toh Apna Hi Hota Hai.” With an endeavour to define the current conventions of Indian real estate development, we are championing excellence in craftsmanship, planning and service. So, we are certified in ISO 9001:2015; 14001:2015; and 45001:2018, delivering the best quality before the promised time.  What’s more, we have introduced the highly advanced global green building certification IGBC. which provides a solution to capitalize on the value of green buildings by promoting benefits to the customers while protecting the environment.</p>
                        <p class="clrwh wow animate__ animate__fadeInUp">The company has successfully launched 18 Affordable Housing projects, all in prime locations which include Gurugram, Sohna and Karnal in Haryana. We have successfully delivered Solera and Synera in Gurugram and offered the possession of Sunrise in Karnal, months before the expected time of delivery. Our success story also includes a commercial mall, focusing on the interests of customers in Vaishali, Ghaziabad, Uttar Pradesh.</p>
                    </div>
                  
                  <div class="col-lg-12">
                    <div class="textwrap mt-4">
                       <h2><p>2 BHK AFFORDABLE FLATS IN SECTOR 89, GURUGRAM </p></h2>
                      
                    </div>
                </div>
                    <div class="col-lg-12">
                        <div class="tablewrap padt80 wow animate__ animate__fadeInUp">
                            <div class="table-responsive-lg">
                                <table class="table table-striped table-dark">
                                    <thead>
                                        <tr>
                                         <!-- <td colspan="10">AREA PER UNIT- SECTOR 89 PHASE-2 (4.73 acres)- SG Proxima 2</td>-->
                                        </tr>
                                        <tr class="tophd">
                                            <td>S.No.</td>
                                            <td>Unit Type Category</td>
                                            <td>Area (in Sqft)</td>
                                            <td>Area (in Sq.mtr.)</td>
                                            <td>Balcony Area</td>
                                          <td>Balcony Area (In Sq. mtr.)</td>
                                          <td>No. of Units</td>
                                          <td>Total Price</td>
                                          <td>5%</td>
                                          <td>20%</td>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td>1</td>
                                        <td>2BHK TYPE -01</td>
                                        <td>581.396</td>
                                        <td>54.013</td>
                                        <td>83.916</td>
                                        <td>7.796</td>
                                       <td>12</td>
                                        <td>25,25,779</td>
                                        <td>122,093</td>
                                        <td>5,09,351.64</td>
                                      </tr>
                                      <tr>
                                        <td>2</td>
                                        <td>2BHK TYPE -02</td>
                                        <td>588.586</td>
                                        <td>54.681</td>
                                        <td>85.543</td>
                                        <td>7.947</td>
                                        <td>19</td>
                                        <td>25,57,604</td>
                                        <td>123,603</td>
                                        <td>5,15,797.99</td>
                                        
                                      </tr>
                                      <tr>
                                        <td>2</td>
                                        <td>2BHK TYPE -03</td>
                                        <td>598.22</td>
                                        <td>55.576 </td>
                                        <td>101.18</td>
                                        <td>9.400</td>
                                        <td>12</td>
                                        <td>26,12,524</td>
                                        <td>125,626</td>
                                        <td>5,27,504.80</td>
                                     
                                      </tr>
                                       <tr>
                                        <td>2</td>
                                        <td>2BHK STORE (M.Q)</td>
                                        <td>645.345</td>
                                        <td>59.954</td>
                                        <td>123.56</td>
                                        <td>11.479</td>
                                        <td>2</td>
                                        <td>2,834,009</td>
                                        <td>135,522</td>
                                        <td>572,980 </td>
                                     
                                      </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>      
    </div>
    <!--Welcome Section-->
    
    
    
    <!--Location-->
    <div class="locationwrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="locationmap wow animate__ animate__fadeInUp">
                        <a data-fancybox="unit-location" href="images/projects/proxima-ii/location-advantage.jpg">
                            <img src="images/projects/proxima-ii/location-advantage.jpg" alt=""/>
                            <div class="btnclick halvar_rg">
                                <span>Click Here</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-5 location-bg">
                    <div class="locationadvantage">
                        <h2 class="headingtag clrwh mb-4 wow animate__ animate__fadeInUp">Location<br/> Advantages</h2>
                        
                        <div class="locationlistslider">
                            <div>
                                <div class="ullist wow animate__ animate__fadeInUp">
                                    <ul>
                                        <li> Sector 89 is one of the most rapidly developing areas of Gurugram.</li>
                                        <li>Project located at 60 meter wide road.</li>
                                        <li> Easy Connectivity from Dwarka Expressway, NH-8, Pataudi Road & KMP Expressway.</li>
                                        <li> Distance from well-known landmarks: Hero Honda Chowk(6 km), Rajiv Chowk (8 km), IFFCO Chowk (12 km) and IGI Airport, Delhi(22 km).</li>
                                        <li> Cycling distance from IMT Manesar.</li>
                                        <li> Next to huge commercial hub (Sector – 88, Gurugram).</li>
                                        <li> Multispecialty hospitals such as Aarvy Healthcare, Arc Multispecialty Hospital & Krishna Hospital in close proximity.</li>
                                        <li> Numerous shopping malls, commercial hubs & hospitals are in close proximity.</li>
                                    </ul>
                                </div>
                            </div>
                            <div>
                                <div class="ullist wow animate__ animate__fadeInUp">
                                    <ul>
                                        <li> Many reputed schools such as SGT Group of Institutes, Yaduvanshi School, Sharda
                                         International School, Colonnels Public School, RPS International School, Sanskar Jyoti
                                         School, Lotus Rise World School, Eureka Pre School, Basant Valley Public School,
                                         Super-30 School, etc. are in close proximity.</li>
                                        <li> Close proximity to Kadipur Industrial Area and Inland Container Depots/Drypots.</li>
                                        <li> Public transport facility – Garhi Harsaru Junction Railway Station.</li>
                                        <li> 30 minutes drive from Gurugram Railway Station.</li>
                                        <li> Upcoming ISBT is nearby (Kherki Dhaula).</li>
                                        <li> Upcoming rapid metro is in close proximity.</li>
                                        <li> 15 km from AIIMS National Cancer Institute, Badsa, Jhajjar.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Location-->
    
    <!--Unit Plan-->
    <div class="unitsectionwrap padd100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Unit Plans</h2>
                    <div class="controlar pull-right">
                        <span class="arrow-icon-leftpl">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </span>
                        <span class="arrow-icon-rightpl">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                            </span>
                    </div>
                </div>
                <div class="col-lg-12 wow animate__ animate__fadeInUp">
                    <div class="unitplanslider">
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/projects/proxima-ii/unit-plan/b1.jpg"><img src="images/projects/proxima-ii/unit-plan/s1.jpg" alt=""/></a>
                               <h3>
                                  <b>TYPE - 01 (2BHK) | COST @23,67,520</b>
                                <span> C.A - 581.396 SQ.FT. | B.A - 83.873 SQ.FT.</span>
                              </h3>
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/projects/proxima-ii/unit-plan/b2.jpg"><img src="images/projects/proxima-ii/unit-plan/s2.jpg" alt=""/></a>
                                <h3>
                                  <b>TYPE - 02 (2BHK) | COST @23,96,933</b>
                                <span>C.A - 588.586 SQ.FT. | B.A - 85.176 SQ.FT.</span>
                              </h3>
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/projects/proxima-ii/unit-plan/b3.jpg"><img src="images/projects/proxima-ii/unit-plan/s3.jpg" alt=""/></a>
                                <h3>
                                  <b>TYPE - 03 (2BHK) | COST @24,36,281</b>
                                <span>C.A - 598.220 SQ.FT. | B.A - 86.801 SQ.FT.</span>
                              </h3>
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/projects/proxima-ii/unit-plan/b4.jpg"><img src="images/projects/proxima-ii/unit-plan/s4.jpg" alt=""/></a>
                                <h3>
                                  <b>TYPE - 04 (2BHK) | COST @24,03,128</b>
                                <span> C.A - 588.263 SQ.FT. | B.A - 89,653 SQ.FT.</span>
                              </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Unit Plan-->
    
    <!--Site Plan-->
    <div class="siteplanwrap padb100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Site Plan</h2>
                </div>
                <div class="col-lg-12">
                    <div class="sitemapimg wow animate__ animate__fadeInUp">
                        <a data-fancybox="siteplan" href="images/projects/proxima-ii/Site-Plan.jpg">
                            <img src="images/projects/proxima-ii/Site-Plan.jpg" alt=""/>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Site Plan-->
    
    <!--Projects Gallery-->
    <div class="elevationsectionwrap padb100">
        <div class="container">
          <div class="row">
            <div class="col-lg-9">
                <span class="captext fcolorlgt wow animate__ animate__fadeInUp">Elevations</span>
                <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">  Our Array of Affordable Accommodations</h2>
            </div>
            <div class="col-lg-3" style="display:none;">
                <div class="clabtn1 wow animate__ animate__fadeInUp">
                    <a class="abtn halvar_rg" href="#">
                        VIEW SPECIFICATION
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{fill:none;stroke:#203d3b;stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                    </a>
                </div>
            </div>
            <div class="col-lg-12 wow animate__ animate__fadeInUp">
                <div class="progalleryslider mt-4">
                    <div class="slider-for">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/1.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/2.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/3.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/4.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/5.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/6.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/7.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/8.jpg" alt="Gallery proxima-ii">
                    </div>
                    <div class="slider-nav"> 
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/1.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/2.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/3.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/4.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/5.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/6.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/7.jpg" alt="Gallery proxima-ii">
                        <img class="item-slick" src="images/projects/proxima-ii/g-slider/8.jpg" alt="Gallery proxima-ii">
                    </div>
                </div>
            </div>
          </div>
        </div>
    </div>
    <!--Projects Gallery-->
    
    
    <!--Accordion Notification-->
    <div class="notificationwrap padb100">
        <div class="container">
            <div class="accordion" id="accordionExample">
                <!--construction update start-->
                
                 <div class="card wow animate__ animate__fadeInUp">
                    <div class="card-head" id="headingTwo">
                        <h2 class="mb-0 collapsed show-more" data-toggle="collapse" data-target="#collapseConstruction" aria-expanded="false" aria-controls="collapseConstruction">
                             <b>Construction Update</b> <span class="halvar_rg text show-more-height"></span>
                        </h2>
                    </div>
                     <div id="collapseConstruction" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="notificationtable">
                                <div class="row">
                                    <!--1-->
                                  
                                   <div class="col-md-4">
                                        <div class="bon_vivant construction-img">
                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=nPqnRC-0227" target="_blank">
                                                <img src="images/Proxima-II-sep-new.jpg" style="">
                                            </a>
                                            <b >Project Update</b>
											<span>1st September 2023</span>                                            
                                    </div>
                                </div> 
                                  
                                  
                                   <div class="col-md-4">
                                        <div class="bon_vivant construction-img">
                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=j5PRA6-0202" target="_blank">
                                                <img src="images/consUpdate/PROXIMA-2.jpg" style="">
                                            </a>
                                            <b >Project Update</b>
											<span>1st June 2023</span>

                                            
                                    </div>
                                </div> 
                                  
                              <div class="col-md-4">
                                        <div class="bon_vivant construction-img">
                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=3J7Xj0-0180" target="_blank">
                                                <img src="images/projects/proxima-ii/construction/SG-Proxima-II-march.jpg" style="">
                                            </a>
                                            <b >Project Update</b>
											<span>1st March 2023</span>

                                            
                                    </div>
                                </div> 
                                  
                                  <div class="col-md-4 mt-5">
                                        <div class="bon_vivant construction-img">
                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=z8cuCs-0153" target="_blank">
                                                <img src="images/projects/proxima-ii/construction/SG-PROXIMA2-December.jpg" style="">
                                            </a>
                                            <b >Project Update</b>
											<span>1st December 2022</span>

                                            
                                    </div>
                                </div>
                                  
                                  <div class="col-md-4 mt-5">
                                        <div class="bon_vivant construction-img">
                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=Sg9ItP-0135" target="_blank">
                                                <img src="images/projects/proxima-ii/construction/Proxima2-sep.jpg" style="">
                                            </a>
                                            <b >Project Update</b>
											<span>1st September 2022</span>

                                            
                                    </div>
                                </div>
                                   
                                  <div class="col-md-4 mt-5">
                                        <div class="bon_vivant construction-img">
                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=HCIbb9-0111" target="_blank">
                                                <img src="images/projects/proxima-ii/construction/Proxima2.jpg" style="">
                                            </a>
                                            <b >Project Update</b>
											<span>1st June 2022</span>

                                            
                                    </div>
                                </div>
                                  
                                   <div class="col-md-4 mt-5">
                                        <div class="bon_vivant construction-img">
                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=Pbkt40-0100" target="_blank">
                                                <img src="images/projects/proxima-ii/construction/Proxima-2.jpg" style="">
                                            </a>
                                            <b >Project Update</b>
											<span>1st March 2022</span>

                                            
                                    </div>
                                </div>
                                  
                                  
                                  
                                <!--2-->
                                <div class="col-md-4">
<!--                                        <div class="" style="display: flex; flex-direction:column; ">-->
<!--                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=ZFznh7-0092">-->
<!--                                                <img src="images/projects/sg-aspire/constructionUpdate/DSC09489.jfif">-->
<!--                                            </a>-->
<!--                                            <b style="display: block; font-size: 1.2rem;-->
<!--    color: #203D3B;-->
<!--    font-weight: normal;-->
<!--    margin-bottom: 5px;-->
<!--    line-height: 1.2;-->
<!--}">February Construction Update</b>-->
                                            
<!--                                    </div>-->
                                </div>
                                
                                <!--3-->
                                <div class="col-md-4">
<!--                                        <div class="" style="display: flex; flex-direction:column; ">-->
<!--                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=ZFznh7-0092">-->
<!--                                                <img src="images/projects/sg-aspire/constructionUpdate/DSC09489.jfif">-->
<!--                                            </a>-->
<!--                                            <b style="display: block; font-size: 1.2rem;-->
<!--    color: #203D3B;-->
<!--    font-weight: normal;-->
<!--    margin-bottom: 5px;-->
<!--    line-height: 1.2;-->
<!--}">February Construction Update</b>-->
                                            
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>


                </div>
                
                
                
                <!--construction update end-->

                
                <div class="card wow animate__ animate__fadeInUp">
                    <div class="card-head" id="headingOne">
                        <h2 class="mb-0 collapsed show-more" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            <b>Notification Advertisement</b> <span class="halvar_rg text show-more-height"></span>
                        </h2>
                    </div>
                
                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="notificationtable">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Title</th>
                                                <th>Date</th>
                                                <th>English</th>
                                                <th>Hindi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                           <tr>
                                                <td>Dainik Jagran(Gurugram)</td>
                                                <td>08.10.2023</td> 
                                                 <td>-</td>                                       
                                                <td><a href="pdf/proxima-ii/Proxima II NPA Cancellation Ad 8x12 cm_05.10.2023.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Jagran(Gurugram)</td>
                                                <td>16.05.2023</td> 
                                                 <td>-</td>                                       
                                                <td><a href="pdf/proxima-ii/Proxima-II-Cancellation-Ad_8x12cm-copy.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                                                                    
                                           <tr>
                                                <td>Jansatta and Dainik Jagran (Gurugram)</td>
                                                <td>24.03.2023</td> 
                                                 <td>-</td>                                       
                                                <td><a href="pdf/proxima-ii/Proxima-II-Draw-Result-Ad-Hindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                          <tr>
                                                <td>Indian Express, Financial Express</td>
                                                <td>24.03.2023</td>                                                
                                                <td><a href="pdf/proxima-ii/Proxima-II-Draw-Result-Ad-English.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                             <td>-</td>
                                            </tr>
                                          
                                          <tr>
                                                <td>Jansatta and Dainik Jagran (Gurugram)</td>
                                                <td>17.03.2023</td> 
                                                 <td>-</td>                                       
                                                <td><a href="pdf/proxima-ii/Proxima-II-Re-Draw-Hindi-Ad.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                          <tr>
                                                <td>Indian Express, Financial Express</td>
                                                <td>17.03.2023</td>                                                
                                                <td><a href="pdf/proxima-ii/Proxima-II-Re-Draw-English-Ad.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                             <td>-</td>
                                            </tr>
                                           <tr>
                                                <td>Indian Express, Financial Express</td>
                                                <td>15.02.2023</td>                                                
                                                <td><a href="pdf/proxima-ii/SGProxima2_LegalAd_16x25cms_English_07.02.2023copy.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                             <td>-</td>
                                            </tr>
                                           <tr>
                                                <td>Jansatta (DNCR) and Dainik Jagran, Gurugram</td>
                                                <td>15.02.2023</td>  
                                              <td>-</td>
                                                <td><a href="pdf/proxima-ii/SGProxima2_LegalAd_16x25cms_Hindi_07.02.2023copy.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            
                                            </tr>
                                          
                                           <tr>
                                                <td> Indian Express, Financial Express</td>
                                                <td>08.02.2023</td>                                                
                                                <td><a href="pdf/proxima-ii/SG-Proxima-2_Legal-Ad_16x25cms_English_07.02.2023-copy.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                             <td>-</td>
                                            </tr>
                                           <tr>
                                                <td>Jansatta (DNCR) and Dainik Jagran, Gurugram</td>
                                                <td>08.02.2023</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/SG-Proxima-2_Legal-Ad_16x25cms_Hindi_07.02.2023-copy.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                          
                                          <tr>
                                                <td>Dainik Jagran(Gurugram)</td>
                                                <td>28.01.2023</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/Proxima-II-23.1.23_8x9cms_CTC.PDF" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>

                                          
											<tr>
                                                <td>Dainik Jagran, Gurugram (Cancellation Ad)</td>
                                                <td>23.04.2022</td>
                                                <td>-</td>
                                                <td><a href="pdf/Proxima II Cancellation Ad_8x13cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>

                                          
                                          
                                            <tr>
                                                <td>Jansatta( DNCR) and Dainik Jagran ( Gurugram) (Draw Result Ad Hindi)</td>
                                                <td>21.01.2022</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/Proxima-II-Re-Draw-Result-Hindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Indian Express, Financial Express (Draw Result Ad English)</td>
                                                <td>21.01.2022</td>
                                                <td><a href="pdf/proxima-ii/notification/Proxima-II-Re-Draw-Result-English.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Jansatta( DNCR) and Dainik Jagran ( Gurugram) (Draw Intimation Ad Hindi)</td>
                                                <td>15.01.2022</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/Proxima II Draw Hindi-Ad.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Indian Express, Financial Express (Draw Intimation Ad English)</td>
                                                <td>15.01.2022</td>
                                                <td><a href="pdf/proxima-ii/notification/Proxima II Ad English.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                             <tr>
                                                <td>Jansatta( DNCR) and Dainik Jagran</td>
                                                <td>17.12.2021</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/SG-Proxima-II-Legal-JS-DJ.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Indian Express, Financial Express</td>
                                                <td>17.12.2021</td>
                                                <td><a href="pdf/proxima-ii/notification/SG-Proxima-II-Legal-IE-FE.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Jansatta( DNCR) and Dainik Jagran Hindi (Gurugram )</td>
                                                <td>10.12.2021</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/SG_Proxima_II_Legal_Ad_16X25_Hindi_JS_DJ.PDF" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Indian Express, Financial Express, English (Gurugram )</td>
                                                <td>10.12.2021</td>
                                                <td><a href="pdf/proxima-ii/notification/SG_Proxima_II_Legal_Ad_16X25_English_IE_FE.PDF" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Public Notice</td>
                                                <td>22.11.2021</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/PublicNotice_EC_Proxima-II_NewsAdvertisement.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Jagran, Gurugram (Cancellation Ad Hindi)</td>
                                                <td>16.11.2021</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/Proxima II Cancellation Ad_8x11cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Jagran, Gurugram (Cancellation Ad Hindi)</td>
                                                <td>26.06.2021</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/Proxima-II Cancellation Ad_8x9cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Jagran (Gurugram)  (Cancellation Ad Hindi)</td>
                                                <td>07.02.2021</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/Proxima II Cancellation Ad_8x9cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Indian Express, Financial Express (Draw Result English)</td>
                                                <td>20.12.2020</td>
                                                <td><a href="pdf/proxima-ii/notification/Proxima_II Re_Draw Result Ad_12x14_cm English.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Jansatta and Dainik Jagran (Draw Result Hindi)</td>
                                                <td>20.12.2020</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/Proxima_II Re_Draw Result Ad_12x14_cm Hindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Indian Express, Financial Express (Draw Intimation English)</td>
                                                <td>12.12.2020</td>
                                                <td><a href="pdf/proxima-ii/notification/Proxima II Draw English Ad 8X10 cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Jansatta and Dainik Jagran (Draw Intimation Hindi)</td>
                                                <td>12.12.2020</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/Proxima II Draw Hindi Ad 8X10 cm.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Indian Express, Financial Express Re-launch Ad (English)</td>
                                                <td>01.11.2020</td>
                                                <td><a href="pdf/proxima-ii/notification/PROXIMA II IE, FE Legal Ad 16X25 English.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Jansatta and Dainik Jagran Re-launch Ad (Hindi)</td>
                                                <td>01.11.2020</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/PROXIMA II JS Legal Ad 16X25 Hindi.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Indian Express, Financial Express Relaunch Legal Ad (English)</td>
                                                <td>25.10.2020</td>
                                                <td><a href="pdf/proxima-ii/notification/SG Proxima II Relaunch Legal Ad 16X25 English.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Jansatta(DNCR) and Dainik Jagran (Gurugram) Relaunch Legal Ad (Hindi)</td>
                                                <td>25.10.2020</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/SG Proxima II Relaunch Legal Ad 16X25 Hindi (1).pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Dainik Jagaran (Cancellation AD Hindi)</td>
                                                <td>07.10.2020</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/SG Proxima Cancellation-AD- II.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                            <tr>
                                                <td>Indian Express, Financial Express (Draw Result English)</td>
                                                <td>14.07.2020</td>
                                                <td><a href="pdf/proxima-ii/notification/Proxima_II_Ad_16x25_cm_English IE,FE.PDF" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                            <tr>
                                                <td>Jansatta and Dainik Jagran (Draw Result Hindi)</td>
                                                <td>14.07.2020</td>
                                                <td>-</td>
                                                <td><a href="pdf/proxima-ii/notification/Proxima_II_Ad_16x25_cm_Hindi DJ,JS.PDF" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card wow animate__ animate__fadeInUp">
                    <div class="card-head" id="headingTwo">
                        <h2 class="mb-0 collapsed show-more" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                             <b>Draw List</b> <span class="halvar_rg text show-more-height"></span>
                        </h2>
                    </div>
                
                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="notificationtable draw-list">
                                <div class="searchrow">
                                    <p>Search by Application Number or Applicant Name</p>
                                    <form class="form-inline">
                                        <input class="form-control" type="search" placeholder="Search" aria-label="Search" id="draw-search">
                                        <button class="btn brbtn draw-result" type="button" data-id="proxima_2"><img src="images/icon/Search.svg" alt="btn"/></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="card mb-0 wow animate__ animate__fadeInUp">
                    <div class="card-head" id="headingThree">
                      <h2 class="mb-0 collapsed show-more" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                          <b>Frequently Asked Question</b> <span class="halvar_rg text show-more-height"></span>
                      </h2>
                    </div>
                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                      <div class="card-body pb-0">
                            <div class="accordioninner" id="accordionExamplefaq">
                                <div class="card">
                                    <div class="card-head" id="faq1">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq1" aria-expanded="false" aria-controls="collapsefaq1">
                                              <b>Location  of  the project </b>
                                        </strong>
                                    </div>
                                
                                    <div id="collapsefaq1" class="collapse" aria-labelledby="faq1" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                               <p><strong>Proxima II</strong> Sector-89 (4.73125 acres) , Gurgaon</p>					 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq2">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq2" aria-expanded="false" aria-controls="collapsefaq2">
                                           <b> USP of Project Location </b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq2" class="collapse" aria-labelledby="faq2" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                                <ul>
                                                    <li>Located in Sector-89 Gurgaon</li>
                                                    <li>Located at 60 Meter wide road</li>
                                                    <li>Easy n smooth connectivity from Pataudi road, Dwarka Expressway, NH8. , KMP Expressway & IGI Airport</li>
                                                    <li>1.5 KM from Dwarka expressway</li>
                                                    <li>20 Minutes away from IGI Airport</li>
                                                    <li>Adjacent to Vatika City2 Township, New Gurgaon</li>
                                                    <li>Next to huge commercial hub (Sector-88, Gurgaon)</li>
                                                    <li>Surrounded by big joints like DLF, Bestech, Ashiana, Godrej, Tulip, Vatika, NBCC, SS group etc. </li>
                                                    <li>Educational Institutions like SGT group of Institutes, Yaduvanshi school, Sharda international school, Colonnels public school, underconstruction Gurugram university, within the proximity</li>
                                                    <li>Genesis hospital, Kamla Hospital, Shri Sai Hospital is in close proximity</li>
                                                    <li>Close to Kadipur Industrial area</li>
                                                    <li>5 Minute Drive from NH8.</li>
                                                    <li>AIIMS National cancer Institute, Badsha, Jhajjar(15KM)</li>
                                                    <li>Sultanpur National park (10KM) </li>
                                                    <li>Close proximity to IMT Maneshar(9KM)</li>
                                                    <li>Adjacent to Transport & communication area</li>
                                                    <li>Recreational area like Sultanpur Bird Sanctuary within the proximity</li>
                                                    <li>It is close proximity to existing ICD (Inland container Depots/Dryports)</li>
                                                    <li>Direct connectivity to multi-utility corridor</li>
                                                    <li>Upcoming rapid metro is in close proximity</li>
                                                    <li>Upcoming ISBT is nearby (Kherki Daula)</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>   
                                <div class="card">
                                    <div class="card-head" id="faq3">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq3" aria-expanded="false" aria-controls="collapsefaq3">
                                              <b>Area being offered in Sq.ft.</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq3" class="collapse" aria-labelledby="faq3" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                               <div class="table-responsive">
                                					<table class="table">
                                					    <tr>
                                    					    <th>Category</th>
                                    					    <th>Carpet Area (in Sq. Ft.)</th>
                                					    </tr>
                                					    <tr>
                                					        <td>Type-1/2BHK</td>
                                					        <td>581.396 sqft</td>
                                					    </tr>
                                					    <tr>
                                					        <td>Type-2/2BHK </td>
                                					        <td>588.586 sqft.</td>
                                					    </tr>
                                					    <tr>
                                					        <td>Type-3/2BHK </td>
                                					        <td>598.220 sqft.</td>
                                					    </tr>
                                					    <tr>
                                					        <td>Type-4/2BHK</td>
                                					        <td>590.169 sqft.</td>
                                					    </tr>
                                					    <tr>
                                					        <td>Type-5/2BHK </td>
                                					        <td>588.263 sqft.</td>
                                					    </tr>
                                					    <tr>
                                					        <td>2BHK+STORE</td>
                                					        <td>645.345	ft.</td>
                                					    </tr>
                                					</table>
                                				</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    
                                <div class="card">
                                    <div class="card-head" id="faq4">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq4" aria-expanded="false" aria-controls="collapsefaq4">
                                             <b>Parking type/ area</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq4" class="collapse" aria-labelledby="faq4" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                                <p>Visitor’s Car Parking & Reserved 2 wheeler parking<br>  <strong>Area :</strong> 690no. (2 wheeler parking)</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="card">
                                    <div class="card-head" id="faq5">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq5" aria-expanded="false" aria-controls="collapsefaq5">
                                              <b>Project Area/ No of Flats</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq5" class="collapse" aria-labelledby="faq5" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                                <p>4.73125 acres/690 DU’s</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                               
                                <div class="card">
                                    <div class="card-head" id="faq6">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq6" aria-expanded="false" aria-controls="collapsefaq6">
                                             <b>Commercial</b> 
                                        </strong>
                                    </div>
                                    <div id="collapsefaq6" class="collapse" aria-labelledby="faq6" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                                <p>Plot area -  765.866 sqmt. (4% of plot area)</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq7">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq7" aria-expanded="false" aria-controls="collapsefaq7">
                                            <b>Power backup</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq7" class="collapse" aria-labelledby="faq7" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext"> 
                                                <p>-</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq8">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq8" aria-expanded="false" aria-controls="collapsefaq8">
                                            <b>Creche cum Anganbadi</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq8" class="collapse" aria-labelledby="faq8" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext"> 
                                               <p>Available (2000 sq.ft. each)</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq9">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq9" aria-expanded="false" aria-controls="collapsefaq9">
                                             <b>Community Hall</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq9" class="collapse" aria-labelledby="faq9" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext"> 
                                               <p>Available (2000 sq.ft. each)</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq10">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq10" aria-expanded="false" aria-controls="collapsefaq10">
                                            <b>Lift</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq10" class="collapse" aria-labelledby="faq10" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                                <p>Available</p> 
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq11">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq11" aria-expanded="false" aria-controls="collapsefaq11">
                                            <b>Banking Partner</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq11" class="collapse" aria-labelledby="faq11" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext"> 
                                                <p>HDFC, PNB Housing, IIFL, ICICI, Yes Bank, ICICI HFC</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq12">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq12" aria-expanded="false" aria-controls="collapsefaq12">
                                            <b>Launch Date</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq12" class="collapse" aria-labelledby="faq12" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext"> 
                                                <p>11.Jan.2020</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq13">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq13" aria-expanded="false" aria-controls="collapsefaq13">
                                            <b>Possession Date</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq13" class="collapse" aria-labelledby="faq13" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext"> 
                                                <p>Within four years from approval of building plans or grant of environmental clearance, whichever is later.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq14">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq14" aria-expanded="false" aria-controls="collapsefaq14">
                                            <b>Surrender process</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq14" class="collapse" aria-labelledby="faq14" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext"> 
                                                <p>In case of surrender of flat by a successful applicant, following amount shall be  forfeited in  addition to  Rs. 25,000/- along with applicable taxes/charges/fee etc</p>
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <tr>
                                    					    <th>Particular</th>
                                    					    <th>Amount to be Forfeited</th>
                                					    </tr>
                                					    <tr>
                                					        <td>In case of surrender/cancellation before the commencement of project</td>
                                					        <td>Nil</td>
                                					    </tr>
                                					    <tr>
                                					        <td>Upto 1 year from the date of commencement of project</td>
                                					        <td>1% of the cost of flat</td>
                                					    </tr>
                                					    <tr>
                                					        <td>Upto 2 years from the date of commencement of project</td>
                                					        <td>3% of the cost of flat</td>
                                					    </tr>
                                					    <tr>
                                					        <td>After 2 years from the date of commencement of project</td>
                                					        <td>5% of the cost of flat</td>
                                					    </tr>
                                                    </table>
                                                </div>
                                                <p>Such flats, (after surrender/cancellation) would be  allotted in terms of Haryana Affordable Housing Policy, 2013 as amended up-to-date.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq15">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq15" aria-expanded="false" aria-controls="collapsefaq15">
                                            <b>Penalty Clause</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq15" class="collapse" aria-labelledby="faq15" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext"> 
                                                <p>Any default in payment shall invite penal interest as provided in Rule 15 of the Haryana Real Estate Regulatory Authority, Rules 2017.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq16">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq16" aria-expanded="false" aria-controls="collapsefaq16">
                                            <b>Maintenance</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq16" class="collapse" aria-labelledby="faq16" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext"> 
                                                <p>0 maintenance for 5 years, however operating and running cost has to be paid.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq17">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq17" aria-expanded="false" aria-controls="collapsefaq17">
                                            <b>Which body will oversee the maintenance after possession</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq17" class="collapse" aria-labelledby="faq17" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext"> 
                                                <p>Colonizer will take care of maintenance for 5 years. Post 5 years it will be handed over to RWA.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq18">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq18" aria-expanded="false" aria-controls="collapsefaq18">
                                            <b>FAR</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq18" class="collapse" aria-labelledby="faq18" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                                <p>43530.822 sqmt. (Residential) & 1429.722 sqmt. (Commercial)</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq19">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq19" aria-expanded="false" aria-controls="collapsefaq19">
                                            <b>Open Area</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq19" class="collapse" aria-labelledby="faq19" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                                <p>3121.006 sqmt. (Green Area) </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq20">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq20" aria-expanded="false" aria-controls="collapsefaq20">
                                            <b>Does Haryana Government Sanction this project</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq20" class="collapse" aria-labelledby="faq20" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                                <p>This project is governed by Haryana Affordable Housing Policy, 2013 as amended up-to-date under issued by the Government of Haryana. Competent authority is  the Director, Town and Country Planning.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card">
                                    <div class="card-head" id="faq21">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq21" aria-expanded="false" aria-controls="collapsefaq21">
                                            <b>Nearby Metro Station</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq21" class="collapse" aria-labelledby="faq21" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                               <p>------</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="card mb-0">
                                    <div class="card-head" id="faq22">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq22" aria-expanded="false" aria-controls="collapsefaq22">
                                            <b>Specifications</b>
                                        </strong>
                                    </div>
                                    <div id="collapsefaq22" class="collapse" aria-labelledby="faq22" data-parent="#accordionExamplefaq">
                                        <div class="card-body pb-0">
                                            <div class="accbodyinnertext specetd">
                                               <div class="table-responsive">
                                					<table class="table">
                                					    <tr>
                                    				        <th colspan="2">Drawing / Dining Room </th>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Floor</td>
                                    				        <td>Vitrified Tiles </td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Ceilng </td>
                                    				        <td>Oil Bond Distemper </td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Wall </td>
                                    				        <td>Oil Bond Distemper </td>
                                    				    </tr>
                                					</table>
                                				</div>
                                				<div class="table-responsive">
                                					<table class="table">
                                					    <tr>
                                    				        <th colspan="2">Bed Room</th>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Floor</td>
                                    				        <td>Vitrified Tiles </td>
                                    				    </tr>
                                    				    
                                    				    <tr>
                                    				        <td>Ceilng </td>
                                    				        <td>Oil Bond Distemper </td>
                                    				    </tr>
                                    				    
                                    				    <tr>
                                    				        <td>Wall </td>
                                    				        <td>Oil Bond Distemper </td>
                                    				    </tr>
                                					</table>
                                				</div>
                                				<div class="table-responsive">
                                					<table class="table">
                                					    <tr>
                                    				        <th colspan="2">Kitchen</th>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Floor</td>
                                    				        <td>Vitrified / Ceramic Tiles </td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Wall / Ceiling </td>
                                    				        <td>Oil Bond Distemper </td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Dado</td>
                                    				        <td>Ceramic tiles 600mm above counter </td>
                                    				    </tr>
                                    				    
                                    				     <tr>
                                    				        <td>Counter Top </td>
                                    				        <td>Green Marble / Granite</td>
                                    				    </tr>
                                    				     <tr>
                                    				        <td>Fittings & Fixtures</td>
                                    				        <td>ISI marked CP Fittings & Single drain board sink</td>
                                    				    </tr>
                                					</table>
                                				</div>
                                				<div class="table-responsive">
                                					<table class="table mb-0">
                                					    <tr>
                                    				        <th colspan="2">Balconies</th>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Floor</td>
                                    				        <td>AntiSkid / Matt Finish Ceramic Tiles</td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Railing </td>
                                    				        <td>M S railing with Enamel Paint Finish </td>
                                    				    </tr>
                                					</table>
                                				</div>
                                				<div class="table-responsive">
                                				    <table class="table">
                                				         <tr>
                                    				        <th colspan="2">Toilet & Bath</th>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Floor</td>
                                    				        <td>Anti Skid Ceramic Tiles</td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Wall</td>
                                    				        <td>Ceramic Tiles till 4Feet / 7'-0" feet high &  Oil Bound Distemper Above</td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Ceiling </td>
                                    				        <td>Grid Flase Ceiling </td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Fittings & Fixtures</td>
                                    				        <td>ISI marked CP Fittings ,W.C & Washbasin</td>
                                    				    </tr>
                                				    </table>
                                				</div>
                                				<div class="table-responsive">
                                				    <table class="table">
                                				        <tr>
                                    				        <th colspan="2">Doors & Windows</th>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Internal Doors Frame</td>
                                    				        <td>Hard Wood / Red Merandi </td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Internal Doors Shutter</td>
                                    				        <td>Main Door - Both Side Laminated  Flush Door &  Internal Flush Door with Painted finish on Both Side</td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>External Doors & Windows</td>
                                    				        <td>Aluminium Powder Coated /UPVC  </td>
                                    				    </tr>
                                				    </table>
                                				</div>
                                				<div class="table-responsive">
                                				    <table class="table">
                                				        <tr>
                                    				        <th colspan="2">Electrical</th>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Wiring</td>
                                    				        <td>Copper Electrical Wiring throughout in concealed conduit for light point</td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Switches / Socket</td>
                                    				        <td>ISI Marked Switches & Sockets</td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Terrace </td>
                                    				        <td>Brick Bat Koba or Water Proofing Treatment</td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Structure</td>
                                    				        <td>EarthQuake Resistant RCC Framed Struture as per Sesmic Zone</td>
                                    				    </tr>
                                				    </table>
                                				</div>
                                				<div class="table-responsive">
                                				    <table class="table">
                                				        <tr>
                                    				        <th colspan="2">External Development </th>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Internal Roads </td>
                                    				        <td>Tremix Concrete Road / Interlocking Blocks</td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>Boundary Wall</td>
                                    				        <td>RCC / Brick wall with Plaster & External weather Proof Paint Finish</td>
                                    				    </tr>
                                    				    <tr>
                                    				        <td>External Development</td>
                                    				        <td>Weather Proof Texture Paint in Buildings</td>
                                    				    </tr>
                                				    </table>
                                				</div>
                                				
                                				<strong class="pl-2 mb-4">Landscape features:</strong>
                                				<ul>
                                				    <li>Arrival Court</li>
                                				    <li>Entry/Exit Gates</li>
                                				    <li>Tower/Club Drop Off</li>
                                				    <li>Open Scooter Parking </li>
                                				    <li>Visitors Car Parking</li>
                                				    <li>Pathway/Jogging Track</li>
                                				    <li>Out door Gym</li>
                                				    <li>Kids play area</li>
                                				    <li>Reflexology path</li>
                                				    <li>Sitting under trellis</li>
                                				    <li>Multipurpose Lawn</li>
                                				    <li>Mound with plantation</li>
                                				    <li>Garden Pavilion</li>
                                				    <li>Feature Walls</li>
                                				    <li>Elder’s seating area</li>
                                				    <li>Circular plaza</li>
                                				    <li>Central Lawn</li>
                                				    <li>Boundary Plantation</li>
                                				</ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </div>
    <!--Accordion Notification-->
    
    <!--CIN no-->
    <div class="footerpagetop">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        <span> Signature Infrabuild Private Limited. CIN - U70100DL2013PTC247676, 1309, UNIT NO. 1310 AT 13TH FLOOR DR.GOPAL DAS BHAWAN, 28  BARAKHAMBA ROAD NEW DELHI Central Delhi DL 110001 IN</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--CIN no-->

	<div class="footerpagetop">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        <strong>Disclaimer</strong>
                      	<p>Promoter urges every applicant to inspect the project site and shall not merely rely upon any architectural impression, plan or sales brochure and, therefore, requests to make personal judgment prior to submitting an application for allotment. Unless otherwise stated, all the images, visuals, materials and information contained herein are purely creative/artistic and may not be actual representations of the product and/or any amenities. Further, the actual design may vary in the fit and finished form, from the one displayed above. Journey time shown, if any, is based upon Google Maps which may vary as per the traffic at a relevant point of time.. *Rate mentioned above does not include GST and other statutory charges, if applicable. T & C Apply. 1 sq. mt. = 10.7639 sq. ft.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

<!--Footer-->
    <footer class="footerbg padd100">
       <div class="width100">
            <div class="container">
                <div class="row paddb60">
                   <div class="col-12">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt m-0 wow animate__ animate__fadeInUp">
                                    <strong>SIGNATURE GLOBAL</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/residential/" title="Residentential projects by Signature Global">Residential</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/" title="Commercial projects by Signature Global">Commercial</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/">Retail</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class=" footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>OUR PRESENCE</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/commercial/society-shops/gurugram/" title="Signature Global in Gurugram">Gurugram</a></li>
                                        <li><a href="https://www.signatureglobal.in/residential/plots/karnal" title="Signature Global in Karnal">Karnal</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/ghaziabad" title="Signature Global in Ghaziabad">Ghaziabad</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>ABOUT US</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" title="Signature Global - Chairman's message" class="scdown">Chairman’s Message</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" title="Signature Global - Board of Director" class="scdown">Board of Directors</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" title="Signature Global - Key Managerial Positions" class="scdown">Key Managerial Positions</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" title="Our Architect" class="scdown">Our Architects</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" title="Signature Global - Vission & Mission of Signature Global" class="scdown">Vision & Mission</a></li>
                                    <!--    <li><a href="signature-global-foundation.php" title="Signature Global Foundation">Signature Global Foundation</a></li>-->
                                    </ul>
                                </div>
                           </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>CAREERS</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/career.php#as-associate" title="Careers at Signature Global">As Associate</a></li>
                                        <li><a href="https://www.signatureglobal.in/career.php#life-signature" title="Life At Signature Global">Life @ Signature Global </a></li>
                                        <li><a href="#"></a></li>
                                    </ul>
                                </div>
                              
                                <div class="footernav halvar_lt wow animate__ animate__fadeInUp publicnoticehome">
                                  <ul>
                                    <li><a href="https://www.signatureglobal.in/public-notice.php" title="Signature Global Public Notice"><strong>Public Notice</strong></a></li>
                                  </ul>                                  
                             	</div>
                                          
                           </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong style="margin-bottom: 15px;">GALLERY</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/gallery.php" title="Signature Global Gallery">Picture Library</a></li>
                                        <li><a href="https://www.signatureglobal.in/video-gallery.php" title="Signature Global Video Gallery">Video Library</a></li>
                                    </ul>
                                </div>   
                            </div>
                           <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/media.php" title="Signature Global Blogs">MEDIA</a></strong> 
                                    <ul>
                                     <li><a href="https://www.signatureglobal.in/media-coverage.php" title="Signature Global Gallery">Media Coverage</a></li>
                                        <!--<li><a href="https://www.signatureglobal.in/press-release.php" title="Signature Global Video Gallery">Press Release</a></li> -->
                                         <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Gallery">Press Kit</a></li>
                                        <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Video Gallery">Media Contact</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                   <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/blog" title="Signature Global Blogs">Blog</a></strong>
                                <!--    <strong class="mb-2"><a class="clrwh opctext" href="https://online.anyflip.com/dhkmm/nalj/mobile/index.html" target="_blank" title="Signature Global Newsletter ">NEWSLETTER</a></strong> -->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/home-loans.php" title="Signature Global - Home Loans">Home Loans</a></strong>
                                  <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/pay-online.php" title="Signature Global - APPLY ONLINE">PAY ONLINE</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/award.php" title="Signature Global Certificates">AWARD</a></strong>                                  
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                 <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" target="_blank" title="Signature Global Login">MBDA/BDA Login</a></strong>
                                   <!-- <strong class="mb-2"><a class="clrwh opctext" href="http://signatureglobal04.realboost.in/add_appointment.aspx" target="_blank" title="Signature Global Appointments">Appointment</a></strong>-->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/terms-of-appointment.php" title="Signature Global - Terms of appointment">Terms of Appointment</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/green-development.php" title="Signature Global - Green Development">Green Development</a></strong>
                                </div>     
                            </div>
                        </div>
                        
                   </div>
                </div>
            </div>
        </div>
      
        
        <div class="width100 bordertop padt60 wow animate__ animate__fadeInUp">
            <div class="container">
                <div class="row">    
                    <div class="col-lg-3">
                       <div class="footerlogo wow animate__ animate__fadeInUp">
                           <img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/>
                       </div> 
                    </div>
                    <div class="col-lg-4">
                        <div class="footernav pl-65 wow animate__ animate__fadeInUp">
                            <strong>REGISTERED OFFICE</strong>
                            <p>13<sup>th</sup> Floor, Dr. Gopal Das Bhawan, 28<br class="ftmb"/> Barakhamba Road, Connaught Place,<br class="ftmb"/> New Delhi 110 001, India.</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Registered Office: +91 11 4928 1700</a>
                        </div>
                    </div>
                    <div class="col-lg-3 pl-00">
                        <div class="footernav wow animate__ animate__fadeInUp">
                            <strong>CORPORATE OFFICE</strong>
                            <p>Unit No.101, Ground Floor, Tower-A,<br class="ftmb"/>Signature Tower South City-1, Gurugram,<br class="ftmb"/>Haryana 122 001, India</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Corporate Office: +91 124 4398 011</a>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="footermedianav mtopft wow animate__ animate__fadeInUp">
                            <strong>FOLLOW US</strong>
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </footer>
     <!--policytab-->
     <div class="policywraper">
         <div class="container">
             <div class="row">
                 <div class="col-lg-10 col-md-10">
                     <div class="policylink text-left">
                        <p>© 2023 Signature Global. All Rights Reserved <br class="mobhidebr"/><span class="clrwh mobhide">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/advertising-policy-for-channel-partners.php"  >Advertising Policy For Channel Partners</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/privacy-policy.php" title="Signature Global - Privacy Policy">Privacy Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/social-media-policy.php" title="Signature Global - Social Media Policy">Social Media Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/generic-faqs-for-haryana-affordable-housing-policy.php">Generic Faq's</a>                        
                       </p>
                       
                     </div>
                  
                 </div>
             <!--     <div class="col-lg-2 col-md-2 cclogo ">
                     <img src="https://www.signatureglobal.in/images/cogdigital.svg" alt="" width="15">
                   </div> -->
             </div>
         </div>
     </div>
   
    <script>
         $.urlParam = function (name) {
            var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);
            return (results !== null) ? results[1] || 0 : false;
            }
            
            var utmSource = $.urlParam('utm_source') ? $.urlParam('utm_source') : 'direct';
            var utmMedium = $.urlParam('utm_medium') ? $.urlParam('utm_medium') : '';
            var utmCampaign = $.urlParam('utm_campaign') ? $.urlParam('utm_campaign') : '';
            var utmId = $.urlParam('utm_id') ? $.urlParam('utm_id') : '';
             
            var enq_url = new URL("https://enquiry.signatureglobal.in/?projectName=ContactUs&enquiryFrom=Online");
            $(function() {
                    enq_url.searchParams.set('utm_source',utmSource);
                    if(utmMedium!=""){enq_url.searchParams.set('utm_medium',utmMedium);}
                    if(utmCampaign!=""){enq_url.searchParams.set('utm_campaign',utmCampaign);}
                    if(utmId!=""){enq_url.searchParams.set('utm_id',utmId);}
                    
              if($('#main_frame').length > 0)
                    $('#main_frame').attr('src', enq_url)
            
            });

    </script>


<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/animate.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/jquery.fancybox.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/slick.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>


<script src="https://www.signatureglobal.in/js/wow.min.js"></script>
<script src="https://www.signatureglobal.in/js/slick.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.fancybox.min.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.validate.min.js"></script>
<script src="https://www.signatureglobal.in/js/additional-methods.js"></script>
<script src="https://www.signatureglobal.in/js/custom.js"></script> 
<script src="https://www.signatureglobal.in/js/app.js"></script> 
<!-- Start of  Zendesk Widget script -->
<script>
   setTimeout(function(){
      var chatScript = '<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"/>';
      $('body').append(chatScript);
   },  
 5000);
</script>

<script>
  window.addEventListener('load', function() {
    jQuery('body').on('mousedown', '[href*="tel:"]', function() {
      gtag('event', 'phone_call')
    })
    jQuery('body').on('mousedown', '[href*="api.whatsapp.com"]', function() {
      gtag('event', 'whatsapp_click')
    })
    jQuery('body').on('mousedown', '.btnrt:contains(Enquire Now)', function() {
      gtag('event', 'enquire_now')
    })
    jQuery('body').on('mousedown', '.contact100-form-btn:contains(Submit)', function() {
      gtag('event', 'Submit_btn')
    })
  });

</script>
<!--<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"> </script>-->
<!-- End of  Zendesk Widget script -->





 


</body>
</html>
<script>
        $.urlParam = function (name) {
           var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);
        return (results !== null) ? results[1] || 0 : false;
        }
        
        var utmSource = $.urlParam('utm_source') ? $.urlParam('utm_source') : 'direct';
        var utmMedium = $.urlParam('utm_medium') ? $.urlParam('utm_medium') : '';
        var utmCampaign = $.urlParam('utm_campaign') ? $.urlParam('utm_campaign') : '';
        var utmId = $.urlParam('utm_id') ? $.urlParam('utm_id') : '';
         
        var url = new URL("https://enquiry.signatureglobal.in?projectName=Proxima2&enquiryFrom=Online");
        $(function() {
                url.searchParams.set('utm_source',utmSource);
                if(utmMedium!=""){url.searchParams.set('utm_medium',utmMedium);}
                if(utmCampaign!=""){url.searchParams.set('utm_campaign',utmCampaign);}
                if(utmId!=""){url.searchParams.set('utm_id',utmId);}
                $('#abc_frame').attr('src', url)
        
        });
    </script>