<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="facebook-domain-verification" content="zqv18clg4hyd5synd83cbrczwv588t" />
<title> Current job Openings at Signature Global – Top Real Estate Companies</title>
<meta name=description content="Forward your resume to HR to know the current openings in Signature Global. We will get back to you as soon as we find suitable openings." />
<meta name=keywords content="Real Estate Companies, job openings" />
<link rel="canonical" href="https://www.signatureglobal.in/career.php" />
<meta name="robots" content="noodp" />
 

    
  
  
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5S8ZC8X');</script>
<!-- End Google Tag Manager -->
  
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-90138100-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-90138100-1');
</script>
  
  

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-MRPZNF8ZD2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-MRPZNF8ZD2');
</script>
  
<!-- Global site tag (gtag.js) - Google Ads: 962082073 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-962082073"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config','AW-962082073', {'allow_enhanced_conversions':true});
</script>
<script>
  gtag('config', 'AW-962082073/BUgQCILmzakDEJnq4MoD', {
    'phone_conversion_number': '7053-121-121'
  });
</script>
  
  

  
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '359225061117882');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=359225061117882&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<link href=https://www.signatureglobal.in/images/favicon1.png rel="shortcut icon" type=image/x-icon>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/bootstrap.min.css"/>
<link  rel="stylesheet"  href="https://www.signatureglobal.in/css/fontawesome/css/all.min.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/style.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/responsive.css"/>
<script src="https://www.signatureglobal.in/js/jquery.min.js"></script>
<script  src="https://www.signatureglobal.in/js/bootstrap.min.js"></script>
<style>
  .shhhow{display:block !important; opacity:1 !important;}
  }
</style>

</head>
<body>
  <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5S8ZC8X"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

        
    <header class="header-area">
        <div class="overlayhd"></div>
        <nav class="navbar navbar-expand-md navbar-dark">
            <div class="container">
                <a href="https://www.signatureglobal.in/" class="navbar-brand"><img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/></a> 
                <div class="mobiconbtn">
                    <a href="tel:+91-7053121121">
                        <svg id="Layer_4" data-name="Layer 4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><circle class="cls-1 cls2" cx="75" cy="75" r="73.55"/><path d="M54.68,41.25,50,41a5.64,5.64,0,0,0-4,1.36c-2.25,2-5.86,5.76-7,10.69-1.66,7.37.9,16.39,7.51,25.4S65.5,101.9,87.29,108.06c7,2,12.55.65,16.81-2.08a15,15,0,0,0,6.54-9.54l.75-3.47a2.43,2.43,0,0,0-1.35-2.7L94.3,83a2.41,2.41,0,0,0-2.92.71l-6.18,8a1.78,1.78,0,0,1-2,.6C79,90.85,64.81,84.91,57,69.93a1.77,1.77,0,0,1,.23-2l5.9-6.83a2.41,2.41,0,0,0,.39-2.53L56.77,42.71A2.42,2.42,0,0,0,54.68,41.25Z"/></svg>
                    </a>
                    <a id="forother" href="https://api.whatsapp.com/send?phone=%2B917303918365&text=Hii%2C+I+am+interested+in+Signature%20Global+Affordable+Housing">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>
                  	<a id="forwhatsapp" href="https://api.whatsapp.com/send?phone=919311144622&amp;text=">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>	
                  
                </div>
                <button type="button" class="navbar-toggler collapsed" data-target="#main-nav">
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                </button>                
                <div id="main-nav" class="navbar-collapse">
                    <div class="topnavbaxy">
                        <ul class="navbar-nav width100 dlfx">                         
                         <!--   <li><a href="career.php" class="nav-link" title="Signature Global - Carrer">Career </a></li> -->
                            <li class="dropdown loginpage">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">LOGIN <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://signatureglobal2.my.salesforce-sites.com/sg?cpForm=true" class="assreg" target="_blank">Associate Registration</a></li>
                                     <li><a href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" class="assreg" target="_blank">MBDA/BDA Login</a></li>
                                     <li><a href="https://app.hrone.cloud/login" class="assreg assreg1" target="_blank">Employee Login</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                        <!--    <li><a href="pay-online.php" class="nav-link" title="Signature Global  - Pay Online">APPLY ONLINE</a></li>-->
                            <li><a href="https://www.signatureglobal.in/investor.php" class="nav-link" title="Signature Global  - Investor">Investor</a></li> 
                            <li><a href="https://www.signatureglobal.in/customer_support.php" class="nav-link" title="Signature Global  - Custome Support">Customer Support </a></li>                         
                   <!--      <li><a href="pdf/SG_Mobile_App_User_Manual.pdf" class="nav-link" target="_blank">Mobile app User Manual</a></li>-->
                         <li><a href="https://www.signatureglobal.in/signature-global-foundation.php" class="nav-link" target="_blank">Signature Global Foundation</a></li>                        
                        </ul>
                    </div>                     
                    <ul class="navbar-nav width100 dlfx ">
                   <!--     <li class="nav-item">
                          <a href="about-us.php" class="nav-link" title="Signature Global  - About Us">About US </a>
                          
                      </li>-->
                      
                       <li class="nav-item dropdown loginpage position-relative">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">About US <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#companyjourney" class="assreg scdown"> Company's Journey</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" class="assreg scdown" >Chairman's Message</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" class="assreg scdown" >Board of Directors</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" class="assreg scdown">Key Managerial Positions</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" class="assreg scdown" >Our Architects</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" class="assreg scdown">Vision & Mission</a></li>
                                     <li><a href="https://www.signatureglobal.in/career.php#life-signature" class="assreg" target="_blank"> Life @ Signature Global</a></li>
                                     <li><a href="https://www.signatureglobal.in/green-development.php" class="assreg assreg1" target="_blank">Green Development</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                      
                        <li class="nav-item dropdown">
                            <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">RESIDENTIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                            <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-5">
                                                <strong>Residential</strong>
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/residential/affordable/">Affordable Group Housing</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/premium/">Premium Independent Floors</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/plots/">Residential Plots</a></li>
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div> 
                                            </div>
                                            <div class="col-lg-8 col-md-7">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5 col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Residential</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/residential/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_6" data-name="Layer 6"><g id="Layer_1-6" data-name="Layer 6"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Resdential-nvbg.jpg" alt="Residential Projects by Signature Global
" title="Residential Projects by Signature Global
">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item dropdown">
                          <a href="#" title="Commercial projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">COMMERCIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                          <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-6 ">
                                                <strong>Commercial</strong>
                                    
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/commercial/society-shops/">Society Shops</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/malls/">Mall</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/sco-plots/">SCO</a></li> 
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-lg-8 col-md-6 ">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5  col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Commercial</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/commercial/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_7" data-name="Layer 7"><g id="Layer_1-7" data-name="Layer 7"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Commercial-nvbg.jpg" alt="Commercial Projects by Signature Global" title="Commercial Projects by Signature Global">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item"><a title="Signature Global  - Contact Us" href="https://www.signatureglobal.in/contact.php" class="nav-link">CONTACT US </a></li>
                    </ul>
                    <div class="bottommediamobwrap">
                        <ul class="pplink">
                            <li><a href="https://www.signatureglobal.in/privacy-policy.php">Privacy Policy</a></li>
                          <li><span>|</span></li>
                            <li><a href="https://www.signatureglobal.in/social-media-policy.php">Social Media Policy</a></li>
                        </ul>
                        <div class="footermedianav mtopft">
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <div class="overlaymobbg"></div>    
    <!--Enquire Now Iframe-->
    <div class="registerform">
        <div class="fixedbtn">
            <span class="btnrt">Enquire Now</span>
        </div>
        <div class="innerform">
            <iframe  frameborder="0" width="100%" height="400px" id="main_frame"></iframe>
        </div>
    </div>
    <!--Enquire Now Iframe-->

    <!--banner section-->
    <div class="banner career-banner padd100">
        <div class="overlay"></div>
        
        <div class="container">
            <div class="row">          
               <div class="col-lg-12">
                    <div class="bannertext wow animate__ animate__fadeInUp" >
                        <div>
                        <h1 class="cr-title">Let's Explore Life<br>  at Signature Global</h1>
                        </div>
                    </div>
               </div>
                
            </div>
        </div>
    </div>
    <!--banner-->
    
    
<section class="lets-gro pad120" id="as-associate">
    <div class="container">
    <div class="row">
          <div class="col-lg-6 col-md-12">
              <h5 class="wow animate__ animate__fadeInUp" >Let's grow<br>
together</h5>
              
          </div>
              
            <div class="col-lg-6 col-md-12">
              <p class="wow animate__ animate__fadeInUp" >We would like to extend a sincere invitation to all the associates to join our
network. We ensure them an excellent environment to excel and to be a part of
the growing fraternity of the Global Real Estate Industry. fill in the
subsequent form for any query on joining our network. </p>
              
          </div>
          
          <div class="col-md-12">
              <div class="career-slider">
                 <div class="lets-thumb">
                      <img src="images/Life-at-Signature-Global-1.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                 <div class="lets-thumb">
                      <img src="images/Life-at-Signature-Global-2.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                 <div class="lets-thumb">
                      <img src="images/Life-at-Signature-Global-3.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                 <div class="lets-thumb">
                      <img src="images/Life-at-Signature-Global-4.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                 <div class="lets-thumb">
                      <img src="images/Life-at-Signature-Global-5.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                 <div class="lets-thumb">
                      <img src="images/Life-at-Signature-Global-6.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                 <div class="lets-thumb">
                      <img src="images/Life-at-Signature-Global-7.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                 <div class="lets-thumb">
                      <img src="images/Life-at-Signature-Global-8.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                 <div class="lets-thumb">
                      <img src="images/Life-at-Signature-Global-9.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                 <div class="lets-thumb">
                      <img src="images/Life-at-Signature-Global-10.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                 <div class="lets-thumb">
                      <img src="images/Life-at-Signature-Global-11.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                <div class="lets-thumb">
                      <img src="images/Life-at-Signature-Global-12.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                  <div class="lets-thumb">
                      <img src="images/lets1.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                  
                  <div class="lets-thumb">
                      <img src="images/lets2.jpg" class="w-100" alt="Signature Global - christmas celebration" title="Signature Global - christmas celebration">
                  </div>
                  
                  
                  <div class="lets-thumb">
                      <img src="images/lets3.jpg" class="w-100" alt="Signature Global - Sports Day" title="Signature Global - Sports Day">
                  </div>
                  
                  <div class="lets-thumb">
                      <img src="images/lets4.jpg" class="w-100" alt="Signature Global - Celebration" title="Signature Global - Celebration">
                  </div>
                  
                  <div class="lets-thumb">
                      <img src="images/lets5.jpg" class="w-100" alt="Signature Global - Women's Day" title="Signature Global - Women's Day">
                  </div>
                  
                  
                  <div class="lets-thumb">
                      <img src="images/lets6.jpg" class="w-100" alt="Signature Global - Workers" title="Signature Global - Workers">
                  </div>
              
              
              
              </div><!--careerslider-->
          </div>
                  
             
        </div>
        </div>
       
     
</section>

<section class="life-sec pad120 pb-0 " id="life-signature">
    <div class="container">
    <div class="row">
          <div class="col-md-12">
              <h5 class="headingtag fcolordrk wow animate__ animate__fadeInUp" > Life @ Signature Global
</h5>

<p class="wow animate__ animate__fadeInUp" >One of the greatest priorities of Signature Global is to promote and nurture talent. For energetic and brilliant professionals who share our zeal for ceaseless advancement and growth, there are several lucrative yet challenging opportunities in every imaginable facet of the Real Estate business. From architecture to design; electrical, structural and civil engineering and in non-technical divisions like marketing and sales – opportunities are endless.</p>

<p class="mt-4 wow animate__ animate__fadeInUp" >As such we expect our present and future employees to nurture the dream of constructing such magnificent edifices that would make Signature Global a brand at par with the giants in the Real Estate arena.
</p>

<p class="mt-4 wow animate__ animate__fadeInUp">As a company we treat all our human resources with the utmost dignity and respect and place a premium on their professional development and personal growth. In order to actualize this goal we conduct regular and in-depth training to enable our employees become experts in the various aspects of modern construction and real estate development practices.</p>

<p class="mt-4 mb-4 wow animate__ animate__fadeInUp" >Therefore, if you have the talent and the all-important zeal and energy to make it big in this exciting and challenging world of Real Estate, Signature Global is the place for you. We invite you to join us, in building brick by brick, the new face of India.
</p>
              
          </div>
          
          
          <div class="col-md-4 mt-4">
              <div class="video-thumb">
                  <iframe width="100%" height="250" src="https://www.youtube.com/embed/vFJFli6hzew" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
          </div>
          
          <div class="col-md-4 mt-4">
              <div class="video-thumb">
                  <iframe width="100%" height="250" src="https://www.youtube.com/embed/Dg3fMVL6vrc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
          </div>
          
          <div class="col-md-4 mt-4">
              <div class="video-thumb">
                  <iframe width="100%" height="250" src="https://www.youtube.com/embed/SEndcXDNqAI" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
          </div>
          
          
          <div class="col-md-4 mt-4">
              <div class="video-thumb">
                  <iframe width="100%" height="250" src="https://www.youtube.com/embed/P7w6YOvLq1Q" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
          </div>
          
          <div class="col-md-4 mt-4">
              <div class="video-thumb">
                  <iframe width="100%" height="250" src="https://www.youtube.com/embed/sYSbRPoq1Kk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
          </div>
          
    <!--       <div class="col-md-4 mt-4">
              <div class="video-thumb">
                  <iframe width="100%" height="250" src="https://www.youtube.com/embed/5yHJXGqlJUg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
          </div> -->
          <div class="col-md-4 mt-4">
              <div class="video-thumb">
                  <iframe width="100%" height="250" src="https://www.youtube.com/embed/_M3lB_nmqFo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
          </div>
      
          <span class="col-md-12 extra-content displaynone">
              <div class="row">
          
          
           <div class="col-md-4 mt-4 ">
              <div class="video-thumb">
                  <iframe width="100%" height="250" src="https://www.youtube.com/embed/Nri4znduF0Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </div>
          </div>
          </div>
          </span>
          <div class="btnwrapone mt-5">
            <a href="javascript:void(0)" id="readmore-btn">
               <span> SHOW MORE</span>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{fill:none;stroke:#203d3b;stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
            </a>
        </div>
        
         

           </div>
        </div>
        
       
     
</section>

<div class="customerwrap padd100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h5 class="headingtag fcolordrk wow animate__ animate__fadeInUp" >Current Openings</h5>
                    
                         <div class="accordioninner" id="accordionExamplefaq">
                                 <div class="card">
                                    <div class="card-head" id="faq1">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq1" aria-expanded="false" aria-controls="collapsefaq1">
                                              <b>Executive Accounts </b>
                                        </strong>
                                    </div>
                                
                                    <div id="collapsefaq1" class="collapse" aria-labelledby="faq1" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                               <h6>Roles and Responsibilities</h6> 
                                                <ul>
                                                    <li>Prepare accurate, timely financial statements in accordance with our established schedule and with input from the rest of the accounting department, Manage all accounting transactions.</li>
                                                    <li>Conduct monthly and quarterly account reconciliations to ensure accurate reporting and ledger maintenance, Prepare budget forecasts.</li>
                                                    <li>Analyze financial statements for discrepancies and other issues that should be brought to the Managements attention.</li>
                                                    <li>Review all inter-company transactions and generate invoices as necessary.</li>
                                                    <li>Reconcile balance sheet accounts.</li>
                                                    <li>Conduct regular ledger maintenance.</li>
                                                    <li>Reinforce financial data confidentiality and conduct database backups when necessary.</li>
                                                    <li>Responsible for all statutory compliances like GST, TDS, Professional Tax, and PF working of GST, TDS and filling of Return on due dates of all Statutory compliances.</li>
                                                    <li>Statutory Compliances and Timely Closure of Statutory Audit.</li>
                                                    <li>Resolving Audit Queries & finalizing the books of accounts.</li>
                                                    <li>Finalization of Individual Accounts, preparing Computation of Income Tax return.</li>
                                                    <li>Preparing Monthly and periodical Financial MIS.</li>

                                              </ul>
                                              
                                              <h6 >Eligibility</h6>
                                              <ul>
                                                   <li>Must have experience with Real estate – project accounting.</li>
                                                    <li>Strong interpersonal skills and the ability to build relationships with staff, internal partners and external vendors.</li>
                                                    <li>Ability to work with broad range of people.</li>
                                                    <li>Ability to work independently and with professional discretion.</li>
                                                    <li>Proficiency in Farvision / SAP.</li>  

                                              </ul>
                                              
                                              <p class="my-4">Interested candidate can email CV at <a href="mailto:hr@signatureglobal.in">hr@signatureglobal.in</a></p>
                                             <p>Role: Accounts Executive<br>
                                                Location : Gurgaon<br>
                                                Experience : minimum 3 year with Real estate industry. <br>
                                                Industry Type  : Real Estate.<br>
                                                Functional Area  : Finance & Accounting.<br>
                                                Employment Type  : Full Time, Permanent.<br>
                                                Role Category  : Accounting & Taxation.<br>
                                                Education  : Commerce Graduate.<br> 
</p>
                                            
                                            </div>
                                        </div>
                                    </div>
                                </div><!--card-->
                                
                                <div class="card">
                                    <div class="card-head" id="faq2">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq2" aria-expanded="false" aria-controls="collapsefaq2">
                                              <b>Front Office Executive  </b>
                                             
                                        </strong>
                                    </div>
                                
                                    <div id="collapsefaq2" class="collapse" aria-labelledby="faq2" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                               
                                               <h6 class="mt-4">Roles and Responsibilities</h6>
                                               <ul>
                                                    <li>Front office management.</li>  
                                                    <li>Guest & visitors / client Management.</li>
                                                    <li>Handling guest request at the desk and resolving the complaints and queries of walk-in customers.</li>
                                                    <li>Coordinating with all the departments.</li>
                                                    <li>Co-coordinating in the Event Management activities.</li>
                                                    <li>Co-coordinating in the arrangement of Conference & meeting activities.</li>
                                                    <li>Should have a clear customer focus (internal and external).</li>  
                                                  </ul>
                                                  <h6>Skill Set</h6>
                                                  <ul>
                                                        <li>Experience in handling Customers.</li>
                                                        <li>Fluency in English and Hindi.</li>
                                                        <li>Good receptive & hospitality management skills.</li>
                                                        <li>Strong interpersonal and organizational skills.</li> 
                                                        <li>Familiar with all MS office applications.</li> 
                                                        <li>Highly groomed, presentable and sophisticated personality to handle customers and guest.</li> 

                                                  </ul>
                                                  
                                                  <p class="mt-4">Interested candidate can email CV at <a href="mailto:hr@signatureglobal.in">hr@signatureglobal.in</a></p>
                                                  <h6>Candidate Profile</h6>
                                                  <ul>
                                                      <li>Graduation from reputed University/Institutes.</li> 
                                                    <li>	3-10 years of Corporate experience preferably.</li> 
                                                    <li>	Candidates with exposure and work experience in Hospitality/Real – Estate/ Banking companies will be preferred.</li>
                                                    <li>	Strong Communication skills (written & verbal), presentation skills and client relationship management are a must for this position.</li>
                                                    <li>	Proficiency in MS Office.</li>

                                                  </ul>
                                                  <p class="mt-4">Role: Front Office  Executive<br>
                                                    Location : Gurgaon<br>
                                                    Experience : minimum 3 year<br>
                                                    Industry Type  : Real Estate / Hospitality / Airlines <br>
                                                    Functional Area  : Front office<br> 
                                                    Employment Type  : Full Time, Permanent<br>
                                                    Role Category  : Front office <br>
                                                    Education  : Graduate  <br>
                                                    </p>
                                            
                                            </div>
                                        </div>
                                    </div>
                                </div><!--card-->
                                
                                
                                <div class="card">
                                    <div class="card-head" id="faq3">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq3" aria-expanded="false" aria-controls="collapsefaq3">
                                              <b>Customer Executive </b>
                                             
                                        </strong>
                                    </div>
                                
                                    <div id="collapsefaq3" class="collapse" aria-labelledby="faq3" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                              
                                              <h6 class="mt-4">Roles and Responsibilities</h6>
                                              <ul>
                                                  <li>Answer inbound and outbound calls professionally and provide required solutions. </li>
<li>Keep records of the customer interaction and transactions.  </li>
<li>Follow up to ensure appropriate actions are taken on customer request.</li> 
<li>Go the extra mile to engage customers in solving issues and ensure satisfaction.</li>
<li>Quickly and effectively build rapport with customers, diagnose and resolve issues.</li>
<li>Should have the ability to provide an overall excellent customer experience.</li>
<li>Managing customer expectations regarding estimated response times.</li>
<li>Take ownership of customer issues:</li>
<li>Escalate unresolved issues to the appropriate internal teams.</li>
<li>Team work.</li>

                                              </ul>
                                              <h6>Skill Set</h6>
                                              <ul>
                                                  <li>Experience in handling Customers.</li>	
                                                <li>Fluency in English and Hindi.</li>
                                                <li>Excellent judgment skills to be able to properly evaluate situations and immediately provide
                                                effective solutions.</li>
                                                <li>The ability to learn new skills and quickly absorb and interpret new information, products, and 
                                                features from the perspective of the customer.</li>
                                                <li>Excellent communication skills and high emotional intelligence.</li>
                                                <li>Excellent problem solving and customer service skills.</li>
                                                <li>Strong analytical & Interpersonal skills.</li>
                                                <li>The ability to be a self-starter, a sense of urgency, and the ability to remain calm under pressure.</li>
                                                <li>Computer savvy.</li>

                                              </ul>
                                              <p class="mt-4">Interested candidate can email CV at <a href="mailto:hr@signatureglobal.in">hr@signatureglobal.in</a></p>
                                                  <h6>Candidate Profile</h6>
                                                  <ul>
                                                      <li>Graduation from reputed University/Institutes.</li> 
                                                    <li>	6 months - 4 years of customer service experience preferably from Voice process .</li> 
                                                    <li>	Candidates with exposure and work experience in Hospitality/Real – Estate/ Banking companies will be preferred.</li>
                                                    <li>	Strong Communication skills (written & verbal), presentation skills and client relationship 
                                                    management are a must for this position. 
                                                    </li>
                                                    <li>	Proficiency in MS Office.</li>

                                                  </ul>
                                                  <p class="mt-4">Role: CRM<br>
                                                    Location : Gurgaon<br>
                                                    Experience : Minimum 3 year with Real estate industry<br> 
                                                    Industry Type  : Real Estate<br>
                                                    Functional Area  :CRM<br>
                                                    Employment Type  : Full Time, Permanent<br>
                                                    Role Category  : CRM<br>
                                                    Education  : Commerce Graduate  
                                                    </p>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--card-->
                                
                                
                                <div class="card">
                                    <div class="card-head" id="faq4">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq4" aria-expanded="false" aria-controls="collapsefaq4">
                                              <b>Sales Executive </b>
                                             
                                        </strong>
                                    </div>
                                
                                    <div id="collapsefaq4" class="collapse" aria-labelledby="faq4" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                               
                                               <h6 class="mt-4">Roles and Responsibilities</h6>
                                               <ul>
                                                   <li>Responsible for generating sales with existing customers and developing opportunities with new customers and brokers within assigned territory.</li>
                                                   <li>Schedule and conduct weekly sales meetings and achieving targets.</li>
                                                    <li>Liaising between customers and the company for up-to-date status of service, pricing and new project release launches.</li>
                                                    <li>Report on sales activities to senior management.</li>
                                                    <li>Reaching the targets and goals set for your area.</li>
                                                    <li>Establishing, maintaining and expanding your customer base and Broker network.</li> 
                                                    <li>Increasing business opportunities through various routes to market.</li>
                                                    <li>Compiling and analyzing sales figures.</li>
                                                    <li>Collecting customer feedback and market research.</li>
                                                    <li>Keeping up to date with products and competitors.</li>
                                                    <li>Own conveyance is a must.</li>
                                                    <li>Candidates from Real Estate / Insurance / Financial Services industry will be preferred.</li>

                                               </ul>
                                               
                                               <h6>Eligibility</h6>
                                               <ul>
                                                    <li>Age should not be more than 30 years.</li>
                                                    <li>Good communication, presentation and negotiation skills.</li>
                                                    <li>Excellence in sales and marketing with positive attitude and team playing ability.</li>
                                                    <li>A flair for establishing an instant rapport with clients.</li>
                                                    <li>Knowledge of Gurgaon market is mandatory</li>
                                                    <li>Good communication and negotiation skills.</li>

                                               </ul>
                                               <p class="mt-4">Interested candidate can email CV at <a href="mailto:hr@signatureglobal.in">hr@signatureglobal.in</a></p>
                                               <p class="mt-4">
                                                    Role: Sales Executive<br>
                                                    Location : Gurgaon<br>
                                                    Experience : 0-2 years of experience. Fresher can also apply<br> 
                                                    Industry Type : Real Estate<br>
                                                    Functional Area : Sales<br>
                                                    Employment Type : Full Time, Permanent<br>
                                                    Role Category : Sales and Business Development<br>
                                                    Education : MBA

                                               </p>    
                                            </div>
                                        </div>
                                    </div>
                                </div><!--card-->
                                
                                
                                 <div class="card">
                                    <div class="card-head" id="faq5">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq5" aria-expanded="false" aria-controls="collapsefaq5">
                                              <b>Corporate Sales</b>
                                             
                                        </strong>
                                    </div>
                                
                                    <div id="collapsefaq5" class="collapse" aria-labelledby="faq5" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                               
                                               <h6 class="mt-4">Roles and Responsibilities</h6>
                                               <ul>
                                                    <li>	To Establish sales opportunities through networking, building relationships, conducting outdoor activities.</li> 
                                                    <li>	Area Mapping, cold calling, prospecting.</li> 
                                                    <li>	Build corporate database and be responsible for lead generation and deal closure with necessary documentation.</li> 
                                                    <li>	Identify potential opportunities to accelerate business volume.</li>
                                                    <li>	Develop and implement strategies for achieving sales goals. </li>
                                                    <li>	Prepare periodic sales report.</li>
                                                    <li>	Should be able to forecast sales in terms of numbers and revenue.</li>
                                                    <li>	Achieve sales targets through acquisition of new clients and growing business from existing clients.</li> 
                                                    <li>	Identify improvements or new requirements by remaining updated with on industry trends, competitor activities & offerings.</li>
                                                    <li>	Ability to articulate USPs of projects  vis-à-vis competitive offerings.</li> 
                                                    <li>	Ability to make inroads into new corporate accounts and territories.</li>

                                               </ul>
                                               <h6 class="mt-4">Candidate Profile</h6>
                                               <ul>
                                                    <li>	MBA in Marketing preferred along with Graduation from reputed University/Institutes.</li>  
                                                    <li>	6-10 years of Corporate Sales experience.</li>  
                                                    <li>	Candidates with exposure and work experience in Hospitality/Real – Estate/ Banking companies will be preferred.</li> 
                                                    <li>	Strong Communication skills (written & verbal), presentation skills and client relationship management are a must for this position.</li> 
                                                    <li>	Proficiency in MS Office.</li> 

                                               </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--card-->
                                
                                <div class="card">
                                    <div class="card-head" id="faq6">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq6" aria-expanded="false" aria-controls="collapsefaq6">
                                              <b>Site Engineer / Sr. Site Engineer </b>
                                             
                                        </strong>
                                    </div>
                                
                                    <div id="collapsefaq6" class="collapse" aria-labelledby="faq6" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                               <h6 class="mt-0">Roles and Responsibilities</h6> 
                                               <ul>
                                                    <li>	Coordination between all working agencies on the project.</li>
                                                    <li>	Projections for material procurement for upcoming tasks.</li>
                                                    <li>	Leading and motivating subordinates for timely accomplishments of jobs.</li>
                                                    <li>	Value Engineering inputs to accommodate the project within scheduled budget.</li>
                                                    <li>	Tracking the working agencies on agreed timelines.</li>
                                                    <li>	Maintaining all the Quality and Safety Standards .</li> 
                                                    <li>	Develop tracking charts showing timelines and progress to completion for the project.</li>
                                                    <li>	Ascertain that all civil works are carried out in conformance with the approved construction drawings.</li>
                                                    <li>	Validation of preliminary estimates, cost plans etc. & ability to ensure strict adherence to the agreed budgets.</li>
                                                    <li>	Ability to quickly analyze and act upon project demand.</li>
                                                    <li>	Planning to optimum utilization of the available resources.</li> 

                                               </ul>
                                               <h6 class="mt-4">Desired Candidate Profile</h6>
                                               <ul>
                                                    <li>	4 to 8 Years of experience in construction of High-Rise residential buildings and High-End Villas in Real Estate and Property Development companies of repute.</li>
                                                    <li>	Thorough understanding of construction  techniques.</li>
                                                    <li>	Have good experience of Civil drawing, man power handling, material quality, Site billing, vendor and supplier management.</li>
                                                    <li>	Self motivated with a results driven approach.</li>

                                               </ul>
                                               <p class="mt-4">Interested candidate can email CV at <a href="mailto:hr@signatureglobal.in">hr@signatureglobal.in</a></p>
                                               <p class="mt-4">Role : Site Engineer / Sr. Site Engineer <br>
                                                Industry Type :  Real Estate<br>
                                                Functional Area : Construction<br> 
                                                Employment Type : Full Time, Permanent<br>
                                                Role Category : Civil construction<br> 
                                                Education : UG, B Tech 
                                                
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--card-->
                                
                                
                                <div class="card">
                                    <div class="card-head" id="faq7">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq7" aria-expanded="false" aria-controls="collapsefaq7">
                                              <b>Sr. Manager / Manager- Sales </b>
                                             
                                        </strong>
                                    </div>
                                
                                    <div id="collapsefaq7" class="collapse" aria-labelledby="faq7" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                                
                                               <h6 class="mt-4">Roles and Responsibilities</h6> 
                                               <ul>
                                                    <li>Responsible for generating sales with existing customers and developing opportunities with new customers and brokers within assigned territory.</li>
                                                    <li>	Schedule and conduct weekly sales meetings and achieving targets.</li>
                                                    <li>	Liaising between customers and the company for up-to-date status of service, pricing and new project release launches.</li>
                                                    <li>	Report on sales activities to senior management.</li>
                                                    <li>	Reaching the targets and goals set for your area
                                                    <li>	Establishing, maintaining and expanding your customer base and Broker network.</li> 
                                                    <li>	Increasing business opportunities through various routes to market.</li>
                                                    <li>	Compiling and analyzing sales figures.</li>
                                                    <li>	Collecting customer feedback and market research.</li>
                                                    <li>	Keeping up to date with products and competitors.</li>
                                                    <li>	Own conveyance is a must.</li>
                                                    <li>	Candidates from Real Estate / Insurance / Financial Services industry will be preferred.</li>

                                               </ul>
                                               <h6 class="mt-4">Eligibility</h6>
                                               <ul>
                                                    <li>Age should not be more than 45 years.</li>
                                                    <li>Good experience in Sales with high professionalism.</li>
                                                    <li>Good communication, presentation and negotiation skills.</li>
                                                    <li>Excellence in sales and marketing with positive attitude and team playing ability.</li>
                                                    <li>A flair for establishing an instant rapport with clients.</li>
                                                    <li>Knowledge of Gurgaon market is mandatory.</li>
                                                    <li>Good communication and negotiation skills.</li>

                                               </ul>
                                               <p class="mt-4">Interested candidate can email CV at <a href="mailto:hr@signatureglobal.in">hr@signatureglobal.in</a> </p>
                                                <p class="mt-4">
                                                    Role: Sales Manager<br>
                                                    Location : Gurgaon
                                                    Experience : minimum 3 years with Real estate industry<br> 
                                                    Industry Type  : Real Estate<br>
                                                    Functional Area  : Sales<br>
                                                    Employment Type  : Full Time, Permanent<br>
                                                    Role Category  : Sales and Business Development<br>
                                                    Education  : MBA

                                                </p>
                                            
                                            
                                            </div>
                                        </div>
                                    </div>
                                </div><!--card-->
                                
                                
                                <div class="card">
                                    <div class="card-head" id="faq8">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq8" aria-expanded="false" aria-controls="collapsefaq8">
                                              <b>Sr. Manager / Manager- Accounts ( Chartered Accountant ) </b>
                                             
                                        </strong>
                                    </div>
                                
                                    <div id="collapsefaq8" class="collapse" aria-labelledby="faq8" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                               <h6 class="mt-0">Roles and Responsibilities</h6> 
                                               <ul>
                                                    <li>	Participating in monthly/quarterly/yearly closing activities and preparation of financial statements within timeline.</li>
                                                    <li>	Managing audit team, preparing final deliverable and getting review done from senior(s).</li>
                                                    <li>	Performing detailed process oriented analysis, walk through and test of controls for identification of signification risk and basis on the same embedded in audit software.</li>
                                                    <li>	Preparing internal process or control documents as per the guidelines.</li>
                                                    <li>	Assessing internal control systems and formulating Management Points to highlight the shortcomings with suggestions of Improvements.</li>
                                                    <li>	Making various analyses of financials using different approaches from risk management perspective.</li>
                                                    <li>	Participating in tax audits including assessment.</li>
                                                    <li>	Participating in GST Audits as team participant.</li>
                                                    <li>	Making budgets considering all relevant inputs and variance analysis.</li>

                                               </ul>
                                               
                                               <h6 class="mt-4">Eligibility</h6>
                                               <ul>
                                                    <li>	Must be a CA.</li>
                                                    <li>	Good in presentation/communication skills.</li>
                                                    <li>	Good experience with Balance Sheet and Taxation.</li>
                                                    <li>	Must have experience with Real estate – project accounting.</li>
                                                    <li>	Strong interpersonal skills and the ability to build relationships with staff, internal partners and external vendors.</li>
                                                    <li>	Ability to work with broad range of people.</li>
                                                    <li>	Ability to work independently and with professional discretion.</li>
                                                    <li>	Proficiency in Windows, including MS Word, EXCEL and PowerPoint.</li>

                                               </ul>
                                               
                                               <p class="mt-4">Interested candidate can email CV at <a href="mailto:hr@signatureglobal.in">hr@signatureglobal.in</a></p>
                                               <p>
                                                    Role: Chartered Accountant (CA)<br>
                                                    Location : Gurgaon<br>
                                                    Experience : minimum 5 year with Real estate industry<br>
                                                    Industry Type  : Real Estate<br>
                                                    Functional Area  : Finance & Accounting<br>
                                                    Employment Type  : Full Time, Permanent<br>
                                                    Role Category  : Accounting & Taxation<br>
                                                    Education  : Qualified CA 

                                               </p>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--card-->
                                
                                <div class="card">
                                    <div class="card-head" id="faq9">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq9" aria-expanded="false" aria-controls="collapsefaq9">
                                              <b>CRM (Customer Relationship Manager)</b>
                                             
                                        </strong>
                                    </div>
                                
                                    <div id="collapsefaq9" class="collapse" aria-labelledby="faq9" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                               <h6 class="mt-0">Roles and Responsibilities</h6>
                                               <ul>
                                                    <li>Ensuring execution of all Back office Sales Administration operations like Builder Buyer Agreement, Payment Receipts.</li>
                                                    <li>Handling the bookings, login in CRM.</li>
                                                    <li>Issuing Payment Receipts, demand letters and reminders accordingly.</li>
                                                    <li>Preparing and Issuing Allotment Letters, Buyer s Agreements to the clients.</li>
                                                    <li>Follow- ups for Allotment letters, Buyer s Agreements etc.</li> 
                                                    <li>Preparation of Company MIS & DSR.</li>
                                                    <li>Maintaining Files and Documents Records.</li>
                                                    <li>Handling post sales query through emails and calls.</li>
                                                    <li>Co- ordination with the sales team.</li>
                                                    <li>Formatting & Issuing document to clients (Credit Note, transfer document of Resale, Demand letter & Receipts).</li> 

                                               </ul>
                                               <h6 class="mt-4">Desired Candidate Profile</h6>
                                               <ul>
                                                    <li>Candidate must be presentable and good communication skills.</li>
                                                    <li>Male/ Female both can apply.</li>
                                                    <li>Preferred only Real Estate Industry with the experience of residential/ commercial project.</li>
                                                    <li>Good knowledge of  CRM procedures of real estate.</li>

                                               </ul>
                                               
                                               <p class="mt-4">Interested candidate can email CV at <a href="mailto:hr@signatureglobal.in">hr@signatureglobal.in</a></p>
                                              <p class="mt-4">
                                                    Role: Assistant Manager <br>
                                                    Location: Gurgaon<br>
                                                    Industry Type : Real Estate<br>
                                                    Functional Area : CRM<br>
                                                    Employment Type : Full Time, Permanent<br>
                                                    Role Category : <br>
                                                    Education  : Graduation 

                                              </p>
                                            
                                            </div>
                                        </div>
                                    </div>
                                </div><!--card-->
                                
                                <div class="card">
                                    <div class="card-head" id="faq10">
                                        <strong class="mb-0 collapsed" data-toggle="collapse" data-target="#collapsefaq10" aria-expanded="false" aria-controls="collapsefaq10">
                                              <b>Safety Officer / Safety Engineer </b>
                                             
                                        </strong>
                                    </div>
                                
                                    <div id="collapsefaq10" class="collapse" aria-labelledby="faq10" data-parent="#accordionExamplefaq">
                                        <div class="card-body">
                                            <div class="accbodyinnertext">
                                              
                                               <h6 class="mt-4">Roles and Responsibilities</h6>
                                               <ul>
                                                    <li>	Should have sound knowledge of all safety standards as established by the company.</li>
                                                    <li>	Should monitor and implement all the necessary safety rules at site and work permits necessary.</li>
                                                    <li>	Should collect all safety related documents from site on a weekly basis.</li>
                                                    <li>	Should provide safety training to all staff concerned at site and office.</li>
                                                    <li>	Should check all safety related Ppe and other equipment at site by regular inspections.</li>
                                                    <li>	Must ensure that all necessary display signs are provided for and erected at site.</li>
                                                    <li>	Must ensure that necessary safety parks are established at site and daily training schedules are maintained.</li>
                                                    <li>	Should lead and direct safety teams in managing safety rules and processes at site.</li>
                                                    <li>	Promoting safe practices at site.</li>
                                                    <li>	Creating and enforcing safety guidelines and programs.</li>
                                                    <li>	Conducting investigations on accidents.</li>
                                                    <li>	Verifying that all safety reports are submitted to related government institutions.</li>
                                                    <li>	Responding to workers' safety concerns.</li>
                                                    <li>	Manages all communications with government departments in regards of safety.</li>
                                                    <li>	Coordinates all issues regarding hazardous materials or waste.</li>
                                                    <li>	Assisting with the preparation of a construction health and safety plan.</li>
                                                    <li>	Attending project planning meetings and collaborating with construction managers.</li>
                                                    <li>	Establishing and maintaining health and safety communication structures.</li>
                                                    <li>	Testing effectiveness of site emergency response plans.</li>
                                                    <li>	Continuous monitoring of all safety related documents reports and issues to keep them updated.</li>
                                                    <li>	Conduct HSE induction & Training .</li>
                                                    <li>	HSE site inspection.</li>
                                                    <li>	Preparing HSE Plan and Emergency Response Plan.</li>
                                                    <li>	Ensure that Safe working procedures are being followed.</li>
                                                    <li>	Maintain all HSE related records and paper work.</li>
                                                    <li>	Fire Safety Officer performs regular fire safety inspections of all facilities under their care, ensuring that they meet all necessary codes and regulations.</li>
                                                    <li>	They also respond to fire emergencies and arson crimes, investigating and reporting the causes of fire and taking appropriate responsive actions.</li>
                                                    <li>	Experience with construction industry would be an added advantage.</li>
                                                    <li>	Well versed with BOCW , ISO 140001 & 45001.</li> 
                                                    <li>	Only male candidates will be preferred.</li>

                                               </ul>
                                               
                                               <h6 class="mt-4">Desired Candidate Profile</h6>
                                               <ul>
                                                    <li>4 – 10 Experience in Real Estate.</li> 
                                                    <li>Qualification : BSc. / B.tech.  is mandatory.</li>
                                                    <li>Must have Diploma in Industrial Safety.</li> 
                                                    <li>Proficiency in MS office/ PowerPoint.</li>
                                                    <li>Knowledge of Q- Cop  is added advantage 
                                                    <li>Excellent communication skills Written & Verbal.</li>
                                                    <li>Disciplined, Hard working, committed and genuinely interested in contributing to the efficiency and effectiveness of organization functioning.</li>
                                                    <li>Eager to learn, adaptable and flexible, willing to work with and through others.</li>

                                               </ul>
                                               <h6 class="mt-4">Perks and Benefits</h6>
                                               <ul>
                                                   <p>Role Environment Health and Safety - Other<br>
                                                    Industry Type Real Estate <br>
                                                    Functional Area : Environment Health & Safety<br>
                                                    Employment TypeFull Time, Permanent<br>
                                                    Role CategoryEnvironment Health and Safety – Other<br>
                                                    Location : Gurgaon </p

                                               </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--card-->
                                
                                
                                
                                
                                
                                </div><!--accordioninner-->
                                
                                
                                
                                
                </div>
            </div>
        </div>
    </div>



<!--Footer-->
    <footer class="footerbg padd100">
       <div class="width100">
            <div class="container">
                <div class="row paddb60">
                   <div class="col-12">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt m-0 wow animate__ animate__fadeInUp">
                                    <strong>SIGNATURE GLOBAL</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/residential/" title="Residentential projects by Signature Global">Residential</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/" title="Commercial projects by Signature Global">Commercial</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/">Retail</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class=" footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>OUR PRESENCE</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/commercial/society-shops/gurugram/" title="Signature Global in Gurugram">Gurugram</a></li>
                                        <li><a href="https://www.signatureglobal.in/residential/plots/karnal" title="Signature Global in Karnal">Karnal</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/ghaziabad" title="Signature Global in Ghaziabad">Ghaziabad</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>ABOUT US</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" title="Signature Global - Chairman's message" class="scdown">Chairman’s Message</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" title="Signature Global - Board of Director" class="scdown">Board of Directors</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" title="Signature Global - Key Managerial Positions" class="scdown">Key Managerial Positions</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" title="Our Architect" class="scdown">Our Architects</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" title="Signature Global - Vission & Mission of Signature Global" class="scdown">Vision & Mission</a></li>
                                    <!--    <li><a href="signature-global-foundation.php" title="Signature Global Foundation">Signature Global Foundation</a></li>-->
                                    </ul>
                                </div>
                           </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>CAREERS</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/career.php#as-associate" title="Careers at Signature Global">As Associate</a></li>
                                        <li><a href="https://www.signatureglobal.in/career.php#life-signature" title="Life At Signature Global">Life @ Signature Global </a></li>
                                        <li><a href="#"></a></li>
                                    </ul>
                                </div>
                              
                                <div class="footernav halvar_lt wow animate__ animate__fadeInUp publicnoticehome">
                                  <ul>
                                    <li><a href="https://www.signatureglobal.in/public-notice.php" title="Signature Global Public Notice"><strong>Public Notice</strong></a></li>
                                  </ul>                                  
                             	</div>
                                          
                           </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong style="margin-bottom: 15px;">GALLERY</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/gallery.php" title="Signature Global Gallery">Picture Library</a></li>
                                        <li><a href="https://www.signatureglobal.in/video-gallery.php" title="Signature Global Video Gallery">Video Library</a></li>
                                    </ul>
                                </div>   
                            </div>
                           <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/media.php" title="Signature Global Blogs">MEDIA</a></strong> 
                                    <ul>
                                     <li><a href="https://www.signatureglobal.in/media-coverage.php" title="Signature Global Gallery">Media Coverage</a></li>
                                        <!--<li><a href="https://www.signatureglobal.in/press-release.php" title="Signature Global Video Gallery">Press Release</a></li> -->
                                         <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Gallery">Press Kit</a></li>
                                        <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Video Gallery">Media Contact</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                   <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/blog" title="Signature Global Blogs">Blog</a></strong>
                                <!--    <strong class="mb-2"><a class="clrwh opctext" href="https://online.anyflip.com/dhkmm/nalj/mobile/index.html" target="_blank" title="Signature Global Newsletter ">NEWSLETTER</a></strong> -->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/home-loans.php" title="Signature Global - Home Loans">Home Loans</a></strong>
                                  <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/pay-online.php" title="Signature Global - APPLY ONLINE">PAY ONLINE</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/award.php" title="Signature Global Certificates">AWARD</a></strong>                                  
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                 <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" target="_blank" title="Signature Global Login">MBDA/BDA Login</a></strong>
                                   <!-- <strong class="mb-2"><a class="clrwh opctext" href="http://signatureglobal04.realboost.in/add_appointment.aspx" target="_blank" title="Signature Global Appointments">Appointment</a></strong>-->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/terms-of-appointment.php" title="Signature Global - Terms of appointment">Terms of Appointment</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/green-development.php" title="Signature Global - Green Development">Green Development</a></strong>
                                </div>     
                            </div>
                        </div>
                        
                   </div>
                </div>
            </div>
        </div>
      
        
        <div class="width100 bordertop padt60 wow animate__ animate__fadeInUp">
            <div class="container">
                <div class="row">    
                    <div class="col-lg-3">
                       <div class="footerlogo wow animate__ animate__fadeInUp">
                           <img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/>
                       </div> 
                    </div>
                    <div class="col-lg-4">
                        <div class="footernav pl-65 wow animate__ animate__fadeInUp">
                            <strong>REGISTERED OFFICE</strong>
                            <p>13<sup>th</sup> Floor, Dr. Gopal Das Bhawan, 28<br class="ftmb"/> Barakhamba Road, Connaught Place,<br class="ftmb"/> New Delhi 110 001, India.</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Registered Office: +91 11 4928 1700</a>
                        </div>
                    </div>
                    <div class="col-lg-3 pl-00">
                        <div class="footernav wow animate__ animate__fadeInUp">
                            <strong>CORPORATE OFFICE</strong>
                            <p>Unit No.101, Ground Floor, Tower-A,<br class="ftmb"/>Signature Tower South City-1, Gurugram,<br class="ftmb"/>Haryana 122 001, India</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Corporate Office: +91 124 4398 011</a>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="footermedianav mtopft wow animate__ animate__fadeInUp">
                            <strong>FOLLOW US</strong>
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </footer>
     <!--policytab-->
     <div class="policywraper">
         <div class="container">
             <div class="row">
                 <div class="col-lg-10 col-md-10">
                     <div class="policylink text-left">
                        <p>© 2023 Signature Global. All Rights Reserved <br class="mobhidebr"/><span class="clrwh mobhide">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/advertising-policy-for-channel-partners.php"  >Advertising Policy For Channel Partners</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/privacy-policy.php" title="Signature Global - Privacy Policy">Privacy Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/social-media-policy.php" title="Signature Global - Social Media Policy">Social Media Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/generic-faqs-for-haryana-affordable-housing-policy.php">Generic Faq's</a>                        
                       </p>
                       
                     </div>
                  
                 </div>
             <!--     <div class="col-lg-2 col-md-2 cclogo ">
                     <img src="https://www.signatureglobal.in/images/cogdigital.svg" alt="" width="15">
                   </div> -->
             </div>
         </div>
     </div>
   
    <script>
         $.urlParam = function (name) {
            var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);
            return (results !== null) ? results[1] || 0 : false;
            }
            
            var utmSource = $.urlParam('utm_source') ? $.urlParam('utm_source') : 'direct';
            var utmMedium = $.urlParam('utm_medium') ? $.urlParam('utm_medium') : '';
            var utmCampaign = $.urlParam('utm_campaign') ? $.urlParam('utm_campaign') : '';
            var utmId = $.urlParam('utm_id') ? $.urlParam('utm_id') : '';
             
            var enq_url = new URL("https://enquiry.signatureglobal.in/?projectName=ContactUs&enquiryFrom=Online");
            $(function() {
                    enq_url.searchParams.set('utm_source',utmSource);
                    if(utmMedium!=""){enq_url.searchParams.set('utm_medium',utmMedium);}
                    if(utmCampaign!=""){enq_url.searchParams.set('utm_campaign',utmCampaign);}
                    if(utmId!=""){enq_url.searchParams.set('utm_id',utmId);}
                    
              if($('#main_frame').length > 0)
                    $('#main_frame').attr('src', enq_url)
            
            });

    </script>


<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/animate.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/jquery.fancybox.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/slick.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>


<script src="https://www.signatureglobal.in/js/wow.min.js"></script>
<script src="https://www.signatureglobal.in/js/slick.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.fancybox.min.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.validate.min.js"></script>
<script src="https://www.signatureglobal.in/js/additional-methods.js"></script>
<script src="https://www.signatureglobal.in/js/custom.js"></script> 
<script src="https://www.signatureglobal.in/js/app.js"></script> 
<!-- Start of  Zendesk Widget script -->
<script>
   setTimeout(function(){
      var chatScript = '<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"/>';
      $('body').append(chatScript);
   },  
 5000);
</script>

<script>
  window.addEventListener('load', function() {
    jQuery('body').on('mousedown', '[href*="tel:"]', function() {
      gtag('event', 'phone_call')
    })
    jQuery('body').on('mousedown', '[href*="api.whatsapp.com"]', function() {
      gtag('event', 'whatsapp_click')
    })
    jQuery('body').on('mousedown', '.btnrt:contains(Enquire Now)', function() {
      gtag('event', 'enquire_now')
    })
    jQuery('body').on('mousedown', '.contact100-form-btn:contains(Submit)', function() {
      gtag('event', 'Submit_btn')
    })
  });

</script>
<!--<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"> </script>-->
<!-- End of  Zendesk Widget script -->





 


</body>
</html><script>
 $("input.type-hide").on('change', function() {
        $('span.file-name').empty().text($("#fileUpload").val().replace(/.*(\/|\\)/, ''));
    }); 
    
    $(document).ready(function() {
			$('#readmore-btn').click(function() {
				$('.extra-content').slideToggle();
				if($('#readmore-btn span').text() == 'SHOW LESS') {
					$('#readmore-btn span').text('SHOW MORE');
				} else {
					$('#readmore-btn span').text('SHOW LESS');
				}
			});
		});
</script>