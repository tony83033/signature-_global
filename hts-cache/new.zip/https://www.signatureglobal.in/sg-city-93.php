<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="facebook-domain-verification" content="zqv18clg4hyd5synd83cbrczwv588t" />
<title> Signature Global City 93 | Independent Premium Floors Gurugram</title>
<meta name=description content="Signature Global City 93 is a gem of Independent Premium Floors amidst the high rise buildings in the heart of New Gurugram, located at Sector 93 Gurugram." />
<meta name=keywords content="Signature Global City 93, Independent Premium Floors in Gurugram, 3 BHK Flats in Gurgaon " />
<link rel="canonical" href="https://www.signatureglobal.in/sg-city-93.php" />
<meta name="robots" content="noodp" />
 

    
  
  
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5S8ZC8X');</script>
<!-- End Google Tag Manager -->
  
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-90138100-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-90138100-1');
</script>
  
  

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-MRPZNF8ZD2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-MRPZNF8ZD2');
</script>
  
<!-- Global site tag (gtag.js) - Google Ads: 962082073 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-962082073"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config','AW-962082073', {'allow_enhanced_conversions':true});
</script>
<script>
  gtag('config', 'AW-962082073/BUgQCILmzakDEJnq4MoD', {
    'phone_conversion_number': '7053-121-121'
  });
</script>
  
  

  
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '359225061117882');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=359225061117882&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<link href=https://www.signatureglobal.in/images/favicon1.png rel="shortcut icon" type=image/x-icon>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/bootstrap.min.css"/>
<link  rel="stylesheet"  href="https://www.signatureglobal.in/css/fontawesome/css/all.min.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/style.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/responsive.css"/>
<script src="https://www.signatureglobal.in/js/jquery.min.js"></script>
<script  src="https://www.signatureglobal.in/js/bootstrap.min.js"></script>
<style>
  .shhhow{display:block !important; opacity:1 !important;}
  }
</style>

</head>
<body>
  <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5S8ZC8X"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

        
    <header class="header-area">
        <div class="overlayhd"></div>
        <nav class="navbar navbar-expand-md navbar-dark">
            <div class="container">
                <a href="https://www.signatureglobal.in/" class="navbar-brand"><img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/></a> 
                <div class="mobiconbtn">
                    <a href="tel:+91-7053121121">
                        <svg id="Layer_4" data-name="Layer 4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><circle class="cls-1 cls2" cx="75" cy="75" r="73.55"/><path d="M54.68,41.25,50,41a5.64,5.64,0,0,0-4,1.36c-2.25,2-5.86,5.76-7,10.69-1.66,7.37.9,16.39,7.51,25.4S65.5,101.9,87.29,108.06c7,2,12.55.65,16.81-2.08a15,15,0,0,0,6.54-9.54l.75-3.47a2.43,2.43,0,0,0-1.35-2.7L94.3,83a2.41,2.41,0,0,0-2.92.71l-6.18,8a1.78,1.78,0,0,1-2,.6C79,90.85,64.81,84.91,57,69.93a1.77,1.77,0,0,1,.23-2l5.9-6.83a2.41,2.41,0,0,0,.39-2.53L56.77,42.71A2.42,2.42,0,0,0,54.68,41.25Z"/></svg>
                    </a>
                    <a id="forother" href="https://api.whatsapp.com/send?phone=%2B917303918365&text=Hii%2C+I+am+interested+in+Signature%20Global+Affordable+Housing">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>
                  	<a id="forwhatsapp" href="https://api.whatsapp.com/send?phone=919311144622&amp;text=">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>	
                  
                </div>
                <button type="button" class="navbar-toggler collapsed" data-target="#main-nav">
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                </button>                
                <div id="main-nav" class="navbar-collapse">
                    <div class="topnavbaxy">
                        <ul class="navbar-nav width100 dlfx">                         
                         <!--   <li><a href="career.php" class="nav-link" title="Signature Global - Carrer">Career </a></li> -->
                            <li class="dropdown loginpage">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">LOGIN <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://signatureglobal2.my.salesforce-sites.com/sg?cpForm=true" class="assreg" target="_blank">Associate Registration</a></li>
                                     <li><a href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" class="assreg" target="_blank">MBDA/BDA Login</a></li>
                                     <li><a href="https://app.hrone.cloud/login" class="assreg assreg1" target="_blank">Employee Login</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                        <!--    <li><a href="pay-online.php" class="nav-link" title="Signature Global  - Pay Online">APPLY ONLINE</a></li>-->
                            <li><a href="https://www.signatureglobal.in/investor.php" class="nav-link" title="Signature Global  - Investor">Investor</a></li> 
                            <li><a href="https://www.signatureglobal.in/customer_support.php" class="nav-link" title="Signature Global  - Custome Support">Customer Support </a></li>                         
                   <!--      <li><a href="pdf/SG_Mobile_App_User_Manual.pdf" class="nav-link" target="_blank">Mobile app User Manual</a></li>-->
                         <li><a href="https://www.signatureglobal.in/signature-global-foundation.php" class="nav-link" target="_blank">Signature Global Foundation</a></li>                        
                        </ul>
                    </div>                     
                    <ul class="navbar-nav width100 dlfx ">
                   <!--     <li class="nav-item">
                          <a href="about-us.php" class="nav-link" title="Signature Global  - About Us">About US </a>
                          
                      </li>-->
                      
                       <li class="nav-item dropdown loginpage position-relative">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">About US <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#companyjourney" class="assreg scdown"> Company's Journey</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" class="assreg scdown" >Chairman's Message</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" class="assreg scdown" >Board of Directors</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" class="assreg scdown">Key Managerial Positions</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" class="assreg scdown" >Our Architects</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" class="assreg scdown">Vision & Mission</a></li>
                                     <li><a href="https://www.signatureglobal.in/career.php#life-signature" class="assreg" target="_blank"> Life @ Signature Global</a></li>
                                     <li><a href="https://www.signatureglobal.in/green-development.php" class="assreg assreg1" target="_blank">Green Development</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                      
                        <li class="nav-item dropdown">
                            <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">RESIDENTIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                            <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-5">
                                                <strong>Residential</strong>
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/residential/affordable/">Affordable Group Housing</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/premium/">Premium Independent Floors</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/plots/">Residential Plots</a></li>
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div> 
                                            </div>
                                            <div class="col-lg-8 col-md-7">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5 col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Residential</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/residential/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_6" data-name="Layer 6"><g id="Layer_1-6" data-name="Layer 6"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Resdential-nvbg.jpg" alt="Residential Projects by Signature Global
" title="Residential Projects by Signature Global
">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item dropdown">
                          <a href="#" title="Commercial projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">COMMERCIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                          <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-6 ">
                                                <strong>Commercial</strong>
                                    
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/commercial/society-shops/">Society Shops</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/malls/">Mall</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/sco-plots/">SCO</a></li> 
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-lg-8 col-md-6 ">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5  col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Commercial</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/commercial/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_7" data-name="Layer 7"><g id="Layer_1-7" data-name="Layer 7"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Commercial-nvbg.jpg" alt="Commercial Projects by Signature Global" title="Commercial Projects by Signature Global">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item"><a title="Signature Global  - Contact Us" href="https://www.signatureglobal.in/contact.php" class="nav-link">CONTACT US </a></li>
                    </ul>
                    <div class="bottommediamobwrap">
                        <ul class="pplink">
                            <li><a href="https://www.signatureglobal.in/privacy-policy.php">Privacy Policy</a></li>
                          <li><span>|</span></li>
                            <li><a href="https://www.signatureglobal.in/social-media-policy.php">Social Media Policy</a></li>
                        </ul>
                        <div class="footermedianav mtopft">
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <div class="overlaymobbg"></div>    
<style>
  
  .sgcity93-slider2 .slick-slide{margin:0 !important}
   
  .sgcity-thumb{height:100vh !important;background-size:cover !important;}
.sg93bannercontent{
    position: absolute;
    top: 0;
    width: 100%;
    height: 100%;
}
.projectdetail{
     position: relative;
     background: #6c9392;
}
.project-main-detail{
    margin: 30px 0px;
    position: relative;
    text-align: center;
}
.project-main-detail-line::after{
    content: "";
    position: absolute;
    width: 1px;
    height: 100%;
    right: -15px;
    background: #d6e6e559;
    top:0;
}
.linebtm::after{
    right: 3px;
}
.projectdetail::before{
    content:"";
    position: absolute;
     background: url(images/sgcity93/Left-leaf.png) no-repeat;
     background-size: contain;
     width: 117px;
     height: 175px;
}
.projectdetail::after{
   content: "";
    position: absolute;
    background: url(images/sgcity93/Right-leaf.png) no-repeat;
    background-size: contain;
    width: 109px;
    height: 158px;
    top: 0;
    right: 0;
    transform: rotate(0deg);
}
.project-main-detail  img{
    width: 40px;
}

.project-main-detail p{
   color: #fff;
    font-size: 18px;
    font-weight: 600;
    letter-spacing: 1px;
    margin-top: 6px;
}
.project-main-detail p.box-modern-title{
    font-weight: 400;
    font-size: 22px;
    padding-top: 6px;
    color: #fff;
    letter-spacing: inherit;
    margin-top: 0px;
    text-align: center;
}
.overview-content{
    font-size: 2rem;
}
.designer{
    font-size: 2rem;
    margin-top: 30px;
}
.sgc93-overview{
    background-image: url(images/sgcity93/BG-Double.jpg);
    background-repeat: no-repeat;
    background-size: 100% 100%;
}
.sg93text{
    color: #347640;
}
.sg93text .headingtag{
   font-size: 3rem; 
}
.sg93location{
    background: #78a280 !important;
}
.sgcity93banner .row{
    width: 100%;
}
.sgcity93banner .row p{
    padding: 20px 0px;
    font-size: 26px;
    color: #fff;
    line-height: 25px;
}
.sgcity93banner .cpationlogo{
    bottom: 40px;
}
.aminitysg93 .controlam{
    top: 80px;
}
.desktopshow{
    display: block;
}
.mobshow{
    display: none;
}
.dreamApartment-content {
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}
.dreamApartment-content .dreamimg{
    width: 100%;
}
.dreamapp-content{
    font-size: 2rem;
}
.designerbg{
    background-color: #d6e6e5;
}
@media(max-width: 991px){
    .sgcity93banner .row p{
        font-size: 16px;
    }
    .sgcity93banner .cpationlogo {
    bottom: 18px;
}
.project-main-detail p.box-modern-title{
    font-size: 16px;
}
.projectdetail::before{
    width: 70px;
}
.projectdetail::after{
    width: 66px;
}
.dreamtwo{
    padding-top: 50px;
}
.aminitysg93 .controlam {
    top: 94px;
}
}
@media(max-width: 767px){
    /*.sgcity93banner {background-image: url(images/sgcity93/Banner-Mobile.jpg);}*/
    .desktopshow{
    display: none;
}
.mobshow {
    display: block;
}
.sgcity93banner .row p {
    padding: 1px 0px;
}
.sgcity93banner .cpationlogo {
    bottom: 45px;
}
.textwrap span{
    font-size: 14px;
}
.prl{
    margin-bottom: 5px;
}
.project-main-detail img {
    width: 30px;
}
.dreamApartment-content img{
    width: 100%;
}
.rightline::after, .linebtm::after{
    content: unset;
}
.rightlinetwo::after{
    content: "";
    position: absolute;
    width: 1px;
    height: 100%;
    right: -15px;
    background: #d6e6e559;
    top: 0;
}
.projectdetail::before {
    width: 40px;
}
.projectdetail::after {
    width: 100px;
    bottom: 0;
    top: unset;
    height: 105px;
}
.sgcity93banner .row p {
    font-size: 14px;
}
}
  
 @media(max-width:560px){
   /*.sgmb1{background: url(../images/sgcity93/sgcity93-mob-banner1.jpg) !important}
    .sgmb2{background: url(../images/sgcity93/sgcity93-mbbanner2.jpg) !important}*/
   
   .sgmb1{background: url(images/SG-Web-Banner-400x600-15-aug-01.jpg) !important}
    .sgmb2{background: url(images/SG-Web-Banner-400x600-15-aug-02.jpg) !important}
 } 
</style>
    <!--Download Brochure-->
    <div class="downloadbtnwrap">
        <a href="pdf/Multipager_SG_City_93_28.06.2023.pdf" target="_blank" class="btnrt" alt="">Download Brochure</a>
    </div>
    <!--Download Brochure-->
    <!--Enquire Now Iframe-->
    <div class="registerform">
        <div class="fixedbtn">
            <span class="btnrt">Enquire Now</span>
        </div>
        <div class="innerform">
            <iframe  frameborder="0" width="100%" height="400px" id="abc_frame"></iframe>
        </div>
    </div>
    <!--Enquire Now Iframe-->
    <!--banner section-->
    <div class="banner sgcity93banner padd100">
        
     <div class="videobg desktopshow">
          <video id="videobanner" autoplay loop muted playsinline poster="">
                  <source src="images/sgcity93/sg93banner.m4v" type="video/mp4">
                  <source src="images/sgcity93/sg93banner.ogg" type="video/ogg">
            </video>
        </div>
        <div class="videobg mobshow">
          <video id="videobanner3" autoplay loop muted playsinline poster="">
                  <source src="images/sgcity93/sg93-mob.m4v" type="video/mp4">
                  <source src="images/sgcity93/sg93-mob.ogg" type="video/ogg">
            </video>
        </div>
    <!-- <div class="sgcity93-slider2">
        <div class="sgcity-thumb sgmb1" style="background:url('images/sgcity93/sgcity93-banner1.jpg');background-size:cover;background-position:center center">  
           
        </div>
         <div class="sgcity-thumb sgmb2" style="background:url('images/sgcity93/sgcity93-banner2.jpg');background-size:cover;background-position:center center">       
        </div>
        
        
      </div> -->
    <!--  <div class="sgcity93-slider2">
       		<div class="sgcity-thumb sgmb1" style="background:url('images/SG-Web-Banner-15aug-01.jpg');background-size:cover;background-position:center center"></div>
           	<div class="sgcity-thumb sgmb2" style="background:url('images/SG-Web-Banner-15aug-02.jpg');background-size:cover;background-position:center center"></div>      
        
      </div>-->
      <div class="overlaybottom"></div>
       <div class="sg93bannercontent">
            <div class="container">
            <div class="cpationlogo mb-5">
                <span><img src="images/sgcity93/SG-City-93.svg" alt="Signature Global City 93 logo" /></span>
            </div>
            <div class="row w-100">
                <div class="col-md-4">
                    <p class="price">2BHK @ 91.4 Lakhs Onwards</p>
                </div>
                <div class="col-md-4">
                    <p class="price">3BHK @ 1.11 Cr. Onwards</p>
                </div>
                <div class="col-md-4">
                    <p class="price prl">3BHK + Study @ 1.32 Cr. Onwards</p>
                </div>
            </div>
        </div>
       </div>
        
    </div>
    <!--banner-->
    <!-- <div class="projectdetail">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--             <div class="col-4">-->
    <!--            <div class="project-main-detail project-main-detail-line">-->
    <!--                <img src="images/sgcity93/Parking.svg" alt="">-->
    <!--                <p class="box-modern-title">12 FEET HIGH STILT PARKING</p>-->
                    
    <!--            </div>-->
    <!--            </div>-->
    <!--             <div class="col-4">-->
    <!--            <div class="project-main-detail project-main-detail-line">-->
    <!--                <img src="images/sgcity93/Jogging-track.svg" alt="">-->
    <!--                <p class="box-modern-title">2 KM LONG JOGGING TRACK</p>-->
    <!--            </div>-->
    <!--            </div>-->
    <!--            <div class="col-4">-->
    <!--            <div class="project-main-detail">-->
    <!--                <img src="images/sgcity93/Road.svg" alt="">-->
    <!--                <p class="box-modern-title">2 SIDE 60MTR. WIDE ROAD</p>-->
                    
    <!--            </div>-->
    <!--            </div>-->
               
    <!--            <div class="col-6">-->
    <!--             <div class="project-main-detail project-main-detail-line linebtm mt-0">-->
    <!--                 <img src="images/sgcity93/Terrace-garden.svg" alt="">-->
    <!--                <p class="box-modern-title">TERRACE GARDEN WITH ROOF RIGHTS</p>-->
                
    <!--            </div>-->
    <!--            </div>-->
    <!--            <div class="col-6">-->
    <!--             <div class="project-main-detail mt-0">-->
    <!--                 <img src="images/sgcity93/Home.svg" alt="">-->
    <!--                <p class="box-modern-title">EXTRA SPACE FOR WORK FROM HOME OFFICE</p>-->
                
    <!--            </div>-->
    <!--            </div>-->
               
             
               
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!--rera no-->
    <div class="afterimg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        <span>RERA REGISTRATION NO.:RC/REP/HARERA/GGM/682/414/2023/26 and RC/REP/HARERA/GGM/681/413/2023/25 (WWW.HARYANARERA.GOV.IN)</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--rera no-->
    <!--Welcome Section-->
    <div class="sectionbg-one">
        <div class="innerprobannerbg sgc93-overview">
            <div class="container">
                <div class="row padd100">
                    <div class="col-lg-12">
                        <span class="captext sg93text wow animate__ animate__fadeInUp">Walk into a Designer Apartment. Walk up to a Premium Lifestyle.</span>
                          <span class="captext sg93text wow animate__ animate__fadeInUp">WELCOME TO</span>
                          <h1 class="sg93text headingtag mb-4 wow animate__ animate__fadeInUp">SIGNATURE GLOBAL CITY 93</h1>
                          <!--<h1 class="headingtag clrwh mb-5 wow animate__ animate__fadeInUp">Enjoy an urban Lifestyle in the lap of nature!</h1>-->
                    </div>
                    <div class="col-lg-12">
                       
                        <p class="sg93text wow animate__ animate__fadeInUp mb-0">SIGNATURE GLOBAL CITY 93 nestled in the heart of New Gurugram, this project is strategically located at Sector 93, Gurugram, offering superior access to major roads – including NH 48, SPR, CPR & Dwarka Expressway. This is where you can assert your liberty in the independence of each spacious floor. The dynamic architectural language builds luxury, contemporary homes with modern amenities; in the prime and upcoming New Gurugram.  All these converge to create cohesive community, where residents interact with each other under a soothingly lush green environment.
</p>

                    </div>
                    
                </div>
            </div>
        </div>      
    </div>
    <!--Welcome Section-->
    
     <div class="projectdetail">
        <div class="container">
            <div class="row">
                 <div class="col-md-4 col-6">
                <div class="project-main-detail project-main-detail-line">
                    <img src="images/sgcity93/Parking.svg" alt="11.5 Feet High Stilt Parking in Signature Global City 93 - Premium Independent Floor in Sctor 93, Gurugram
" >
                    <p class="box-modern-title">11.5 FEET HIGH STILT PARKING</p>
                    
                </div>
                </div>
                 <div class="col-md-4 col-6">
                <div class="project-main-detail project-main-detail-line rightline">
                    <img src="images/sgcity93/Jogging-track.svg" alt="Checkout 2 km Long Jogging Track in Signature Global City 93 - 2 & 3 BHK Independent Floor in Sctor 93, Gurugram">
                    <p class="box-modern-title">2 KM LONG JOGGING TRACK</p>
                </div>
                </div>
                <div class="col-md-4 col-6">
                <div class="project-main-detail rightlinetwo">
                    <img src="images/sgcity93/Road.svg" alt="Bang on 84 Meter Wide Road in Signature Global City 93 - 2 & 3 Independent Floor in Sctor 93, Gurugram">
                    <p class="box-modern-title">BANG ON 84 METER WIDE ROAD</p>
                    
                </div>
                </div>
               
                <div class="col-6">
                 <div class="project-main-detail project-main-detail-line linebtm mt-0">
                     <img src="images/sgcity93/Terrace-garden.svg" alt="Checkout 2 & 3 BHK Flat with Terrace Garden and with roof rights - Premium Independent Floor in Sctor 93, Gurugram">
                    <p class="box-modern-title">TERRACE GARDEN WITH ROOF RIGHTS</p>
                
                </div>
                </div>
                <div class="col-6">
                 <div class="project-main-detail rightlinetwo mt-0">
                     <img src="images/sgcity93/Home.svg" alt="Checkout 3 BHK Flat with some extra space for work from home office in Sector 93, Gurugram">
                    <p class="box-modern-title">EXTRA SPACE FOR WORK FROM HOME</p>
                
                </div>
                </div>
               
             
               
            </div>
        </div>
    </div>
    
    <!--3D WALKTHROUGH-->
    <div class="walkthroughwrap padd100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <span class="captext fcolorlgt wow animate__ animate__fadeInUp" style="visibility: visible; animation-name: fadeInUp;">3D WALKTHROUGH</span>
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp" style="visibility: visible; animation-name: fadeInUp;">Step Into The World Of Luxury</h2>
                </div>
                <div class="col-lg-12">
                    <div class="walkvideoiframe wow animate__ animate__fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                      <iframe width="100%" height="500" src="https://www.youtube.com/embed/mVvf2v-jG1I" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--3D WALKTHROUGH-->
    
    <!--Location-->
    <div class="locationwrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="locationmap wow animate__ animate__fadeInUp">
                        <a data-fancybox="unit-location" href="images/sgcity93/Location-map-double-size.jpg">
                            <img src="images/sgcity93/Location-map.jpg" alt="Signature Global City 93 Location" title="Signature Global City 93 Location"/>
                            <div class="btnclick halvar_rg">
                                <span>Click Here</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-5 location-bg sg93location">
                    <div class="locationadvantage">
                        <h2 class="headingtag clrwh mb-4 wow animate__ animate__fadeInUp">Location<br/> Advantages</h2>
                        
                        <div class="locationlistslider">
                            <div>
                                <div class="ullist wow animate__ animate__fadeInUp">
                                    <p class="clrwh h3">Connectivity to Major Highways</p>
                                    <ul>
                                         <li>Well Connected to NH-48.</li>
                                        <li>Dwarka Expressway.</li>
                                        <li>CPR</li>
                                        <li>SPR(Southern Peripheral Road Gurgaon Manesar)</li>
                                        <li>Kundli-Manesar-Palwal Expressway (KMP)</li>
                                        
                                    </ul>
                                </div>
                                <div class="ullist wow animate__ animate__fadeInUp mt-3">
                                    <p class="clrwh h3">Recreational / Hotels in 7Km Radius </p>
                                    <ul>
                                         <li>Holiday Inn</li>
                                        <li>ITC Grand Bharat</li>
                                        <li>Radisson Hotel</li>
                                        <li>Hyatt Regency</li>
                                    </ul>
                                </div>
                            </div>
                            <div>
                                <div class="ullist wow animate__ animate__fadeInUp">
                                    <p class="clrwh h3">Multi-Specialty Hospital in 6Km Radius</p>
                                    <ul>
                                        <li>Medanta Medicity</li>
<li>Aarvy Healthcare</li>
<li>Miracles Apollo Cradle/Spectra Hospital</li>
<li>Genesis Hospital</li>
<li>Arc Multi Specialty Hospital</li>
<li>Rockland Hospital</li>
<li>Greenway Hospital</li>
<li>ESIC Hospital, Manesar</li>
<li>Silver Streak Hospital</li>
<li>Medeor Hospital, Manesar</li>
                                        
                                    </ul>
                                </div>
                            </div>
                            <div>
                                <div class="ullist wow animate__ animate__fadeInUp">
                                    <p class="clrwh h3">Major School in 6Km Radius</p>
                                    <ul>
                                        <li>DPS</li>
<li>RPS International</li>
<li>St. Xavier's</li>
<li>Yaduvanshi School</li>
<li>Matrikiran School</li>
<li>Euro Kids School</li>
<li>Ipsaa Day Care and Pre School</li>
<li>Kidzee School</li>
<li>Shri Chaitanya School</li>

                                        
                                    </ul>
                                </div>
                            </div>
                            <div>
                                <div class="ullist wow animate__ animate__fadeInUp">
                                    <p class="clrwh h3">Major Universities in 7Km Radius</p>
                                    <ul>
                                        <li>Gurugram University</li>
<li>SGT University</li>
<li>XLRI School of Management</li>


                                        
                                    </ul>
                                </div>
                            </div>
                            <div>
                                <div class="ullist wow animate__ animate__fadeInUp">
                                    <p class="clrwh h3">Retail Hubs and Malls in 7Km Radius </p>
                                    <ul>
                                        <li>Sapphire 90</li>
<li>Orris Broadway</li>
<li>S S Omnia</li>
<li>Gardencity Arcade</li>
<li>Gardencity Central</li>
<li>Vatika City Centre</li>
<li>Iris Broadway</li>
<li>Sapphire 83</li>
<li>Sapphire 92</li>
<li>Town Square</li>
                                    </ul>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Location-->
    <section class="padd100 designerbg">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 col-12">
                     <div class="dreamApartment-content">
                         <h2 class="dreamapp-content fcolordrk mb-4 wow animate__ animate__fadeInUp">Build Your Dream Life In Your Designer Apartment</h2>
                         <div>
                    <img src="images/sgcity93/bg.jpg" alt="Checkout Luxurious Independent Floors by Signature Global" title="Checkout Luxurious Independent Floors by Signature Global" class="dreamimg">
                    </div>
                         <p class="mt-4 wow animate__ animate__fadeInUp">The Complex & Premium Floors are designed by AEDAS, an architectural firm of International presence with expertise in urban designing & master planning. The firm has been founded by Keith Griffith the renowned Welsh architect. Griffith has won many international awards & accolades, which include fellowship of the Hong Kong Institute of Architects & Honorary Fellow of Cardiff University as well as University of Wales, Trinity Saint, David. 
</p>
                            <p class="wow animate__ animate__fadeInUp">Sector 93 is envisioned as economical homes with world-class facilities tailored for a luxurious lifestyle. Homes are designed as efficient and spacious layouts, with a variety of unit types ranging from 2-bedroom to 3-bedroom + study units, catering to diverse pool of residents. </p>
                    </div>
                 </div>
                <div class="col-lg-4 col-12">
                    <div class="dreamApartment-content dreamtwo">
                        <h3 class="dreamapp-content fcolordrk mb-4 wow animate__ animate__fadeInUp">Let Your Interior Decor Speak of Your Premium Lifestyle</h3>
                        <div>
                    <img src="images/sgcity93/Designer-image.jpg" alt="Premium Independent Floors Designed by Sonali Bhagwati" title="Premium Independent Floors Designed by Sonali Bhagwati">
                     </div>
                         <p class="mt-4 wow animate__ animate__fadeInUp">The interiors have been designed by Sonali Bhagwati, a renowned designer who is having 30 years of experience in designing. Bhagwati has given the project her expert touch, which includes the designing & color combination of walls, floors, sanitary as well as landscaping. 
 
</p>
                   
                    </div>
                </div>
                 
            </div>
        </div>
    </section>
   
    
    <!--Unit Plan-->
    <div class="unitsectionwrap padd100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Unit Plans</h2>
                    <div class="controlar pull-right">
                        <span class="arrow-icon-leftpl">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </span>
                        <span class="arrow-icon-rightpl">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </span>
                    </div>
                </div>
                <div class="col-lg-12 wow animate__ animate__fadeInUp">
                    <div class="unitplanslider">
                      <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/type-al.jpg">
                                  <img src="images/sgcity93/type-a.jpg" alt="Signature Global City 93 - Typical Floor Plan (3 BHK + Study) - Category A" title="Signature Global City 93 - Typical Floor Plan (3 BHK + Study) - Category A"/></a>
                               <h3>                               
                              <b>CATEGORY - A</b>
                                <span>TYPICAL FLOOR PLAN</span></h3>
                            </div>
                        </div>
                       <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/type-bl.jpg">
                                  <img src="images/sgcity93/type-b.jpg" alt="Signature Global City 93 - Terrace Floor Plan - Category A" title="Signature Global City 93 - Terrace Floor Plan - Category A"/></a>
                                <h3><b>CATEGORY - A</b>
                                <span>TERRACE FLOOR PLAN</span></h3>
                            </div>
                        </div>
                      
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/type-cl.jpg">
                                  <img src="images/sgcity93/type-c.jpg" alt="Signature Global City 93 - Stilt Floor Plan - Category A" title="Signature Global City 93 - Stilt Floor Plan - Category A"/></a>
                                 <h3><b>CATEGORY - A</b>
                                <span>STILT FLOOR PLAN</span></h3>
                            </div>
                        </div>
                       <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/type-dl.jpg">
                                  <img src="images/sgcity93/type-d.jpg" alt="Signature Global City 93 - Basement Floor Plan - Category A" title="Signature Global City 93 - Basement Floor Plan - Category A"/></a>
                                <h3><b>CATEGORY - A</b>
                                <span>BASEMENT FLOOR PLAN</span></h3>
                            </div>
                        </div>
                       <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/a1l.jpg">
                                  <img src="images/sgcity93/A1.jpg" alt="Signature Global City 93 - Typical Floor Plan  (3 BHK + Study) - Category A(I)" title="Signature Global City 93 - Typical Floor Plan  (3 BHK + Study) - Category A(I)"/></a>
                                <h3><b>CATEGORY - A(I)</b>
                               <span>TYPICAL FLOOR PLAN</span></h3>
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/a12l.jpg"><img src="images/sgcity93/A12.jpg" alt="Signature Global City 93 - Terrace Floor Plan - Category A(I)" title="Signature Global City 93 - Terrace Floor Plan - Category A(I)"/></a>
                                <h3><b>CATEGORY - A(I)</b>
                               <span>TERRACE FLOOR PLAN</span></h3>
                            </div>
                        </div>
                       
                       
                       <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/a13l.jpg">
                                  <img src="images/sgcity93/A14.jpg" alt="Signature Global City 93 - Stilt Floor Plan - Category A(I)" title="Signature Global City 93 - Stilt Floor Plan - Category A(I)"/></a>
                                <h3><b>CATEGORY - A(I)</b>
                              <span>STILT FLOOR PLAN</span></h3>
                            </div>
                        </div>
                      <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/a14l.jpg"><img src="images/sgcity93/A13.jpg" alt="Signature Global City 93 - Basement Floor Plan - Category A(I)" title="Signature Global City 93 - Basement Floor Plan - Category A(I)"/></a>
                                  <h3><b>CATEGORY - A(I)</b>
                               <span>BASEMENT FLOOR PLAN</span></h3>
                            </div>
                        </div>
                        
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/b2-1l.jpg">
                                  <img src="images/sgcity93/b2-1.jpg" alt="Signature Global City 93 - Typical Floor Plan (3 BHK) - Category B(II)" title="Signature Global City 93 - Typical Floor Plan (3 BHK) - Category B(II)"/></a>
                                <h3><b>CATEGORY - B(II)</b>
                                <span>TYPICAL FLOOR PLAN</span></h3>
                            </div>
                        </div>
                      <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/b2-2l.jpg"><img src="images/sgcity93/b2-2.jpg" alt="Signature Global City 93 - Terrace Floor Plan - Category B(II)" title="Signature Global City 93 - Terrace Floor Plan - Category B(II)"/></a>
                                <h3><b>CATEGORY - B(II)</b>
                                 <span>TERRACE FLOOR PLAN</span></h3>
                            </div>
                        </div>
                       <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/b2-3l.jpg">
                                  <img src="images/sgcity93/b2-3.jpg" alt="Signature Global City 93 - Stilt Floor Plan - Category B(II)" title="Signature Global City 93 - Stilt Floor Plan - Category B(II)"/></a>
                                <h3><b>CATEGORY - B(II)</b>
                                <span>STILT FLOOR PLAN</span></h3>
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/b2-4l.jpg">
                                  <img src="images/sgcity93/b2-4.jpg" alt="Signature Global City 93 - Basement Floor Plan - Category B(II)" title="Signature Global City 93 - Basement Floor Plan - Category B(II)"/></a>
                                <h3><b>CATEGORY - B(II)</b>
                                <span>BASEMENT FLOOR PLAN</span></h3>
                            </div>
                        </div>
                        
                       
                        
                         <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/b3-1l.jpg"><img src="images/sgcity93/b3-1.jpg" alt="Signature Global City 93 - Typical Floor Plan (3 BHK) - Category B(III)" title="Signature Global City 93 - Typical Floor Plan (3 BHK) - Category B(III)"/></a>
                                <b>CATEGORY - B(III)</b>
                                <span>TYPICAL FLOOR PLAN</span>
                            </div>
                        </div>
                      <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/b3-2l.jpg"><img src="images/sgcity93/b3-2.jpg" alt="Signature Global City 93 - Terrace Floor Plan - Category B(III)" title="Signature Global City 93 - Terrace Floor Plan - Category B(III)"/></a>
                                <b>CATEGORY - B(III)</b>
                                 <span>TERRACE FLOOR PLAN</span>
                            </div>
                        </div>
                       <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/b3-3l.jpg"><img src="images/sgcity93/b3-3.jpg" alt="Signature Global City 93 - Stilt Floor Plan - Category B(III)" title="Signature Global City 93 - Stilt Floor Plan - Category B(III)"/></a>
                                <b>CATEGORY - B(III)</b>
                                <span>STILT FLOOR PLAN</span>
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/b3-4l.jpg"><img src="images/sgcity93/b3-4.jpg" alt="Signature Global City 93 - Basement Floor Plan - Category B(III)" title="Signature Global City 93 - Basement Floor Plan - Category B(III)"/></a>
                                <b>CATEGORY - B(III)</b>
                                <span>BASEMENT FLOOR PLAN</span>
                            </div>
                        </div> 
                      
                      <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/c1-l.jpg">
                                  <img src="images/sgcity93/c1.jpg" alt="Signature Global City 93 - Typical Floor Plan (3 BHK) - Category C(I)" title="Signature Global City 93 - Typical Floor Plan (3 BHK) - Category C(I)"/></a>
                                <b>CATEGORY - C(I)</b>
                                <span>TYPICAL FLOOR PLAN</span>
                            </div>
                        </div>
                      <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/c2-l.jpg">
                                  <img src="images/sgcity93/c2.jpg" alt="Signature Global City 93 - Terrace Floor Plan - Category C(I)" title="Signature Global City 93 - Terrace Floor Plan - Category C(I)"/></a>
                                <b>CATEGORY - C(I)</b>
                                 <span>TERRACE FLOOR PLAN</span>
                            </div>
                        </div>
                       <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/c3-l.jpg"><img src="images/sgcity93/c3.jpg" alt="Signature Global City 93 - Stilt Floor Plan - Category C(I)" title="Signature Global City 93 - Stilt Floor Plan - Category C(I)"/></a>
                                <b>CATEGORY - C(I)</b>
                                <span>STILT FLOOR PLAN</span>
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/c4-l.jpg"><img src="images/sgcity93/c4.jpg" alt="Signature Global City 93 - Basement Floor Plan - Category C(I)" title="Signature Global City 93 - Basement Floor Plan - Category C(I)"/></a>
                                <b>CATEGORY - C(I)</b>
                                <span>BASEMENT FLOOR PLAN</span>
                            </div>
                        </div>    
                       
                       <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/d1-l.jpg"><img src="images/sgcity93/d1.jpg" alt="Signature Global City 93 - Typical Floor Plan (2 BHK) - Category D" title="Signature Global City 93 - Typical Floor Plan (2 BHK) - Category D"/></a>
                                <b>CATEGORY - D</b>
                                <span>TYPICAL FLOOR PLAN</span>
                            </div>
                        </div>
                      <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/d2-l.jpg"><img src="images/sgcity93/d2.jpg" alt="Signature Global City 93 - Terrace Floor Plan - Category D" title="Signature Global City 93 - Terrace Floor Plan - Category D"/></a>
                                <b>CATEGORY - D</b>
                                 <span>TERRACE FLOOR PLAN</span>
                            </div>
                        </div>
                       <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/d3-l.jpg"><img src="images/sgcity93/d3.jpg" alt="Signature Global City 93 - Stilt Floor Plan - Category D" title="Signature Global City 93 - Stilt Floor Plan - Category D"/></a>
                                <b>CATEGORY - D</b>
                                <span>STILT FLOOR PLAN</span>
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/d4-l.jpg"><img src="images/sgcity93/d4.jpg" alt="Signature Global City 93 - Basement Floor Plan - Category D" title="Signature Global City 93 - Basement Floor Plan - Category D"/></a>
                                <b>CATEGORY - D</b>
                                <span>BASEMENT FLOOR PLAN</span>
                            </div>
                        </div>  
                     
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/d11-l.jpg"><img src="images/sgcity93/d11.jpg" alt="Signature Global City 93 - Typical Floor Plan (2 BHK) - Category D(I)" title="Signature Global City 93 - Typical Floor Plan (2 BHK) - Category D(I)"/></a>
                                <b>CATEGORY - D(I)</b>
                                <span>TYPICAL FLOOR PLAN</span>
                            </div>
                        </div>
                      <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/d12-l.jpg"><img src="images/sgcity93/d12.jpg" alt="Signature Global City 93 - Terrace Floor Plan - Category D(I)" title="Signature Global City 93 - Terrace Floor Plan - Category D(I)"/></a>
                                <b>CATEGORY - D(I)</b>
                                 <span>TERRACE FLOOR PLAN</span>
                            </div>
                        </div>
                       <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/d13-l.jpg"><img src="images/sgcity93/d13.jpg" alt="Signature Global City 93 - Stilt Floor Plan - Category D(I)" title="Signature Global City 93 - Stilt Floor Plan - Category D(I)"/></a>
                                <b>CATEGORY - D(I)</b>
                                <span>STILT FLOOR PLAN</span>
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="images/sgcity93/d14-l.jpg"><img src="images/sgcity93/d14.jpg" alt="Signature Global City 93 - Basement Floor Plan - Category C(I)" title="Signature Global City 93 - Basement Floor Plan - Category C(I)"/></a>
                                <b>CATEGORY - D(I)</b>
                                <span>BASEMENT FLOOR PLAN</span>
                            </div>
                        </div>  
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Unit Plan-->
    <div class="siteplanwrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp" style="visibility: visible; animation-name: fadeInUp;">Site Plan</h2>
                </div>
                <div class="col-lg-12">
                    <div class="sitemapimg wow animate__ animate__fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                        <a data-fancybox="siteplan" href="images/sgcity93/Site-Plan-Double.jpg">
                            <img src="images/sgcity93/Site-Plan.jpg" alt="Signature Global city 93 Site-Plan" title="Signature Global city 93 Site-Plan">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!--Amenities-->
    <div class="amenitieswrap aminitysg93 padd100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="headingtag fcolordrk  wow animate__ animate__fadeInUp">Amenities</h2>
                    <span class="captext fcolorlgt mb-5 wow animate__ animate__fadeInUp">Enter a Realm where Independence Comes with Privileged Amenities</span>
                    <div class="controlam pull-right">
                        <span class="arrow-icon-left">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </span>
                        <span class="arrow-icon-right">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </span>
                   </div>
                   
                   <div class="amenitiesslider">
                       <div>
                           <div class="amenitiesimg">
                                <a data-fancybox="am-gallery" href="images/sgcity93/Family-time.jpg">
                                   <img src="images/sgcity93/Family-time.jpg" alt="Signature Global city 93 - Family Garden" title="Signature Global city 93 - Family Garden">
                                </a>
                           </div>
                           <div class="textbtnam">
                               <span>Family Garden</span>
                           </div>
                       </div>
                       <div>
                           <div class="amenitiesimg">
                                <a data-fancybox="am-gallery" href="images/sgcity93/Grand-Entryway.jpg">
                                   <img src="images/sgcity93/Grand-Entryway.jpg" alt="Signature Global city 93 - Grand Entryway" title="Signature Global city 93 - Grand Entryway">
                                </a>
                           </div>
                           <div class="textbtnam">
                               <span>Grand Entryway</span>
                           </div>
                       </div>
                       <div>
                           <div class="amenitiesimg">
                                <a data-fancybox="am-gallery" href="images/sgcity93/Jogging-track.jpg">
                                   <img src="images/sgcity93/Jogging-track.jpg" alt="Signature Global city 93 - Jogging Track" title="Signature Global city 93 - Jogging Track">
                                </a>
                           </div>
                           <div class="textbtnam">
                               <span>Jogging Track</span>
                           </div>
                       </div>
                       <div>
                           <div class="amenitiesimg">
                                <a data-fancybox="am-gallery" href="images/sgcity93/Peace-of-mind.jpg">
                                   <img src="images/sgcity93/Peace-of-mind.jpg" alt="Signature Global city 93 - Children Play Ground" title="Signature Global city 93 - Children Play Ground">
                                </a>
                           </div>
                           <div class="textbtnam">
                               <span>Children Play Ground</span>
                           </div>
                       </div>
                       <div>
                           <div class="amenitiesimg">
                                <a data-fancybox="am-gallery" href="images/sgcity93/Submerge--yourself.jpg">
                                   <img src="images/sgcity93/Submerge--yourself.jpg" alt="Signature Global city 93 - Swimming Pool" title="Signature Global city 93 - Swimming Pool">
                                </a>
                           </div>
                           <div class="textbtnam">
                               <span>Swimming Pool</span>
                           </div>
                       </div>
                       <div>
                           <div class="amenitiesimg">
                                <a data-fancybox="am-gallery" href="images/sgcity93/Yoga.jpg">
                                   <img src="images/sgcity93/Yoga.jpg" alt="Signature Global city 93 - Yoga Park" title="Signature Global city 93 - Yoga Park">
                                </a>
                           </div>
                           <div class="textbtnam">
                               <span>Yoga Park</span>
                           </div>
                       </div>
                       <div>
                           <div class="amenitiesimg">
                                <a data-fancybox="am-gallery" href="images/sgcity93/Extra-spaces-Extra-advantages.jpg">
                                   <img src="images/sgcity93/Extra-spaces-Extra-advantages.jpg" alt="Signature Global city 93 - Study Room" title="Signature Global city 93 - Study Room">
                                </a>
                           </div>
                           <div class="textbtnam">
                               <span>Study Room</span>
                           </div>
                       </div>
                       <!--<div>-->
                       <!--    <div class="amenitiesimg">-->
                       <!--         <a data-fancybox="am-gallery" href="images/sgcity93/Extra-spacesExtra-advantages-2.jpg">-->
                       <!--            <img src="images/sgcity93/Extra-spacesExtra-advantages-2.jpg" alt="Club in House Events">-->
                       <!--         </a>-->
                       <!--    </div>-->
                       <!--    <div class="textbtnam">-->
                       <!--        <span>Extra Spaces Extra Advantages</span>-->
                       <!--    </div>-->
                       <!--</div>-->
                       <!--  <div>-->
                       <!--    <div class="amenitiesimg">-->
                       <!--         <a data-fancybox="am-gallery" href="images/sgcity93/Family-driving.jpg">-->
                       <!--            <img src="images/sgcity93/Family-driving.jpg" alt="Club in House Events">-->
                       <!--         </a>-->
                       <!--    </div>-->
                       <!--    <div class="textbtnam">-->
                       <!--        <span>Family Driving</span>-->
                       <!--    </div>-->
                       <!--</div>-->
                   </div>
                </div>
            </div>
        </div>
    </div>
    <!--Amenities-->
    
    <!--Projects Gallery-->
    <div class="elevationsectionwrap padb100">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
                <span class="captext fcolorlgt wow animate__ animate__fadeInUp">Elevations</span>
                <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Our array of luxury accommodations</h2>
            </div>
            <div class="col-lg-12 wow animate__ animate__fadeInUp">
                <div class="progalleryslider mt-4">
                    <div class="slider-for">
                        <img class="item-slick" src="images/sgcity93/elevation/Aerial-Cam+1.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                       <img class="item-slick" src="images/sgcity93/elevation/Basket-Ball.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                        <img class="item-slick" src="images/sgcity93/elevation/Commercial-view+1.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                        <img class="item-slick" src="images/sgcity93/elevation/Main-Entry.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                      <img class="item-slick" src="images/sgcity93/elevation/Open-Gym+1).jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                      <img class="item-slick" src="images/sgcity93/elevation/Sculpture-Cam.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                      <img class="item-slick" src="images/sgcity93/elevation/Street-View 01.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                      <img class="item-slick" src="images/sgcity93/elevation/Yoga-Court+1.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                      <img class="item-slick" src="images/sgcity93/elevation/kids-cam+1.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                      <img class="item-slick" src="images/sgcity93/elevation/street-view+1).jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                    </div>
                    <div class="slider-nav"> 
                       <img class="item-slick" src="images/sgcity93/elevation/Aerial-Cam+1.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                       <img class="item-slick" src="images/sgcity93/elevation/Basket-Ball.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                        <img class="item-slick" src="images/sgcity93/elevation/Commercial-view+1.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                        <img class="item-slick" src="images/sgcity93/elevation/Main-Entry.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                      <img class="item-slick" src="images/sgcity93/elevation/Open-Gym+1).jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                      <img class="item-slick" src="images/sgcity93/elevation/Sculpture-Cam.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                      <img class="item-slick" src="images/sgcity93/elevation/Street-View 01.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                      <img class="item-slick" src="images/sgcity93/elevation/Yoga-Court+1.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                      <img class="item-slick" src="images/sgcity93/elevation/kids-cam+1.jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                      <img class="item-slick" src="images/sgcity93/elevation/street-view+1).jpg" alt="Signature Global city 93 - Residential Property in Sector 93" title="Signature Global city 93Signature Global city 93 - Residential Property in Sector 93">
                    </div>
                </div>
            </div>
          </div>
        </div>
    </div>
    <!--Projects Gallery-->

<div class="notificationwrap padb100">
        <div class="container">
            <div class="accordion" id="accordionExample">
              
                <div class="card wow animate__ animate__fadeInUp">
                    <div class="card-head" id="headingOne">
                        <h2 class="mb-0 collapsed show-more" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            <b>Notification Advertisement</b> <span class="halvar_rg text show-more-height"></span>
                        </h2>
                    </div>
                
                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="notificationtable">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Title</th>
                                                <th>Date</th>
                                                <th>English</th>
                                                <th>Hindi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Hari Bhoomi (Hindi) and The Morning Standard (English)</td>
                                                <td>13.04.2023</td>
                                                <td><a href="pdf/city-93/Public-Notice-Ad4x10cm-(Signature Builders Private Limited)-copy.pdf" target="_blank"><img src="images/icon/pdf.svg" alt="Pdf"/></a></td>
                                                <td></td>
                                            </tr>                                           
                                            
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


   
  <div class="footerpagetop bg79b">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="textwrap">
                            <span>SIGNATURE BUILDERS PRIVATE LIMITED | CIN:. U70101DL2011PTC220275</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   <div class="footerpagetop bg79b">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        <strong>Disclaimer</strong>
                      	<p>Promoter urges every applicant to inspect the project site and shall not merely rely upon any architectural impression, plan or sales brochure and, therefore, requests to make personal judgment prior to submitting an application for allotment. The Project is being developed in phases, hence, certain facilities/amenities etc, may be used by allottee of other phases. Unless otherwise stated, all the images, visuals, materials and information contained herein are purely creative/artistic and may not be actual representations of the product and/or any amenities. Further, the actual design may vary in the fit and finished form, from the one displayed above . Journey time shown, if any, is based upon Google Maps which may vary as per the traffic at a relevant point of time. *Rate mentioned above does not include GST and other statutory charges, if applicable. T &amp; C Apply. 1 sq. mt. = 10.7639 sq. ft.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
       $.urlParam = function (name) {
           var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);
        return (results !== null) ? results[1] || 0 : false;
        }
        
        var utmSource = $.urlParam('utm_source') ? $.urlParam('utm_source') : 'direct';
        var utmMedium = $.urlParam('utm_medium') ? $.urlParam('utm_medium') : '';
        var utmCampaign = $.urlParam('utm_campaign') ? $.urlParam('utm_campaign') : '';
        var utmId = $.urlParam('utm_id') ? $.urlParam('utm_id') : '';
         
        var url = new URL("https://enquiry.signatureglobal.in/?projectName=SGCity93&enquiryFrom=Online");
        $(function() {
                url.searchParams.set('utm_source',utmSource);
                if(utmMedium!=""){url.searchParams.set('utm_medium',utmMedium);}
                if(utmCampaign!=""){url.searchParams.set('utm_campaign',utmCampaign);}
                if(utmId!=""){url.searchParams.set('utm_id',utmId);}
                $('#abc_frame').attr('src', url)
        
        });
    </script>
    

<!--Footer-->
    <footer class="footerbg padd100">
       <div class="width100">
            <div class="container">
                <div class="row paddb60">
                   <div class="col-12">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt m-0 wow animate__ animate__fadeInUp">
                                    <strong>SIGNATURE GLOBAL</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/residential/" title="Residentential projects by Signature Global">Residential</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/" title="Commercial projects by Signature Global">Commercial</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/">Retail</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class=" footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>OUR PRESENCE</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/commercial/society-shops/gurugram/" title="Signature Global in Gurugram">Gurugram</a></li>
                                        <li><a href="https://www.signatureglobal.in/residential/plots/karnal" title="Signature Global in Karnal">Karnal</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/ghaziabad" title="Signature Global in Ghaziabad">Ghaziabad</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>ABOUT US</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" title="Signature Global - Chairman's message" class="scdown">Chairman’s Message</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" title="Signature Global - Board of Director" class="scdown">Board of Directors</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" title="Signature Global - Key Managerial Positions" class="scdown">Key Managerial Positions</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" title="Our Architect" class="scdown">Our Architects</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" title="Signature Global - Vission & Mission of Signature Global" class="scdown">Vision & Mission</a></li>
                                    <!--    <li><a href="signature-global-foundation.php" title="Signature Global Foundation">Signature Global Foundation</a></li>-->
                                    </ul>
                                </div>
                           </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>CAREERS</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/career.php#as-associate" title="Careers at Signature Global">As Associate</a></li>
                                        <li><a href="https://www.signatureglobal.in/career.php#life-signature" title="Life At Signature Global">Life @ Signature Global </a></li>
                                        <li><a href="#"></a></li>
                                    </ul>
                                </div>
                              
                                <div class="footernav halvar_lt wow animate__ animate__fadeInUp publicnoticehome">
                                  <ul>
                                    <li><a href="https://www.signatureglobal.in/public-notice.php" title="Signature Global Public Notice"><strong>Public Notice</strong></a></li>
                                  </ul>                                  
                             	</div>
                                          
                           </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong style="margin-bottom: 15px;">GALLERY</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/gallery.php" title="Signature Global Gallery">Picture Library</a></li>
                                        <li><a href="https://www.signatureglobal.in/video-gallery.php" title="Signature Global Video Gallery">Video Library</a></li>
                                    </ul>
                                </div>   
                            </div>
                           <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/media.php" title="Signature Global Blogs">MEDIA</a></strong> 
                                    <ul>
                                     <li><a href="https://www.signatureglobal.in/media-coverage.php" title="Signature Global Gallery">Media Coverage</a></li>
                                        <!--<li><a href="https://www.signatureglobal.in/press-release.php" title="Signature Global Video Gallery">Press Release</a></li> -->
                                         <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Gallery">Press Kit</a></li>
                                        <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Video Gallery">Media Contact</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                   <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/blog" title="Signature Global Blogs">Blog</a></strong>
                                <!--    <strong class="mb-2"><a class="clrwh opctext" href="https://online.anyflip.com/dhkmm/nalj/mobile/index.html" target="_blank" title="Signature Global Newsletter ">NEWSLETTER</a></strong> -->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/home-loans.php" title="Signature Global - Home Loans">Home Loans</a></strong>
                                  <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/pay-online.php" title="Signature Global - APPLY ONLINE">PAY ONLINE</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/award.php" title="Signature Global Certificates">AWARD</a></strong>                                  
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                 <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" target="_blank" title="Signature Global Login">MBDA/BDA Login</a></strong>
                                   <!-- <strong class="mb-2"><a class="clrwh opctext" href="http://signatureglobal04.realboost.in/add_appointment.aspx" target="_blank" title="Signature Global Appointments">Appointment</a></strong>-->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/terms-of-appointment.php" title="Signature Global - Terms of appointment">Terms of Appointment</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/green-development.php" title="Signature Global - Green Development">Green Development</a></strong>
                                </div>     
                            </div>
                        </div>
                        
                   </div>
                </div>
            </div>
        </div>
      
        
        <div class="width100 bordertop padt60 wow animate__ animate__fadeInUp">
            <div class="container">
                <div class="row">    
                    <div class="col-lg-3">
                       <div class="footerlogo wow animate__ animate__fadeInUp">
                           <img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/>
                       </div> 
                    </div>
                    <div class="col-lg-4">
                        <div class="footernav pl-65 wow animate__ animate__fadeInUp">
                            <strong>REGISTERED OFFICE</strong>
                            <p>13<sup>th</sup> Floor, Dr. Gopal Das Bhawan, 28<br class="ftmb"/> Barakhamba Road, Connaught Place,<br class="ftmb"/> New Delhi 110 001, India.</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Registered Office: +91 11 4928 1700</a>
                        </div>
                    </div>
                    <div class="col-lg-3 pl-00">
                        <div class="footernav wow animate__ animate__fadeInUp">
                            <strong>CORPORATE OFFICE</strong>
                            <p>Unit No.101, Ground Floor, Tower-A,<br class="ftmb"/>Signature Tower South City-1, Gurugram,<br class="ftmb"/>Haryana 122 001, India</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Corporate Office: +91 124 4398 011</a>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="footermedianav mtopft wow animate__ animate__fadeInUp">
                            <strong>FOLLOW US</strong>
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </footer>
     <!--policytab-->
     <div class="policywraper">
         <div class="container">
             <div class="row">
                 <div class="col-lg-10 col-md-10">
                     <div class="policylink text-left">
                        <p>© 2023 Signature Global. All Rights Reserved <br class="mobhidebr"/><span class="clrwh mobhide">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/advertising-policy-for-channel-partners.php"  >Advertising Policy For Channel Partners</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/privacy-policy.php" title="Signature Global - Privacy Policy">Privacy Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/social-media-policy.php" title="Signature Global - Social Media Policy">Social Media Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/generic-faqs-for-haryana-affordable-housing-policy.php">Generic Faq's</a>                        
                       </p>
                       
                     </div>
                  
                 </div>
             <!--     <div class="col-lg-2 col-md-2 cclogo ">
                     <img src="https://www.signatureglobal.in/images/cogdigital.svg" alt="" width="15">
                   </div> -->
             </div>
         </div>
     </div>
   
    <script>
         $.urlParam = function (name) {
            var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);
            return (results !== null) ? results[1] || 0 : false;
            }
            
            var utmSource = $.urlParam('utm_source') ? $.urlParam('utm_source') : 'direct';
            var utmMedium = $.urlParam('utm_medium') ? $.urlParam('utm_medium') : '';
            var utmCampaign = $.urlParam('utm_campaign') ? $.urlParam('utm_campaign') : '';
            var utmId = $.urlParam('utm_id') ? $.urlParam('utm_id') : '';
             
            var enq_url = new URL("https://enquiry.signatureglobal.in/?projectName=ContactUs&enquiryFrom=Online");
            $(function() {
                    enq_url.searchParams.set('utm_source',utmSource);
                    if(utmMedium!=""){enq_url.searchParams.set('utm_medium',utmMedium);}
                    if(utmCampaign!=""){enq_url.searchParams.set('utm_campaign',utmCampaign);}
                    if(utmId!=""){enq_url.searchParams.set('utm_id',utmId);}
                    
              if($('#main_frame').length > 0)
                    $('#main_frame').attr('src', enq_url)
            
            });

    </script>


<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/animate.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/jquery.fancybox.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/slick.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>


<script src="https://www.signatureglobal.in/js/wow.min.js"></script>
<script src="https://www.signatureglobal.in/js/slick.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.fancybox.min.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.validate.min.js"></script>
<script src="https://www.signatureglobal.in/js/additional-methods.js"></script>
<script src="https://www.signatureglobal.in/js/custom.js"></script> 
<script src="https://www.signatureglobal.in/js/app.js"></script> 
<!-- Start of  Zendesk Widget script -->
<script>
   setTimeout(function(){
      var chatScript = '<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"/>';
      $('body').append(chatScript);
   },  
 5000);
</script>

<script>
  window.addEventListener('load', function() {
    jQuery('body').on('mousedown', '[href*="tel:"]', function() {
      gtag('event', 'phone_call')
    })
    jQuery('body').on('mousedown', '[href*="api.whatsapp.com"]', function() {
      gtag('event', 'whatsapp_click')
    })
    jQuery('body').on('mousedown', '.btnrt:contains(Enquire Now)', function() {
      gtag('event', 'enquire_now')
    })
    jQuery('body').on('mousedown', '.contact100-form-btn:contains(Submit)', function() {
      gtag('event', 'Submit_btn')
    })
  });

</script>
<!--<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"> </script>-->
<!-- End of  Zendesk Widget script -->





 


</body>
</html>