<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="facebook-domain-verification" content="zqv18clg4hyd5synd83cbrczwv588t" />
<title> About Signature Global - Leading Real Estate Developer in India</title>
<meta name=description content="Learn about Signature Global, a top real estate developer in India. Discover our vision, mission, and values, and explore our portfolio of projects that have transformed the urban landscape." />
<meta name=keywords content="About Signature Global, About Signatureglobal (India) Limited, About Signature Global India" />
<link rel="canonical" href="https://www.signatureglobal.in/about-us.php" />
<meta name="robots" content="noodp" />
 

    
  
  
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5S8ZC8X');</script>
<!-- End Google Tag Manager -->
  
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-90138100-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-90138100-1');
</script>
  
  

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-MRPZNF8ZD2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-MRPZNF8ZD2');
</script>
  
<!-- Global site tag (gtag.js) - Google Ads: 962082073 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-962082073"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config','AW-962082073', {'allow_enhanced_conversions':true});
</script>
<script>
  gtag('config', 'AW-962082073/BUgQCILmzakDEJnq4MoD', {
    'phone_conversion_number': '7053-121-121'
  });
</script>
  
  

  
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '359225061117882');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=359225061117882&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<link href=https://www.signatureglobal.in/images/favicon1.png rel="shortcut icon" type=image/x-icon>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/bootstrap.min.css"/>
<link  rel="stylesheet"  href="https://www.signatureglobal.in/css/fontawesome/css/all.min.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/style.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/responsive.css"/>
<script src="https://www.signatureglobal.in/js/jquery.min.js"></script>
<script  src="https://www.signatureglobal.in/js/bootstrap.min.js"></script>
<style>
  .shhhow{display:block !important; opacity:1 !important;}
  }
</style>

</head>
<body>
  <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5S8ZC8X"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

        
    <header class="header-area">
        <div class="overlayhd"></div>
        <nav class="navbar navbar-expand-md navbar-dark">
            <div class="container">
                <a href="https://www.signatureglobal.in/" class="navbar-brand"><img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/></a> 
                <div class="mobiconbtn">
                    <a href="tel:+91-7053121121">
                        <svg id="Layer_4" data-name="Layer 4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><circle class="cls-1 cls2" cx="75" cy="75" r="73.55"/><path d="M54.68,41.25,50,41a5.64,5.64,0,0,0-4,1.36c-2.25,2-5.86,5.76-7,10.69-1.66,7.37.9,16.39,7.51,25.4S65.5,101.9,87.29,108.06c7,2,12.55.65,16.81-2.08a15,15,0,0,0,6.54-9.54l.75-3.47a2.43,2.43,0,0,0-1.35-2.7L94.3,83a2.41,2.41,0,0,0-2.92.71l-6.18,8a1.78,1.78,0,0,1-2,.6C79,90.85,64.81,84.91,57,69.93a1.77,1.77,0,0,1,.23-2l5.9-6.83a2.41,2.41,0,0,0,.39-2.53L56.77,42.71A2.42,2.42,0,0,0,54.68,41.25Z"/></svg>
                    </a>
                    <a id="forother" href="https://api.whatsapp.com/send?phone=%2B917303918365&text=Hii%2C+I+am+interested+in+Signature%20Global+Affordable+Housing">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>
                  	<a id="forwhatsapp" href="https://api.whatsapp.com/send?phone=919311144622&amp;text=">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>	
                  
                </div>
                <button type="button" class="navbar-toggler collapsed" data-target="#main-nav">
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                </button>                
                <div id="main-nav" class="navbar-collapse">
                    <div class="topnavbaxy">
                        <ul class="navbar-nav width100 dlfx">                         
                         <!--   <li><a href="career.php" class="nav-link" title="Signature Global - Carrer">Career </a></li> -->
                            <li class="dropdown loginpage">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">LOGIN <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://signatureglobal2.my.salesforce-sites.com/sg?cpForm=true" class="assreg" target="_blank">Associate Registration</a></li>
                                     <li><a href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" class="assreg" target="_blank">MBDA/BDA Login</a></li>
                                     <li><a href="https://app.hrone.cloud/login" class="assreg assreg1" target="_blank">Employee Login</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                        <!--    <li><a href="pay-online.php" class="nav-link" title="Signature Global  - Pay Online">APPLY ONLINE</a></li>-->
                            <li><a href="https://www.signatureglobal.in/investor.php" class="nav-link" title="Signature Global  - Investor">Investor</a></li> 
                            <li><a href="https://www.signatureglobal.in/customer_support.php" class="nav-link" title="Signature Global  - Custome Support">Customer Support </a></li>                         
                   <!--      <li><a href="pdf/SG_Mobile_App_User_Manual.pdf" class="nav-link" target="_blank">Mobile app User Manual</a></li>-->
                         <li><a href="https://www.signatureglobal.in/signature-global-foundation.php" class="nav-link" target="_blank">Signature Global Foundation</a></li>                        
                        </ul>
                    </div>                     
                    <ul class="navbar-nav width100 dlfx ">
                   <!--     <li class="nav-item">
                          <a href="about-us.php" class="nav-link" title="Signature Global  - About Us">About US </a>
                          
                      </li>-->
                      
                       <li class="nav-item dropdown loginpage position-relative">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">About US <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#companyjourney" class="assreg scdown"> Company's Journey</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" class="assreg scdown" >Chairman's Message</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" class="assreg scdown" >Board of Directors</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" class="assreg scdown">Key Managerial Positions</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" class="assreg scdown" >Our Architects</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" class="assreg scdown">Vision & Mission</a></li>
                                     <li><a href="https://www.signatureglobal.in/career.php#life-signature" class="assreg" target="_blank"> Life @ Signature Global</a></li>
                                     <li><a href="https://www.signatureglobal.in/green-development.php" class="assreg assreg1" target="_blank">Green Development</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                      
                        <li class="nav-item dropdown">
                            <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">RESIDENTIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                            <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-5">
                                                <strong>Residential</strong>
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/residential/affordable/">Affordable Group Housing</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/premium/">Premium Independent Floors</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/plots/">Residential Plots</a></li>
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div> 
                                            </div>
                                            <div class="col-lg-8 col-md-7">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5 col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Residential</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/residential/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_6" data-name="Layer 6"><g id="Layer_1-6" data-name="Layer 6"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Resdential-nvbg.jpg" alt="Residential Projects by Signature Global
" title="Residential Projects by Signature Global
">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item dropdown">
                          <a href="#" title="Commercial projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">COMMERCIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                          <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-6 ">
                                                <strong>Commercial</strong>
                                    
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/commercial/society-shops/">Society Shops</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/malls/">Mall</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/sco-plots/">SCO</a></li> 
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-lg-8 col-md-6 ">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5  col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Commercial</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/commercial/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_7" data-name="Layer 7"><g id="Layer_1-7" data-name="Layer 7"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Commercial-nvbg.jpg" alt="Commercial Projects by Signature Global" title="Commercial Projects by Signature Global">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item"><a title="Signature Global  - Contact Us" href="https://www.signatureglobal.in/contact.php" class="nav-link">CONTACT US </a></li>
                    </ul>
                    <div class="bottommediamobwrap">
                        <ul class="pplink">
                            <li><a href="https://www.signatureglobal.in/privacy-policy.php">Privacy Policy</a></li>
                          <li><span>|</span></li>
                            <li><a href="https://www.signatureglobal.in/social-media-policy.php">Social Media Policy</a></li>
                        </ul>
                        <div class="footermedianav mtopft">
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <div class="overlaymobbg"></div>    
<!--Enquire Now Iframe-->
<div class="registerform">
   <div class="fixedbtn">
      <span class="btnrt">Enquire Now</span>
   </div>
   <div class="innerform">
      <iframe  frameborder="0" width="100%" height="400px" id="main_frame"></iframe>
   </div>
</div>
<!--Enquire Now Iframe-->
<!--banner section-->
<div class="banner about-banner padd100">
   <div class="overlay"></div>
</div>
<!--banner-->
<section class="about-sec" id="companyjourney">
   <div class="innerbannerbg">
      <div class="container">
         <div class="row">
            <div class="col-md-12 paragraph">
               <h1 class="wow animate__ animate__fadeInUp">About<br>
                  Signature Global
               </h1>
              <p class="mb185 mb-3 wow animate__ animate__fadeInUp">Signature Global is a well-established brand with a strong presence in Delhi-NCR, and is known for innovative construction technologies, amenities & affordable prices.</p> 
              <p class=" mb-3 wow animate__ animate__fadeInUp">
               The company commenced its operations in 2014 through its subsidiary, Signature Builders Private Limited, with the launch of our Solera project on 6.13 acres of land in Gurugram, Haryana. Over the years, The Company has expanded its operations, and as of March 31, 2023 it had sold 27,965 residential and commercial units, all within the Delhi NCR region. The Company strategically focuses on the Affordable Housing segment and the middle-income housing segment through Government of India and state government policies. Most of the completed, ongoing, and forthcoming projects are located in Gurugram and Sohna in Haryana.

 
              </p>
               <p class="mb-3 wow animate__ animate__fadeInUp">The Company provides "value homes" with attractive designs and amenities, seeking to enhance the value of its projects by creating a better living environment through the provision of comprehensive community facilities and engagement with renowned architects. The company's affordable projects include amenities such as recreational areas, gardens, open spaces, and community halls and Mid-housing projects provide facilities including gyms, recreational spaces, entertainment centers, swimming pools, and sporting facilities. All Affordable and Mid-housing projects have a retail component within them intended to offer convenience to residents, further increasing the value of the projects without price ceilings.
 </p>
               <p class="mb-3 wow animate__ animate__fadeInUp">All the projects are located in the well-developed Delhi NCR region with connectivity to other parts of Delhi NCR. In addition to the Gurugram area, the company has also launched certain projects across key markets in Haryana, such as Karnal, under the mid-housing segment. The company also has one ongoing project being developed by its subsidiary, Sternal Buildcon Private Limited, namely Infinity Mall, located close to the company's affordable and mid-housing projects in Sohna.
</p>
               <p class="mb-3 wow animate__ animate__fadeInUp">The company believes that the Signature Global brand is well-established in Gurugram, Haryana, and the wider Delhi NCR region for affordable and mid-segment housing projects. The combination of Signature Global's brand recognition, quality product offerings, and competitive pricing has enabled the company to sell a substantial portion of the inventory soon after the launch of the projects. The company has adopted an integrated real estate development model, with capabilities and resources to carry a project from conceptualization to completion. Company's project execution capabilities are present across the real estate development value chain, and they have developed extensive in-house capabilities right from land identification, project conceptualization, to project execution involving planning, obtaining regulatory approvals, designing, supervising construction, marketing and sales, and culminating in project delivery. The company's expertise across several processes, including a centralized raw material procurement system, has resulted in cost efficiencies for its operations and has helped deliver their offerings at competitive prices.
</p>
               <p class="mb-3 wow animate__ animate__fadeInUp">The company constantly incorporates sustainable best practices and considerations into the design and construction of our projects. The company has implemented environmentally friendly building concepts in many of their projects and aim to increase green cover in their developments to minimize net carbon impact. The company has implemented sustainable practices such as common area lighting with solar panels, LED lights, besides the use of steel/aluminum powder-coated UPVC doors and windows and high-performance glass with light transmission that ensure better cooling and, in turn, energy savings. Signature Global is an EDGE certified Green Building Developer in the affordable/mid-housing segment in Delhi NCR. EDGE certification obtained by Signature Global's completed projects and ongoing projects demonstrates the achievement in the areas of energy savings, water savings, and sustainable materials. As a member of the IGBC, the company is committed to sustainability efforts as part of its project development. The company has also been recognized for its efforts towards sustainable building through awards such as the 'Developer Leading the Green Affordable Housing Movement in India' at the 8th IGBC Green Championship Awards.
</p>
              <p  class="mb-3 wow animate__ animate__fadeInUp">
             As of March 31, 2022, all of the company's projects launched between Fiscal 2020 and Fiscal 2022 are either EDGE or IGBC certified. Signature Global also possesses industry-leading certifications, including ISO 9000:2015 for quality management systems for development and construction of buildings, ISO 14001:2015 for environmental management systems for development and construction of buildings, and ISO 45001:201 for occupational health and safety for development and construction of buildings. 

              </p>
              <p class="mb-3 wow animate__ animate__fadeInUp">
                The company has replicated its business model across micro-markets in Delhi NCR, with a particular focus on Gurugram, Haryana, and has consistently grown its operations to leverage its robust brand presence. The company's ability to expand at a rapid pace can be attributed to its standardized design, technical specifications, and layout plans, which they also foresee enabling rapid future expansion. Signature Global's track record in execution and continued construction has been instrumental in their consistent sales and performance, despite challenging market conditions due to the COVID-19 pandemic.

              </p>
            
            </div>
            <div class="col-md-12 chairman-sec" id="chairmans-message">
               <span class="captext wow animate__ animate__fadeInUp" >CHAIRMAN’S MESSAGE</span>
               <div class="headingtag clrwh wow animate__ animate__fadeInUp" >A vision that differentiates us</div>
            </div>
            <div class="col-md-8 ">
               <div class="chairman-content">
                  <div class="scroll">
                     <p class="mt-minus mb-3">To begin with, I would like to thank you for visiting our website and showing an interest in our company. Whether you are a client, an investor or one of our own team members, I sincerely hope we are able to provide you with whatever information you seek.</p>
                     <p class="mb-3 ">Signature Global takes great pride in everything that it does, and the projects we wish to deliver are going to be the proud examples of what can be achieved when brilliant minds come together, determined to make a difference to the world we live in.</p>
                     <p class="mb-3">I believe that our hard work, determination, foresight and the technological edge that we enjoy over our competitors, are the real differentiators when comparisons are made and experts take notes.</p>
                     <p class="mb-3">Attention to detail, superior quality, maximization of resources and elegant aesthetics are just some of the standards we demand throughout our projects – from residential to commercial, from retail to when we build, the entire process from design to execution to its final delivery – we try to ensure that experience of living and working in a Signature property is truly unparalleled.</p>
                     <p class="mb-3">With each of our properties we continue to consistently raise the bar of luxury living in India. Even though as a company we are still young, we possess a rich and diversified presence across several core sectors in the real estate arena. As new windows of opportunities open up, we find ourselves well equipped to make a mark in the annals of Indian Real Estate in the coming years.</p>
                  </div>
                  <h2>Mr. Pradeep Kumar Aggarwal | Founder and Chairman</h2>
               </div>
            </div>
            <div class="col-md-4">
               <div class="chairman-thumb">
                  <img src="images/key/Pradeep-Aggarwal.webp" class="w-100" alt="Signature Global - Chairman" title="Signature Global - Chairman">
               </div>
            </div>
         </div>
      </div>
   </div>
  
   
</section>

<section class="director-sec" id="board-of-directors">
   <div class="container">
      <div class="row">
         <div class="col-md-12 relative">
            <h2 class="wow animate__ animate__fadeInUp">Board of Directors</h2>
            <div class="control pull-right">
                <span class="arrow-icon-left">
                   <!--<img src="images/icon/right-arrow.svg" >-->
                   <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                </span>
                <span class="arrow-icon-right">
                    <!--<img src="images/icon/right-arrow.svg">-->
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                </span>
            </div>
         </div>
      </div>
      <div class="director-slider">
         <div class="director-thumb">
            <div class="thumb-pic">
               <img src="images/key/Pradeep-Aggarwal.webp" class="w-100" alt="Signature Global - Founder & Chairman" title="Signature Global - Founder & Chairman">
            </div>
            <div class="title-sec">
               <div>
                  <h3>                   
                 <span>Mr. Pradeep Kumar Aggarwal</span>
                  <p>Founder and Chairman</p>
                  </h3>
               </div>
               <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="4">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
               </a>
            </div>
         </div>
         <div class="director-thumb">
            <div class="thumb-pic">
               <img src="images/key/Lalit-Aggarwal.webp" class="w-100" alt=" Signature Global Co-Founder & Vice Chairman" title=" Signature Global Co-Founder & Vice Chairman">
            </div>
            <div class="title-sec">
               <div>
                 <h3><span>Mr. Lalit Kumar Aggarwal</span>
                  <p>Vice Chairman and Whole-time Director</p>
                   </h3>
               </div>
               <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="5">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
               </a>
            </div>
         </div>
        <div class="director-thumb">
            <div class="thumb-pic">
               <img src="images/key/Devender-Aggarwal.webp" class="w-100" alt="Signature Global - Co-Founder & Joint Managing Director" title="Signature Global - Co-Founder & Joint Managing Director">
            </div>
            <div class="title-sec">
               <div>
                  <h3><span>Mr. Devender Aggarwal</span>
                  <p>Joint Managing Director and Whole-time Director</p>
                    </h3>
               </div>
               <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="7">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
               </a>
            </div>
         </div>
        
         <div class="director-thumb">
            <div class="thumb-pic">
               <img src="images/key/Ravi-Aggarwal.webp" class="w-100" alt="Signature Global - Co-Founder & Managing Director" title="Signature Global - Co-Founder & Managing Director" >
            </div>
            <div class="title-sec">
               <div>
                 <h3><span>Mr. Ravi Aggarwal</span>
                  <p>Managing Director</p>
                   </h3>
               </div>
               <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="6">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
               </a>
            </div>
         </div>
         
        <div class="director-thumb">
            <div class="thumb-pic">
              <img src="images/key/Kundan-Mal-Agarwal.webp" class="w-100" alt="Signature Global - Director" title="Signature Global - Director">
            </div>
            <div class="title-sec">
              <div>
                 <h3><span>Mr. Kundan Mal Agarwal</span>
                 <p>Independent Director</p>
                   </h3>
              </div>
              <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="13">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
              </a>
            </div>
        </div>
        
        <div class="director-thumb">
            <div class="thumb-pic">
              <img src="images/key/Chandra-Wadhwa.webp" class="w-100" alt="Signature Globa - Director" title="Signature Global - Director">
            </div>
            <div class="title-sec">
              <div>
                 <h3><span>Mr. Chandra Wadhwa </span>
                 <p>Independent Director</p>
                   </h3>
              </div>
              <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="14">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
              </a>
            </div>
        </div>
        
        <div class="director-thumb">
            <div class="thumb-pic">
              <img src="images/key/Lata-Pillai.webp" class="w-100" alt="Signature Globa - Director" title="Signature Global - Director">
            </div>
            <div class="title-sec">
              <div>
                 <h3><span>Ms. Lata Pillai</span>
                 <p>Independent Director</p>
                   </h3>
              </div>
              <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="17">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
              </a>
            </div>
        </div>
        
        <div class="director-thumb">
            <div class="thumb-pic">
              <img src="images/key/narayanan.webp" class="w-100" alt="Signature Globa - Director" title="Signature Global - Director">
            </div>
            <div class="title-sec">
              <div>
                <h3> <span>Mr. Venkatesan Narayanan</span>
                <p>Independent Director</p>
                  </h3>
              </div>
              <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="18">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
              </a>
            </div>
        </div>
        
        
      </div>
   </div>
  
</section>
<section class="key-sec pad120" id="key-managerial">
   <div class="container">
      <div class="row">
         <div class="col-md-12 relative">
            <h2 class="wow animate__ animate__fadeInUp">Key Managerial Positions</h2>
            <div class="control pull-right">
                <span class="arrow-icon-left2">
                   <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                </span>
               <span class="arrow-icon-right2">
                   <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
               </span>
            </div>
         </div>
      </div>
      <div class="key-slider">
         <!--<div class="col-md-3 mb-40">-->
         <!--   <div class="director-thumb">-->
         <!--      <div class="thumb-pic">-->
         <!--         <img src="images/key/rajat-kathuria-thumb.jpg" class="w-100" alt="Mr. Rajat Kathuria">-->
         <!--      </div>-->
         <!--      <div class="title-sec">-->
         <!--         <div>-->
         <!--            <span>Mr. Rajat Kathuria</span>-->
         <!--            <p>CEO, Signatureglobal (India) Limited</p>-->
         <!--         </div>-->
         <!--         <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="12">-->
         <!--             <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>-->
         <!--         </a>-->
         <!--      </div>-->
         <!--   </div>-->
         <!--</div>-->
        <div class="col-md-3 mb-40">
                    <div class="director-thumb">
                    <div class="thumb-pic">
                       <img src="images/key/Pradeep-Aggarwal.webp" class="w-100" alt="Signature Global - Founder & Chairman" title="Signature Global - Founder & Chairman">
                    </div>
                    <div class="title-sec">
                       <div>
                          <h3><span>Mr. Pradeep Kumar Aggarwal</span>
                          <p>Founder and Chairman</p>
                            </h3>
                       </div>
                       <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="4">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                       </a>
                    </div>
                 </div>
         </div>
        
        <div class="col-md-3 mb-40">
          <div class="director-thumb">
            <div class="thumb-pic">
               <img src="images/key/Lalit-Aggarwal.webp" class="w-100" alt=" Signature Global Co-Founder & Vice Chairman" title=" Signature Global Co-Founder & Vice Chairman">
            </div>
            <div class="title-sec">
               <div>
                  <h3><span>Mr. Lalit Kumar Aggarwal</span>
                  <p>Vice Chairman and Whole-time Director</p>
                    </h3>
               </div>
               <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="5">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
               </a>
            </div>
         </div>
        </div>
        <div class="col-md-3 mb-40">
           <div class="director-thumb">
            <div class="thumb-pic">
               <img src="images/key/Devender-Aggarwal.webp" class="w-100" alt="Signature Global - Co-Founder & Joint Managing Director" title="Signature Global - Co-Founder & Joint Managing Director">
            </div>
            <div class="title-sec">
               <div>
                  <h3><span>Mr. Devender Aggarwal</span>
                  <p>Joint Managing Director and Whole-time Director</p>
                    </h3>
               </div>
               <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="7">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
               </a>
            </div>
         </div>
        </div>
        <div class="col-md-3 mb-40">
           <div class="director-thumb">
            <div class="thumb-pic">
               <img src="images/key/Ravi-Aggarwal.webp" class="w-100" alt="Signature Global - Co-Founder & Managing Director" title="Signature Global - Co-Founder & Managing Director" >
            </div>
            <div class="title-sec">
               <div>
                  <h3><span>Mr. Ravi Aggarwal</span>
                  <p>Managing Director</p>
                    </h3>
               </div>
               <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="6">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
               </a>
            </div>
         </div>
        </div>
         <div class="col-md-3 mb-40">
            <div class="director-thumb">
               <div class="thumb-pic">
                  <img src="images/key/rajat-kathuria-thumb.webp" class="w-100" alt="Signature Global - CEO" title="Signature Global - CEO">
               </div>
               <div class="title-sec">
                  <div>
                     <h3><span>Mr. Rajat Kathuria</span>
                     <p>Chief Executive Officer (CEO) - Signatureglobal (India) Limited</p>
                       </h3>
                  </div>
                  <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="12">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                  </a>
               </div>
            </div>
         </div>
         <div class="col-md-3 mb-40">
            <div class="director-thumb">
               <div class="thumb-pic">
                  <img src="images/key/sanjay-kumar-varshney.webp" class="w-100" alt="Signature Global - COO" title="Signature Global - COO">
               </div>
               <div class="title-sec">
                  <div>
                     <h3><span>Mr. Sanjay Kumar Varshney</span>
                     <p>Chief operating officer (COO) - Signatureglobal (India) Limited</p>
                       </h3>
                  </div>
                  <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="8">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                  </a>
               </div>
            </div>
         </div>
           <div class="col-md-3 mb-40">
            <div class="director-thumb">
               <div class="thumb-pic">
                  <img src="images/key/manish-garg-thumb.webp" class="w-100" alt="Signature Global - Deputy CFO" title="Signature Global - Deputy CFO" >
               </div>
               <div class="title-sec">
                  <div>
                     <h3><span>Mr. Manish Garg</span>
                     <p>Chief Financial Officer (CFO) - Signatureglobal (India) Limited</p>
                       </h3>
                  </div>
                  <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="10">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                  </a>
               </div>
            </div>
         </div>
         <div class="col-md-3 mb-40">
            <div class="director-thumb ">
               <div class="thumb-pic">
                  <img src="images/key/Mr.Vothra..webp" class="w-100" alt="Signature Global - Legal & Compliance Officer" title="Signature Global - Legal & Compliance Officer">
               </div>
               <div class="title-sec">
                  <div>
                     <h3><span>Mr. Meghraj Bothra</span>
                     <p>Company Secretary and Compliance Officer - Signatureglobal (India) Limited</p>
                       </h3>
                  </div> 
                  <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="19">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                  </a>
               </div>
            </div>
         </div> 
        
      
        
       
        
        
        <!-- <div class="col-md-3 mb-40">
            <div class="director-thumb">
               <div class="thumb-pic">
                  <img src="images/key/suraj-malik-thumb.jpg" class="w-100" alt="Signature global CFO" title="Signature global CFO">
               </div>
               <div class="title-sec">
                  <div>
                     <span>Mr. Suraj Malik</span>
                     <p>CFO, Signatureglobal (India) Limited</p>
                  </div>
                  <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="9">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                  </a>
               </div>
            </div>
         </div> -->
        
         
   <!--     <div class="col-md-3 mb-40">
            <div class="director-thumb ">
               <div class="thumb-pic">
                  <img src="images/key/nupur-garg.jpg" class="w-100" alt="Signature Global - Legal & Compliance Officer" title="Signature Global - Legal & Compliance Officer">
               </div>
               <div class="title-sec">
                  <div>
                     <span>Ms. Nupur Garg</span>
                     <p>Deputy Legal & Compliance Officer - Signatureglobal (India) Limited</p>
                  </div>
                  <a class="arrow-btn show-popup" href="javascript:void(0)" popup-id="11">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                  </a>
               </div>
            </div>
         </div> -->
       
      </div>
   </div>
</section>

<!--our architects -->
<section class="architect-sec pad120" id="our-architects">
   <div class="container">
      <div class="row">
         <div class="col-md-12 relative">
            <h5 class="wow animate__ animate__fadeInUp">Our Architects</h5>
            <div class="control pull-right">
                <span class="arrow-icon-left3">
                   <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                </span>
               <span class="arrow-icon-right3">
                   <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
               </span>
            </div>
         </div>
        
        <div class="col-md-12">
          <div class="architect-slider row">
         <div class="col-md-4">
            <div class="director-thumb my-0">
               <div class="thumb-pic">
                  <img src="images/key/hafeez-thumb.jpg" class="w-100" alt="Signature global Awarded Padma Bhushan" title="Signature global Awarded Padma Bhushan">
               </div>
               <div class="title-sec">
                  <div>
                     <span>Mr. Hafeez Contractor</span>
                     <p>Padmabhushan Recipient</p>
                     <!--<p>Awarded Padma Bhushan by the President</p>-->
                  </div>
                  <a class="arrow-btn arrow-btn1 show-popup" href="javascript:void(0)" popup-id="1">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91">
                        <defs>
                           <style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style>
                        </defs>
                        <g id="Layer_2" data-name="Layer 2">
                           <g id="Layer_1-2" data-name="Layer 1">
                              <polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline>
                              <line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line>
                           </g>
                        </g>
                     </svg>
                  </a>
               </div>
            </div>
         </div>
         <div class="col-md-4">
            <div class="director-thumb">
               <div class="thumb-pic">
                  <img src="images/key/gp-mathur-thumb.jpg" class="w-100" alt="Signature global Chief Architect" title="Signature global Chief Architect">
               </div>
               <div class="title-sec">
                  <div>
                     <span>Mr. G.P. Mathur</span>
                     <p>Chief Architect</p>
                  </div>
                  <a class="arrow-btn arrow-btn1 show-popup" href="javascript:void(0)" popup-id="2">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91">
                        <defs>
                           <style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style>
                        </defs>
                        <g id="Layer_2" data-name="Layer 2">
                           <g id="Layer_1-2" data-name="Layer 1">
                              <polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline>
                              <line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line>
                           </g>
                        </g>
                     </svg>
                  </a>
               </div>
            </div>
         </div>
         <div class="col-md-4">
            <div class="director-thumb">
               <div class="thumb-pic">
                  <img src="images/key/deepak-mehta-thumb.jpg" class="w-100" alt="Signature global  R.C.O.A , A.I.I.A,Govt." title="Signature global  R.C.O.A , A.I.I.A,Govt.">
               </div>
               <div class="title-sec">
                  <div>
                     <span>Ar. Deepak Mehta</span>
                     <p>R.C.O.A , A.I.I.A,Govt., Appd. valuer – CAT-I</p>
                  </div>
                  <a class="arrow-btn arrow-btn1 show-popup" href="javascript:void(0)" popup-id="3">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91">
                        <defs>
                           <style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style>
                        </defs>
                        <g id="Layer_2" data-name="Layer 2">
                           <g id="Layer_1-2" data-name="Layer 1">
                              <polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline>
                              <line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line>
                           </g>
                        </g>
                     </svg>
                  </a>
               </div>
            </div>
         </div>
            <div class="col-md-4">
            <div class="director-thumb">
               <div class="thumb-pic">
                  <img src="images/key/profile-thumb.jpg" class="w-100" alt="Signature global Director Architecture" title="Signature global Director Architecture">
               </div>
               <div class="title-sec">
                  <div>
                     <span>Ms Meenakshi  Khanna</span>
                     <p>Director Architecture, GRID PLC</p>
                  </div>
                  <a class="arrow-btn arrow-btn1 show-popup" href="javascript:void(0)" popup-id="15">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91">
                        <defs>
                           <style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style>
                        </defs>
                        <g id="Layer_2" data-name="Layer 2">
                           <g id="Layer_1-2" data-name="Layer 1">
                              <polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline>
                              <line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line>
                           </g>
                        </g>
                     </svg>
                  </a>
               </div>
            </div>
         </div>
         
         <div class="col-md-4">
            <div class="director-thumb">
               <div class="thumb-pic">
                  <img src="images/key/rohit-garg-thumb.jpg" class="w-100" alt="Signature global Senior Architect" title="Signature global Senior Architect">
               </div>
               <div class="title-sec">
                  <div>
                     <span>Ar. Rohit Garg</span>
                     <p>Senior Architect</p>
                  </div>
                  <a class="arrow-btn arrow-btn1 show-popup" href="javascript:void(0)" popup-id="16">
                     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91">
                        <defs>
                           <style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style>
                        </defs>
                        <g id="Layer_2" data-name="Layer 2">
                           <g id="Layer_1-2" data-name="Layer 1">
                              <polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline>
                              <line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line>
                           </g>
                        </g>
                     </svg>
                  </a>
               </div>
            </div>
         </div>
         
        </div>
          </div>
          </div>
      
   </div>
</section>



<section class="vision-sec pad120" id="vission-mission">
   <div class="container">
      <div class="row">
         <div class="col-md-6">
            <div class="vission-content">
               <h2 class="wow animate__ animate__fadeInUp">Vision</h2>
               <p class="wow animate__ animate__fadeInUp">Our vision is to redefine the current conventions of Indian real estate development by championing excellence—in craftsmanship, planning and service. The greatest residential architectural marvels of the world shall rise here, defining luxury as a lifestyle lived every day.</p>
            </div>
         </div>
         <div class="col-md-6">
            <div class="mission-content">
               <h2 class="wow animate__ animate__fadeInUp">Mission</h2>
               <p class="wow animate__ animate__fadeInUp">To become the fastest growing pan-India company, with a versatile portfolio of properties, hailed for their design ingenuity, construction quality and long term value. To stand for the highest standards in real estate quality both in terms of planning and executing ambitious projects and offering our clients with the very best in urban luxury.</p>
            </div>
         </div>
      </div>
   </div>
</section>
<section class="foundation pad120">
   <div class="container">
      <div class="row">
         <div class="col-md-12">
            <span class="captext fcolorlgt wow animate__ animate__fadeInUp" >CORPORATE SOCIAL RESPONSIBILITY</span>
            <h2 class="headingtag fcolordrk wow animate__ animate__fadeInUp" >Signature Global Foundation</h2>
         </div>
         <div class="col-md-12 ">
            <div class="foundation-bg">
               <div class="foundation-content pull-right">
                  <p class="wow animate__ animate__fadeInUp">Signature global Foundation Trust, the humanitarian arm of Signatureglobal (India) Limited aims to empower society by providing multiple opportunities for the underprivileged. This is a charitable Trust formed under provisions of the Indian Trust Act 1882 under the direct guardianship of Mr. Pradeep Kumar Aggarwal, Founder and Chairman.</p>
                  <div class="clabtn1 wow animate__ animate__fadeInUp" >
                     <a class="abtn halvar_rg wow animate__ animate__fadeInUp" href="signature-global-foundation.php" title="Signature Global Foundation">
                        Discover More 
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91">
                           <g id="Layer_2" data-name="Layer 2">
                              <g id="Layer_1-2" data-name="Layer 1">
                                 <polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline>
                                 <line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line>
                              </g>
                           </g>
                        </svg>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<div class="slide-popup" id="popup-slide">
   <a href="javascript:void(0)" class="closebtn" onclick="closePopup()">&times;</a>
   <div class="row">
      <div class="col-lg-6 col-md-12">
         <div class="image-thumb">
            <img src="" class="w-100 popup-image" alt="Mr. Pradeep Aggarwal" title="Mr. Pradeep Aggarwal">
         </div>
      </div>
      <div class="col-lg-6 col-md-12">
         <div class="pupup-content">
            <div class="popup-title">
               Mr. Pradeep Aggarwal
            </div>
            <span class="popup-designation">Founder & Chairman </span>
            <div class="popup-scroll scroll">
               <p>With a rich experience of around two decades in financial capital market and commodity market, Mr. Aggarwal brings motivation with emphasis on ethical professional approach . His in-depth knowledge of various intricacies of securities market and financial services led him to diversify the arbitrage business. With a keen desire to do more, he ventured into the real estate business under the brand name 'Signature Global', focusing on Affordable Housing which is key to the growth of housing in India. With a grand vision and mission of 'Har Pariwar Ek Ghar' (House for Every Family), Mr Aggarwal has been contributing significantly to Prime Minister Narendra Modi's flagship mission of 'Housing for All by 2022'. With a target to launch one lakh affordable homes by 2022, he has already made a mark by launching close to a dozen affordable housing projects in the National Capital Region. With a clear focus on contemporary designs,modern construction technology global quality standards, timely delivery and affordability, Mr Aggarwal has won great recognition from home buyers. So much so that he has earned the sobriquet of 'Affordable Man'. Having already launched successful housing projects of global standards in Haryana and in Uttar Pradesh and delivering one of these projects ahead of time , Mr Aggarwal has now set his eyes to expand and explore newer regions across India to develop new affordable housing projects. His rich acumen and domain knowledge along with excellent inter-personal communication skills and keen desire to innovate and implement new ideas to business, has endeared him to both customers and industry professionals. With his unmatched integrity and vision, Mr Aggarwal is set to create new benchmarks in real estate , especially in the domain of affordable housing.</p>
            </div>
         </div>
      </div>
   </div>
</div>
<div class="chaticon">
   <span><i class="fa fa-commenting-o" aria-hidden="true"></i></span>
</div>

<!--Footer-->
    <footer class="footerbg padd100">
       <div class="width100">
            <div class="container">
                <div class="row paddb60">
                   <div class="col-12">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt m-0 wow animate__ animate__fadeInUp">
                                    <strong>SIGNATURE GLOBAL</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/residential/" title="Residentential projects by Signature Global">Residential</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/" title="Commercial projects by Signature Global">Commercial</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/">Retail</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class=" footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>OUR PRESENCE</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/commercial/society-shops/gurugram/" title="Signature Global in Gurugram">Gurugram</a></li>
                                        <li><a href="https://www.signatureglobal.in/residential/plots/karnal" title="Signature Global in Karnal">Karnal</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/ghaziabad" title="Signature Global in Ghaziabad">Ghaziabad</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>ABOUT US</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" title="Signature Global - Chairman's message" class="scdown">Chairman’s Message</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" title="Signature Global - Board of Director" class="scdown">Board of Directors</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" title="Signature Global - Key Managerial Positions" class="scdown">Key Managerial Positions</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" title="Our Architect" class="scdown">Our Architects</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" title="Signature Global - Vission & Mission of Signature Global" class="scdown">Vision & Mission</a></li>
                                    <!--    <li><a href="signature-global-foundation.php" title="Signature Global Foundation">Signature Global Foundation</a></li>-->
                                    </ul>
                                </div>
                           </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>CAREERS</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/career.php#as-associate" title="Careers at Signature Global">As Associate</a></li>
                                        <li><a href="https://www.signatureglobal.in/career.php#life-signature" title="Life At Signature Global">Life @ Signature Global </a></li>
                                        <li><a href="#"></a></li>
                                    </ul>
                                </div>
                              
                                <div class="footernav halvar_lt wow animate__ animate__fadeInUp publicnoticehome">
                                  <ul>
                                    <li><a href="https://www.signatureglobal.in/public-notice.php" title="Signature Global Public Notice"><strong>Public Notice</strong></a></li>
                                  </ul>                                  
                             	</div>
                                          
                           </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong style="margin-bottom: 15px;">GALLERY</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/gallery.php" title="Signature Global Gallery">Picture Library</a></li>
                                        <li><a href="https://www.signatureglobal.in/video-gallery.php" title="Signature Global Video Gallery">Video Library</a></li>
                                    </ul>
                                </div>   
                            </div>
                           <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/media.php" title="Signature Global Blogs">MEDIA</a></strong> 
                                    <ul>
                                     <li><a href="https://www.signatureglobal.in/media-coverage.php" title="Signature Global Gallery">Media Coverage</a></li>
                                        <!--<li><a href="https://www.signatureglobal.in/press-release.php" title="Signature Global Video Gallery">Press Release</a></li> -->
                                         <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Gallery">Press Kit</a></li>
                                        <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Video Gallery">Media Contact</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                   <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/blog" title="Signature Global Blogs">Blog</a></strong>
                                <!--    <strong class="mb-2"><a class="clrwh opctext" href="https://online.anyflip.com/dhkmm/nalj/mobile/index.html" target="_blank" title="Signature Global Newsletter ">NEWSLETTER</a></strong> -->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/home-loans.php" title="Signature Global - Home Loans">Home Loans</a></strong>
                                  <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/pay-online.php" title="Signature Global - APPLY ONLINE">PAY ONLINE</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/award.php" title="Signature Global Certificates">AWARD</a></strong>                                  
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                 <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" target="_blank" title="Signature Global Login">MBDA/BDA Login</a></strong>
                                   <!-- <strong class="mb-2"><a class="clrwh opctext" href="http://signatureglobal04.realboost.in/add_appointment.aspx" target="_blank" title="Signature Global Appointments">Appointment</a></strong>-->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/terms-of-appointment.php" title="Signature Global - Terms of appointment">Terms of Appointment</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/green-development.php" title="Signature Global - Green Development">Green Development</a></strong>
                                </div>     
                            </div>
                        </div>
                        
                   </div>
                </div>
            </div>
        </div>
      
        
        <div class="width100 bordertop padt60 wow animate__ animate__fadeInUp">
            <div class="container">
                <div class="row">    
                    <div class="col-lg-3">
                       <div class="footerlogo wow animate__ animate__fadeInUp">
                           <img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/>
                       </div> 
                    </div>
                    <div class="col-lg-4">
                        <div class="footernav pl-65 wow animate__ animate__fadeInUp">
                            <strong>REGISTERED OFFICE</strong>
                            <p>13<sup>th</sup> Floor, Dr. Gopal Das Bhawan, 28<br class="ftmb"/> Barakhamba Road, Connaught Place,<br class="ftmb"/> New Delhi 110 001, India.</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Registered Office: +91 11 4928 1700</a>
                        </div>
                    </div>
                    <div class="col-lg-3 pl-00">
                        <div class="footernav wow animate__ animate__fadeInUp">
                            <strong>CORPORATE OFFICE</strong>
                            <p>Unit No.101, Ground Floor, Tower-A,<br class="ftmb"/>Signature Tower South City-1, Gurugram,<br class="ftmb"/>Haryana 122 001, India</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Corporate Office: +91 124 4398 011</a>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="footermedianav mtopft wow animate__ animate__fadeInUp">
                            <strong>FOLLOW US</strong>
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </footer>
     <!--policytab-->
     <div class="policywraper">
         <div class="container">
             <div class="row">
                 <div class="col-lg-10 col-md-10">
                     <div class="policylink text-left">
                        <p>© 2023 Signature Global. All Rights Reserved <br class="mobhidebr"/><span class="clrwh mobhide">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/advertising-policy-for-channel-partners.php"  >Advertising Policy For Channel Partners</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/privacy-policy.php" title="Signature Global - Privacy Policy">Privacy Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/social-media-policy.php" title="Signature Global - Social Media Policy">Social Media Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/generic-faqs-for-haryana-affordable-housing-policy.php">Generic Faq's</a>                        
                       </p>
                       
                     </div>
                  
                 </div>
             <!--     <div class="col-lg-2 col-md-2 cclogo ">
                     <img src="https://www.signatureglobal.in/images/cogdigital.svg" alt="" width="15">
                   </div> -->
             </div>
         </div>
     </div>
   
    <script>
         $.urlParam = function (name) {
            var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);
            return (results !== null) ? results[1] || 0 : false;
            }
            
            var utmSource = $.urlParam('utm_source') ? $.urlParam('utm_source') : 'direct';
            var utmMedium = $.urlParam('utm_medium') ? $.urlParam('utm_medium') : '';
            var utmCampaign = $.urlParam('utm_campaign') ? $.urlParam('utm_campaign') : '';
            var utmId = $.urlParam('utm_id') ? $.urlParam('utm_id') : '';
             
            var enq_url = new URL("https://enquiry.signatureglobal.in/?projectName=ContactUs&enquiryFrom=Online");
            $(function() {
                    enq_url.searchParams.set('utm_source',utmSource);
                    if(utmMedium!=""){enq_url.searchParams.set('utm_medium',utmMedium);}
                    if(utmCampaign!=""){enq_url.searchParams.set('utm_campaign',utmCampaign);}
                    if(utmId!=""){enq_url.searchParams.set('utm_id',utmId);}
                    
              if($('#main_frame').length > 0)
                    $('#main_frame').attr('src', enq_url)
            
            });

    </script>


<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/animate.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/jquery.fancybox.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/slick.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>


<script src="https://www.signatureglobal.in/js/wow.min.js"></script>
<script src="https://www.signatureglobal.in/js/slick.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.fancybox.min.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.validate.min.js"></script>
<script src="https://www.signatureglobal.in/js/additional-methods.js"></script>
<script src="https://www.signatureglobal.in/js/custom.js"></script> 
<script src="https://www.signatureglobal.in/js/app.js"></script> 
<!-- Start of  Zendesk Widget script -->
<script>
   setTimeout(function(){
      var chatScript = '<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"/>';
      $('body').append(chatScript);
   },  
 5000);
</script>

<script>
  window.addEventListener('load', function() {
    jQuery('body').on('mousedown', '[href*="tel:"]', function() {
      gtag('event', 'phone_call')
    })
    jQuery('body').on('mousedown', '[href*="api.whatsapp.com"]', function() {
      gtag('event', 'whatsapp_click')
    })
    jQuery('body').on('mousedown', '.btnrt:contains(Enquire Now)', function() {
      gtag('event', 'enquire_now')
    })
    jQuery('body').on('mousedown', '.contact100-form-btn:contains(Submit)', function() {
      gtag('event', 'Submit_btn')
    })
  });

</script>
<!--<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"> </script>-->
<!-- End of  Zendesk Widget script -->





 


</body>
</html>
<script>
   $(document).ready(function () {
       
       $(document).on('click', '.show-popup', function() {
               $.ajax({ url:"load-team.php", method:"POST", 
                           data: 'id='+ $(this).attr('popup-id'),
                           success:function(response){
                           var $json = $.parseJSON(response)
                           $('.popup-image').attr('src','images/key/' + $json.image)
                           $('.popup-title').html($json.name)
                           $('.popup-designation').html($json.designation)
                           $('.popup-scroll').html($json.description)
                           document.getElementById("popup-slide").style.marginRight = "0%";
                           $('body').addClass('overflowHide');
               		}
              });
       })
      
      
    
   
       
   
   });
   
   function closePopup() {
     document.getElementById("popup-slide").style.marginRight = "-100%";
      $('body').removeClass('overflowHide');
   }
   
</script>