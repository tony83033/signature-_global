<!doctype html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> Affordable Housing Projects in Gurgaon - Signature Global</title>
<meta name=description content="Signature Global is a brand which stands for Making India Affordable. Provide best affordable housing in Gurgaon. Signature Global offer commercial and residential properties in Gurgaon with in your budget." />
<meta name=keywords content="Affordable Housing, New project in Gurugram, best project in Gurgaon, real estate project in Gurgaon, flats in gurgaon, flats in Delhi, Residential Flats in Gurugram, affordable housing in Gurgaon. Residential projects in Gurgaon, Pradhan mantri awaas yojna, Retail Shops in Gurugram" />
<link href=https://webtestinglink.net/signature-global-new/images/favicon.png rel="shortcut icon" type=image/x-icon>

<script src="js/jquery.min.js"></script>
<script src="https://kit.fontawesome.com/017cdcc9e5.js" crossorigin="anonymous"></script>
<link rel="stylesheet" href="css/bootstrap.min.css" />
<link rel="stylesheet" href="css/style.css" />
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<style>
    .thanktext{ width:100%; position:absolute; z-index:11;padding-bottom: 50px;}
    .thankyoubanner{ background-image:url(images/thanksbanner.jpg);}
    
        .clabtn1 .abtn {
    width: 165px;
    height: 50px;
    border: 1px solid #fff;
    opacity:1;
    color: #fff;
    font-size:14px;
    }
    
    .clabtn1 {
     position: relative;
    }
    
    .clabtn1 .abtn:hover {
    background: #203D3B;
    border: 1px solid #203D3B;
    color: #fff;
    
}
    
    .clabtn1 .cls-1 {
    fill: none;
    stroke: #fff;
    stroke-linecap: round;
    stroke-linejoin: round;
}
    @media(max-width:767px){
        .thankyoubanner{ background-image:url(images/thanks-mob-banner.jpg);}
        .mhide{display:none;}
        .headingtag{ font-size:2.5rem;}
    }
</style>
</head>
<body>
    <section class="banner thankyoubanner">
        <div class="mainbanneroverlay"></div>
        <div class="container">
            <div class="thanktext">
                <h1 class="headingtag clrwh mb-2">Thank you for<br class="mhide"/> contacting us</h1>
                <p class="clrwh mb-4">We shall revert to your enquiry shortly.</p>
                <div class="clabtn1" >
                        <a class="abtn halvar_rg" href="index.php">
                            Back to Home
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                        </a>
                    </div>
            </div>
        </div>
    </section>
</body>
</html>