<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="facebook-domain-verification" content="zqv18clg4hyd5synd83cbrczwv588t" />
<title> Signature Global Imperial Gurgaon</title>
<meta name=description content="Signature Global Imperial is another Haryana Affordable Housing project which is Bang on Pataudi road and well-connected from Hero Honda Chowk and NH-8" />
<meta name=keywords content="Signature Global Imperial, Signature Global Imperial sector 88A Gurgaon, affordable housing projects in sector 88A Gurgaon, Signature Global Imperial Sector 88A Gurugram, Signature Global Imperial Gurgaon, Residential flats in sector 88A Gurgaon, Apartments in sector 88A Gurgaon, New Housing Projects in sector 88A Gurgaon, Signature Global Imperial Gurgaon, 1 BHK flats in Gurgaon , Affordable housing project in sector 88A Gurgaon, Affordable homes in sector 88A Gurgaon, Residential project in Gurgaon sector 88A, Affordable flats in sector 88A Gurgaon, 3 BHK flats in gurgaon, Imperial Sector 88A Gurgaon, New Projects in Gurgaon, Flats in sector 88A Gurgaon, 3 BHK Flats in sector 88A Gurgaon, Signature Global Imperial Gurgaon" />
<link rel="canonical" href="https://www.signatureglobal.in/sg-imperial.php" />
<meta name="robots" content="noodp" />
 

    
  
  
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5S8ZC8X');</script>
<!-- End Google Tag Manager -->
  
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-90138100-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'UA-90138100-1');
</script>
  
  

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-MRPZNF8ZD2"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-MRPZNF8ZD2');
</script>
  
<!-- Global site tag (gtag.js) - Google Ads: 962082073 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-962082073"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config','AW-962082073', {'allow_enhanced_conversions':true});
</script>
<script>
  gtag('config', 'AW-962082073/BUgQCILmzakDEJnq4MoD', {
    'phone_conversion_number': '7053-121-121'
  });
</script>
  
  

  
<!-- Meta Pixel Code -->
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '359225061117882');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=359225061117882&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
<link href=https://www.signatureglobal.in/images/favicon1.png rel="shortcut icon" type=image/x-icon>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/bootstrap.min.css"/>
<link  rel="stylesheet"  href="https://www.signatureglobal.in/css/fontawesome/css/all.min.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/style.css"/>
<link rel="stylesheet"  href="https://www.signatureglobal.in/css/responsive.css"/>
<script src="https://www.signatureglobal.in/js/jquery.min.js"></script>
<script  src="https://www.signatureglobal.in/js/bootstrap.min.js"></script>
<style>
  .shhhow{display:block !important; opacity:1 !important;}
  }
</style>

</head>
<body>
  <!-- Google Tag Manager (noscript) -->
<noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5S8ZC8X"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->

        
    <header class="header-area">
        <div class="overlayhd"></div>
        <nav class="navbar navbar-expand-md navbar-dark">
            <div class="container">
                <a href="https://www.signatureglobal.in/" class="navbar-brand"><img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/></a> 
                <div class="mobiconbtn">
                    <a href="tel:+91-7053121121">
                        <svg id="Layer_4" data-name="Layer 4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><circle class="cls-1 cls2" cx="75" cy="75" r="73.55"/><path d="M54.68,41.25,50,41a5.64,5.64,0,0,0-4,1.36c-2.25,2-5.86,5.76-7,10.69-1.66,7.37.9,16.39,7.51,25.4S65.5,101.9,87.29,108.06c7,2,12.55.65,16.81-2.08a15,15,0,0,0,6.54-9.54l.75-3.47a2.43,2.43,0,0,0-1.35-2.7L94.3,83a2.41,2.41,0,0,0-2.92.71l-6.18,8a1.78,1.78,0,0,1-2,.6C79,90.85,64.81,84.91,57,69.93a1.77,1.77,0,0,1,.23-2l5.9-6.83a2.41,2.41,0,0,0,.39-2.53L56.77,42.71A2.42,2.42,0,0,0,54.68,41.25Z"/></svg>
                    </a>
                    <a id="forother" href="https://api.whatsapp.com/send?phone=%2B917303918365&text=Hii%2C+I+am+interested+in+Signature%20Global+Affordable+Housing">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>
                  	<a id="forwhatsapp" href="https://api.whatsapp.com/send?phone=919311144622&amp;text=">
                        <svg id="Layer_5" data-name="Layer 5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 150 150"><defs><style>.cls-1{fill:#4dcb5b;}.cls-2{fill:#fdfdfd;}.cls-3{fill:#fff;}</style></defs><path class="cls-1" d="M75,146.09a71,71,0,0,1-37-10.36L34.2,133.4l-22.66,5.83,6.16-21.87-2.57-4A71.1,71.1,0,1,1,75,146.09Z"/><path class="cls-2" d="M75,6.91A68.09,68.09,0,1,1,39.58,133.17l-2.73-1.67-2.17-1.32-2.46.63L15.84,135l4.38-15.56.73-2.6-1.46-2.27-1.84-2.86A68.12,68.12,0,0,1,75,6.91m0-6A74.11,74.11,0,0,0,12.61,115l1.84,2.86-7.21,25.6,26.48-6.82,2.73,1.67A74.1,74.1,0,1,0,75,.91Z"/><path class="cls-3" d="M53,38.56l-5.09-.28a6.16,6.16,0,0,0-4.38,1.5c-2.47,2.14-6.42,6.29-7.63,11.69-1.81,8.05,1,17.92,8.22,27.78s20.71,25.64,44.55,32.38c7.68,2.17,13.72.71,18.38-2.27a16.46,16.46,0,0,0,7.15-10.44l.82-3.8a2.65,2.65,0,0,0-1.48-3L96.32,84.24a2.65,2.65,0,0,0-3.2.78l-6.75,8.76a1.94,1.94,0,0,1-2.18.65c-4.62-1.63-20.12-8.12-28.63-24.5a1.94,1.94,0,0,1,.25-2.18l6.45-7.47a2.63,2.63,0,0,0,.43-2.76L55.27,40.16A2.62,2.62,0,0,0,53,38.56Z"/></svg>
                    </a>	
                  
                </div>
                <button type="button" class="navbar-toggler collapsed" data-target="#main-nav">
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                    <span class="menu-icon-bar"></span>
                </button>                
                <div id="main-nav" class="navbar-collapse">
                    <div class="topnavbaxy">
                        <ul class="navbar-nav width100 dlfx">                         
                         <!--   <li><a href="career.php" class="nav-link" title="Signature Global - Carrer">Career </a></li> -->
                            <li class="dropdown loginpage">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">LOGIN <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://signatureglobal2.my.salesforce-sites.com/sg?cpForm=true" class="assreg" target="_blank">Associate Registration</a></li>
                                     <li><a href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" class="assreg" target="_blank">MBDA/BDA Login</a></li>
                                     <li><a href="https://app.hrone.cloud/login" class="assreg assreg1" target="_blank">Employee Login</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                        <!--    <li><a href="pay-online.php" class="nav-link" title="Signature Global  - Pay Online">APPLY ONLINE</a></li>-->
                            <li><a href="https://www.signatureglobal.in/investor.php" class="nav-link" title="Signature Global  - Investor">Investor</a></li> 
                            <li><a href="https://www.signatureglobal.in/customer_support.php" class="nav-link" title="Signature Global  - Custome Support">Customer Support </a></li>                         
                   <!--      <li><a href="pdf/SG_Mobile_App_User_Manual.pdf" class="nav-link" target="_blank">Mobile app User Manual</a></li>-->
                         <li><a href="https://www.signatureglobal.in/signature-global-foundation.php" class="nav-link" target="_blank">Signature Global Foundation</a></li>                        
                        </ul>
                    </div>                     
                    <ul class="navbar-nav width100 dlfx ">
                   <!--     <li class="nav-item">
                          <a href="about-us.php" class="nav-link" title="Signature Global  - About Us">About US </a>
                          
                      </li>-->
                      
                       <li class="nav-item dropdown loginpage position-relative">
                              <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">About US <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                               <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                   <ul>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#companyjourney" class="assreg scdown"> Company's Journey</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" class="assreg scdown" >Chairman's Message</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" class="assreg scdown" >Board of Directors</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" class="assreg scdown">Key Managerial Positions</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" class="assreg scdown" >Our Architects</a></li>
                                     <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" class="assreg scdown">Vision & Mission</a></li>
                                     <li><a href="https://www.signatureglobal.in/career.php#life-signature" class="assreg" target="_blank"> Life @ Signature Global</a></li>
                                     <li><a href="https://www.signatureglobal.in/green-development.php" class="assreg assreg1" target="_blank">Green Development</a></li>
                                  </ul>
                                </div>
                          	</div>
                          </li>
                      
                        <li class="nav-item dropdown">
                            <a href="#" title="Residentential projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">RESIDENTIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                            <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-5">
                                                <strong>Residential</strong>
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/residential/affordable/">Affordable Group Housing</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/premium/">Premium Independent Floors</a></li>
                                                    <li><a href="https://www.signatureglobal.in/residential/plots/">Residential Plots</a></li>
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/residential?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div> 
                                            </div>
                                            <div class="col-lg-8 col-md-7">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5 col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Residential</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/residential/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_6" data-name="Layer 6"><g id="Layer_1-6" data-name="Layer 6"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Resdential-nvbg.jpg" alt="Residential Projects by Signature Global
" title="Residential Projects by Signature Global
">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item dropdown">
                          <a href="#" title="Commercial projects by Signature Global" class="nav-link addac hdbg dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">COMMERCIAL <img src="https://www.signatureglobal.in/images/icon/arrow-down-wh.svg" alt="" title=""/></a>
                          <div class="dropdown-menu abdrop">
                                <div class="subnavdown paddn60">
                                    <div class="container">
                                        <div class="row">
                                            <div class="col-lg-4 col-md-6 ">
                                                <strong>Commercial</strong>
                                    
                                                <ul>
                                                    <li><a href="https://www.signatureglobal.in/commercial/society-shops/">Society Shops</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/malls/">Mall</a></li>
                                                    <li><a href="https://www.signatureglobal.in/commercial/sco-plots/">SCO</a></li> 
                                                </ul>
                                                <div class="dskhide">
                                                    <ul>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=ongoing">Ongoing Projects</a></li>
                                                      <li><span>|</span></li>
                                                        <li><a href="https://www.signatureglobal.in/commercial?status=delivered">Delivered</a></li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="col-lg-8 col-md-6 ">
                                                <div class="rightnavpro">
                                                    <div class="row">
                                                        <div class="col-lg-5  col-md-6">
                                                            <div class="projectsbtn">
                                                                <strong>Commercial</strong>
                                                                <div class="pronavbtn">
                                                                    <a class="abtn halvar_rg" href="https://www.signatureglobal.in/commercial/">
                                                                        View Projects 
                                                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><g id="Layer_7" data-name="Layer 7"><g id="Layer_1-7" data-name="Layer 7"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"></polyline><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"></line></g></g></svg>
                                                                    </a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-lg-7 col-md-12">
                                                            <div class="navproimg">
                                                                <img src="https://www.signatureglobal.in/images/Commercial-nvbg.jpg" alt="Commercial Projects by Signature Global" title="Commercial Projects by Signature Global">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                          </div>
                        </li>
                        <li class="nav-item"><a title="Signature Global  - Contact Us" href="https://www.signatureglobal.in/contact.php" class="nav-link">CONTACT US </a></li>
                    </ul>
                    <div class="bottommediamobwrap">
                        <ul class="pplink">
                            <li><a href="https://www.signatureglobal.in/privacy-policy.php">Privacy Policy</a></li>
                          <li><span>|</span></li>
                            <li><a href="https://www.signatureglobal.in/social-media-policy.php">Social Media Policy</a></li>
                        </ul>
                        <div class="footermedianav mtopft">
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </nav>
    </header>
    <div class="overlaymobbg"></div>    

     <!--Download Brochure-->
    <div class="downloadbtnwrap">
        <a href="/pdf/imperial/SG_Imperial_Multipager_21.2.20222_Spread.pdf" target="_blank" class="btnrt" alt="">Download Brochure</a>
    </div>
    <!--Download Brochure-->
    
    <!--Enquire Now Iframe-->
   <div class="registerform">
        <div class="fixedbtn">
            <span class="btnrt">Enquire Now</span>
        </div>
        <div class="innerform">
            <iframe  frameborder="0" width="100%" height="400px" id="abc_frame"></iframe>
        </div>
    </div>
    <!--Enquire Now Iframe-->
    
    <!--banner section-->
    <div class="banner sg-imperial-bannner padd100">
        <div class="overlaybottom"></div>
        <div class="container">
            <div class="cpationlogo">
                <span><img src="/images/logo/imperial.png" alt="Signature Global Imperial" title="Signature Global Imperial"/></span>
            </div>
       	<div class="delevered-stam">
                <img src="/images/projects/signum37d-iv/Banner/logo.svg" alt="Delevered Stam" class="igbc-logo">
            </div> 
        </div>
    </div>
    <!--banner-->
    <!--rera no-->
    <div class="afterimg">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        <span>HRERA Number : RC/REP/HARERA/GGM/544/276/2022/19</span>
                     <!-- <a href="https://payment.signatureglobal.in/sg/imperial.aspx" target="_blank" ><span class="blink_me">REGISTRATION</span></a>-->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--rera no-->
    
    <!--Welcome Section-->
    <div class="sectionbg-one">
        <div class="innerprobannerbg">
            <div class="container">
                <div class="row padd100">
                    <div class="col-lg-12">
                          <span class="captext wow animate__ animate__fadeInUp">WELCOME TO </span>
                          <h1 class="headingtag clrwh mb-5 wow animate__ animate__fadeInUp">Signature Global Imperial</h1>
                    </div>
                    <div class="col-lg-12">
                        <p class="clrwh wow animate__ animate__fadeInUp">Bang on Pataudi road and well-connected from Hero Honda Chowk, NH-8 and close proximity from Dwarka Expressway, the affordable apartments are spread across 8.93125 acres and built with the latest technology to last for generations. Here, you can rejoice and revitalize in peace and tranquility, while enjoying the benefits of a well-developed location surrounded by well-established societies. IGBC Gold Rated Project where you get everything you need for a modern lifestyle and more at Signature Global Imperial.</p>
                        <p class="clrwh wow animate__ animate__fadeInUp">Sector 88A is one of the most potential sector of Gurugram. Endowed with planned roads like Pataudi Road and excellent infrastructure, this locality is witnessing a steady rise in the number of residential projects. Gurugram is home to innumerable commercial and industrial hubs. This has in turn helped the connectivity in sector 88A, that is aided by local buses, shared autos and taxis. The proposed Metro corridors in Gurugram shall help in strengthening the connectivity further. Due to the increase in population of this locality, a lot of recreational hubs have also come up. Many reputed schools, colleges and universities are situated in and around sector 88A</p>
                    </div>
                    <div class="col-lg-12">
                        <div class="tablewrap padt80 wow animate__ animate__fadeInUp">
                            <div class="table-responsive-lg">
                                <table class="table table-striped table-dark">
                                    <thead>
                                        <tr class="tophd">
                                            <td>S No.</td>
                                            <td>Category (Type)</td>
                                            <td>No. of Units </td>
                                            <td>CARPET AREA <br/>(SQ. M)</td>
                                            <td>Balcony Area <br/> (SQ. M)</td>
                                            <td>CARPET AREA <br/>(SQ. FT.)</td>
                                            <td>Balcony Area <br/>(SQ. FT.)</td>
                                            <td>BASIC SALES PRICE</td>
                                            <td>BALCONY COST</td>
                                            <td>TOTAL COST</td>
                                            <td>5% OF CARPET</td>
                                            <td>ALLOTMENT MONEY</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>01</td>
                                            <td>1BHK</td>
                                            <td>8</td>
                                            <td>36.961</td>
                                            <td>7.98</td>
                                            <td>397.848</td>
                                            <td>85.897</td>
                                            <td>1670962</td>
                                            <td>85897</td>
                                            <td>1756859</td>
                                            <td>83548.08</td>
                                            <td>355667</td>
                                        </tr>
                                        <tr>
                                            <td>02</td>
                                            <td>1BHK+STORE UNIT</td>
                                            <td>295</td>
                                            <td>38.887</td>
                                            <td>5.544</td>
                                            <td>418.58</td>
                                            <td>59.676</td>
                                            <td>1758036</td>
                                            <td>59676</td>
                                            <td>1817712</td>
                                            <td>87901.8</td>
                                            <td>366526</td>
                                        </tr>
                                        <tr>
                                            <td>03</td>
                                            <td>3BHK TYPE I</td>
                                            <td>391</td>
                                            <td>59.996</td>
                                            <td>10.505</td>
                                            <td>645.797</td>
                                            <td>113.076</td>
                                            <td>2712347</td>
                                            <td>100000</td>
                                            <td>2812347</td>
                                            <td>135617.4</td>
                                            <td>567469</td>
                                        </tr>
                                        <tr>
                                            <td>04</td>
                                            <td>3BHK TYPE II</td>
                                            <td>390</td>
                                            <td>59.781</td>
                                            <td>9.42</td>
                                            <td>643.483</td>
                                            <td>101.397</td>
                                            <td>2702629</td>
                                            <td>100000</td>
                                            <td>2802629</td>
                                            <td>135131.4</td>
                                            <td>565526</td>
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                  <div class="col-lg-12">
                    <div class="textwrap mt-4">
                       <h2><p>1 & 3 BHK AFFORDABLE APARTMENTS IN SECTOR 88, NEAR DWARKA EXPRESSWAY, GURUGRAM </p></h2>
                      
                    </div>
                </div>
                </div>
            </div>
        </div>      
    </div>
    <!--Welcome Section-->
    
    <!--3D WALKTHROUGH-->
   <div class="walkthroughwrap padd100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Embrace The Signature Life</h2>
                </div>
                <div class="col-lg-6">
                    <div class="walkvideoiframe wow animate__ animate__fadeInUp">
                       <iframe width="100%" height="400" src="https://www.youtube.com/embed/dYyNVt-xfPw" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
              <div class="col-lg-6">
                    <div class="walkvideoiframe wow animate__ animate__fadeInUp">
                       <iframe width="100%" height="400" src="https://www.youtube.com/embed/BqjUiTtJ74Q" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--3D WALKTHROUGH-->
    
    <!--Location-->
    <div class="locationwrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="locationmap wow animate__ animate__fadeInUp">
                        <a data-fancybox="unit-location" href="/images/projects/imperial/SG-imperial--mobile-Location-Map.jpg">
                            <img src="/images/projects/imperial/SG-imperial--mobile-Location-Map.jpg" alt="Signature Global Imperial Location Advantage" title="Signature Global Imperial Location Advantage"/>
                            <div class="btnclick halvar_rg">
                                <span>Click Here</span>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-lg-5 location-bg">
                    <div class="locationadvantage">
                        <h2 class="headingtag clrwh mb-4 wow animate__ animate__fadeInUp">Location<br/> Advantages</h2>
                        
                        <div class="locationlistslider">
                            <div>
                                <div class="ullist wow animate__ animate__fadeInUp">
                                    <ul>
                                        <li>1.5 Km From Dwarka Expressway.</li>
                                        <li>Bang on Pataudi Road.</li>
                                        <li>The Proposed Metro Corridor is in close proximity.</li>
                                        <li>Railway Station is 4 Km.</li>
                                        <li>ISBT Depot is 4 Km.</li>
                                        <li>IGI Airport is 25 Km.</li>
                                        <li>IMT Manesar is 10.3 KM.</li>
                                        <li>Schools, colleges, hospitals, shopping malls are in close proximity.</li>
                                        <li>Hero Honda Chowk is 9.4 KM.</li>
                                    </ul>
                                </div>
                            </div>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Location-->
    
    <!--Unit Plan-->
    <div class="unitsectionwrap padd100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Floor Plans</h2>
                    <div class="controlar pull-right">
                        <span class="arrow-icon-leftpl">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </span>
                        <span class="arrow-icon-rightpl">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </span>
                    </div>
                </div>
                <div class="col-lg-12 wow animate__ animate__fadeInUp">
                    <div class="unitplanslider">
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="/images/projects/imperial/floor-plan/b1.jpg"><img src="/images/projects/imperial/floor-plan/s1.jpg" alt="Signature Global Imperial Floor Plan 1" title="Signature Global Imperial Floor Plan 1"/></a>
                               <h3>
                                  <b>TYPE I (1BHK)</b>
                                <span>C. A - 397.844 SQ.FT. | 36.961 SQM</span>
                                <span>B. A - 85.896 SQ.FT. | 7.980 SQM</span>
                              </h3>
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="/images/projects/imperial/floor-plan/b2.jpg"><img src="/images/projects/imperial/floor-plan/s2.jpg" alt="Signature Global Imperial Floor Plan 2" title="Signature Global Imperial Floor Plan 2"/></a>
                                <h3>
                                  <b>TYPE II (1BHK + STORE)</b>
                                <span>C. A - 418.576 SQ.FT. | 38.887 SQM</span>
                                <span>B. A - 59.675 SQ.FT. | 5.544 SQM</span>
                              </h3>
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="/images/projects/imperial/floor-plan/b3.jpg"><img src="/images/projects/imperial/floor-plan/s3.jpg" alt="Signature Global Imperial Floor Plan 3" title="Signature Global Imperial Floor Plan 3"/></a>
                               <h3>
                                  <b>TYPE I (3BHK) </b> 
                                <span>C. A - 645.791 SQ.FT. | 59.996 SQM</span>
                                <span>B. A - 113.074 SQ.FT. | 10.505 SQM</span>
                              </h3>
                            </div>
                        </div>
                        <div>
                            <div class="innunit bon_vivant">
                                <a data-fancybox="unit-gallery" href="/images/projects/imperial/floor-plan/b4.jpg"><img src="/images/projects/imperial/floor-plan/s4.jpg" alt="Signature Global Imperial Floor Plan 4" title="Signature Global Imperial Floor Plan 4"/></a>
                                <h3>
                                  <b>TYPE II (3BHK)</b>
                                <span>C. A - 643.477 SQ.FT. | 59.781 SQM</span>
                                <span>B. A - 101.396 SQ.FT. | 9.420 SQM</span>
                              </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Unit Plan-->
    
    <!--Site Plan-->
    <div class="siteplanwrap">
        <div class="container">
            <div class="row">
                <div class="col-lg-9">
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Site Plan</h2>
                </div>
                <div class="col-lg-3" style="display:none;">
                    <div class="clabtn1 wow animate__ animate__fadeInUp">
                        <a class="abtn halvar_rg" href="#">
                            DOWNLOAD BROCHURE
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{fill:none;stroke:#203d3b;stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </a>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="sitemapimg wow animate__ animate__fadeInUp">
                        <a data-fancybox="siteplan" href="/images/projects/imperial/Imperial Site plan.jpg">
                            <img src="/images/projects/imperial/Imperial Site plan.jpg" alt="Signature Global Imperial Site Plan " title="Signature Global Imperial Site Plan "/>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Site Plan-->

    <!--Projects Gallery-->
    <div class="elevationsectionwrap padd100">
        <div class="container">
          <div class="row">
            <div class="col-lg-12">
                <span class="captext fcolorlgt wow animate__ animate__fadeInUp">Elevations</span>
                <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Our Array of Affordable Accommodations</h2>
            </div>
            <div class="col-lg-12 wow animate__ animate__fadeInUp">
                <div class="progalleryslider mt-4">
                    <div class="slider-for">
                        <img class="item-slick" src="/images/projects/imperial/g-slider/SG-imperial-elevation-4.jpg" alt="Signature Global Imperial Slider 1" title="Signature Global Imperial Slider 1">
                        <img class="item-slick" src="/images/projects/imperial/g-slider/SG-imperial-elevation-5.jpg" alt="Signature Global Imperial Slider 2" title="Signature Global Imperial Slider 2">
                        <img class="item-slick" src="/images/projects/imperial/g-slider/SG-imperial-elevation-6.jpg" alt="Signature Global Imperial Slider 3" title="Signature Global Imperial Slider 3">
                        <img class="item-slick" src="/images/projects/imperial/g-slider/SG-imperial-elevation-7.jpg" alt="Signature Global Imperial Slider 3" title="Signature Global Imperial Slider 3">
                    </div>
                    <div class="slider-nav"> 
                        <img class="item-slick" src="/images/projects/imperial/g-slider/SG-imperial-elevation-4.jpg" alt="Signature Global Imperial Slider 1" title="Signature Global Imperial Slider 1">
                        <img class="item-slick" src="/images/projects/imperial/g-slider/SG-imperial-elevation-5.jpg" alt="Signature Global Imperial Slider 2" title="Signature Global Imperial Slider 2">
                        <img class="item-slick" src="/images/projects/imperial/g-slider/SG-imperial-elevation-6.jpg" alt="Signature Global Imperial Slider 3" title="Signature Global Imperial Slider 3">
                        <img class="item-slick" src="/images/projects/imperial/g-slider/SG-imperial-elevation-7.jpg" alt="Signature Global Imperial Slider 3" title="Signature Global Imperial Slider 3">
                    </div>
                </div>
            </div>
          </div>
        </div>
    </div>
    <!--Projects Gallery-->
    
    <!--Recognition-->
    <div class="recognitionwrap padb100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Recognitions</h2>
                    <p class="mb-4 wow animate__ animate__fadeInUp">Signature Global has been felicitated by many awards in 2021.</p>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-7">
                    <div class="recimg">
                        <img src="/images/projects/imperial/SG-imperial-Award-1.jpg" alt="Signature Global Imperial Award 1" title="Signature Global Imperial Award 1"/>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="recimg">
                        <img src="/images/projects/imperial/SG-imperial-Award-3.jpg" alt="Signature Global Imperial Award 3" title="Signature Global Imperial Award 3"/>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--Recognition-->
    
    <!--Amenities-->
    <div class="amenitieswrap padb100">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h2 class="headingtag fcolordrk mb-4 wow animate__ animate__fadeInUp">Amenities</h2>
                    <div class="controlam pull-right">
                        <span class="arrow-icon-left">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </span>
                        <span class="arrow-icon-right">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16.88 15.91"><defs><style>.cls-1{stroke-linecap:round;stroke-linejoin:round;}</style></defs><g id="Layer_2" data-name="Layer 2"><g id="Layer_1-2" data-name="Layer 1"><polyline class="cls-1" points="8.93 15.41 15.42 8.91 16.38 7.96 0.5 7.96"/><line class="cls-1" x1="8.93" y1="0.5" x2="14.17" y2="5.75"/></g></g></svg>
                        </span>
                   </div>
                   
                   <div class="amenitiesslider">
                       <div>
                           <div class="amenitiesimg">
                                <a data-fancybox="am-gallery" href="/images/projects/imperial/amenities/SG-imperial-ANIMETIES-1.jpg">
                                   <img src="/images/projects/imperial/amenities/SG-imperial-ANIMETIES-1.jpg" alt="Signature Global Imperial Amenities 1" title="Signature Global Imperial Amenities 1">
                                </a>
                           </div>
                           <div class="textbtnam">
                               <span>Skate Court</span>
                           </div>
                       </div>
                       <div>
                           <div class="amenitiesimg">
                                <a data-fancybox="am-gallery" href="/images/projects/imperial/amenities/SG-imperial-ANIMETIES-2.jpg">
                                    <img src="/images/projects/imperial/amenities/SG-imperial-ANIMETIES-2.jpg" alt="Signature Global Imperial Amenities 2" title="Signature Global Imperial Amenities 2">
                                </a>
                           </div>
                           <div class="textbtnam">
                               <span>Outdoor Gym</span>
                           </div>
                       </div>
                       <div>
                           <div class="amenitiesimg">
                                <a data-fancybox="am-gallery" href="/images/projects/imperial/amenities/SG-imperial-ANIMETIES-3.jpg">
                                    <img src="/images/projects/imperial/amenities/SG-imperial-ANIMETIES-3.jpg" alt="Signature Global Imperial Amenities 3" title="Signature Global Imperial Amenities 3">
                               </a>
                           </div>
                           <div class="textbtnam">
                               <span>Palm Court</span>
                           </div>
                       </div>
                       <div>
                           <div class="amenitiesimg">
                                <a data-fancybox="am-gallery" href="/images/projects/imperial/amenities/SG-imperial-ANIMETIES-4.jpg">
                                    <img src="/images/projects/imperial/amenities/SG-imperial-ANIMETIES-4.jpg" alt="Signature Global Imperial Amenities 4" title="Signature Global Imperial Amenities 4">
                                </a>
                           </div>
                           <div class="textbtnam">
                               <span>Basketball court</span>
                           </div>
                       </div>
                      
                   </div>
                </div>
            </div>
        </div>
    </div>
    <!--Amenities-->

 <div class="notificationwrap padb100">
        <div class="container">
            <div class="accordion" id="accordionExample">
               <!--construction update start-->
                
              <div class="card wow animate__ animate__fadeInUp">
                    <div class="card-head" id="headingTwo">
                        <h2 class="mb-0 collapsed" data-toggle="collapse" data-target="#collapseConstructionone" aria-expanded="false" aria-controls="collapseConstruction">
                             <b>Construction Update</b> <span class="halvar_rg text show-more-height"></span>
                        </h2>
                    </div>
                <div id="collapseConstructionone" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="notificationtable">
                                <div class="row">
                                  <div class="col-md-4">
                                        <div class="bon_vivant construction-img">
                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=i7L7vf-0221" target="_blank">
                                                <img src="images/SG-IMPERIAL.jpg" >
                                            </a>
                                            <b>Project Update</b>
                                  <span>1st September 2023</span>          
                                    </div>
                                </div>
                                   <div class="col-md-4">
                                        <div class="bon_vivant construction-img">
                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=vOirzc-0191" target="_blank">
                                                <img src="images/consUpdate/SG-IMPERIAL.jpg" >
                                            </a>
                                            <b>Project Update</b>
                                  <span>1st June 2023</span>          
                                    </div>
                                </div>
                                  <div class="col-md-4">
                                        <div class="bon_vivant construction-img">
                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=GA8AO2-0177" target="_blank">
                                                <img src="/images/projects/imperial/constructionUpdate/SGImperical-march.jpg" >
                                            </a>
                                            <b>Project Update</b>
                                  <span>1st March 2023</span>          
                                    </div>
                                </div>
                                   
                                    <div class="col-md-4 mt-5">
                                        <div class="bon_vivant construction-img">
                                            <a href="http://image.signatureglobal.in/ProjectUpdates/Gallery.html?T=4Dj8sM-0130" target="_blank">
                                                <img src="/images/projects/imperial/constructionUpdate/Imperical.jpg" >
                                            </a>
                                            <b>Project Update</b>
                                  <span>1st September 2022</span>          
                                    </div>
                                </div>
                             
                             
                                
                                </div>
                                
                            </div>
                        </div>
                    </div>


                </div>
                
                
                
                <!--construction update end-->
              
              <div class="card wow animate__ animate__fadeInUp">
                    <div class="card-head" id="headingTwo">
                        <h2 class="mb-0 collapsed show-more" data-toggle="collapse" data-target="#collapseConstruction" aria-expanded="false" aria-controls="collapseTwo">
                             <b>Draw List</b> <span class="halvar_rg text show-more-height"></span>
                        </h2>
                    </div>
                
                    <div id="collapseConstruction" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="notificationtable draw-list">
                                <div class="searchrow">
                                    <p>Search by Application Number or Applicant Name</p>
                                    <form class="form-inline">
                                        <input class="form-control" type="search" placeholder="Search" aria-label="Search" id="draw-search">
                                        <button class="btn brbtn draw-result" type="button" data-id="imperial"><img src="/images/icon/Search.svg" alt="btn"/></button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
              
              
              
              
                <div class="card wow animate__ animate__fadeInUp">
                    <div class="card-head" id="headingOne">
                        <h2 class="mb-0 collapsed show-more" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
                            <b>Notification Advertisement</b> <span class="halvar_rg text show-more-height"></span>
                        </h2>
                    </div>
                
                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                        <div class="card-body">
                            <div class="notificationtable">
                                <div class="table-responsive">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Publication</th>
                                                <th>Date</th>
                                                <th>English</th>
                                                <th>Hindi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                          
                                          <tr>
                                                <td>Dainik Jagran(Gurugram) </td>
                                                <td>10.11.2022</td>
                                              	<td>-</td>
                                                <td><a href="/pdf/Imperial_8x10cm.pdf" target="_blank"><img src="/images/icon/pdf.svg" alt="/pdf"/></a></td>
                                            
                                            </tr>
                                           <tr>
                                                <td>Jansatta ( DNCR) , Dainil Jagran( Gurugram) (Draw result ad) </td>
                                                <td>18.05.2022</td>
                                              	<td>-</td>
                                                <td><a href="/pdf/SG Imperial Draw Result Ad_28x25cm Hindi.pdf" target="_blank"><img src="/images/icon/pdf.svg" alt="/pdf"/></a></td>
                                            
                                            </tr>
                                           <tr>
                                                <td>Indian Express, Financial Express (Draw result ad) </td>
                                                <td>18.05.2022</td>
                                              	
                                                <td><a href="/pdf/SG Imperial Draw Result Ad_28x25cm English.pdf" target="_blank"><img src="/images/icon/pdf.svg" alt="/pdf"/></a></td>
                                            <td>-</td>
                                            </tr>
                                          
                                          
                                          
                                          <tr>
                                                <td>Indian Express, Financial Express (Draw Intimation Ad) </td>
                                                <td>12.05.2022</td>
                                              	
                                                <td><a href="/pdf/Imperial Draw English Ad 8X10 cm _ 1.pdf" target="_blank"><img src="/images/icon/pdf.svg" alt="/pdf"/></a></td>
                                            <td>-</td>
                                            </tr>
                                          <tr>
                                                <td>Jansatta and Dainik Jagran (Draw Intimation Ad) </td>
                                                <td>12.05.2022</td>
                                              	<td>-</td>
                                                <td><a href="/pdf/Imperial _Draw hindi Ad 8X10 cm _ 1.pdf" target="_blank"><img src="/images/icon/pdf.svg" alt="/pdf"/></a></td>
                                            </tr>
                                          
                                          
                                          	<tr>
                                                <td>Jansatta and Dainik Jagran (Extension Ad Hindi) </td>
                                                <td>09.04.2022</td>
                                              	<td>-</td>
                                                <td><a href="/pdf/imperial/notification/Signature-Global-Imperial-Extension-Legal-Hindi.pdf" target="_blank"><img src="/images/icon/pdf.svg" alt="/pdf"/></a></td>
                                            </tr>
                                          	<tr>
                                                <td>Indian Express, Financial Express (Extension Ad English)</td>
                                                <td>09.04.2022</td>
                                                <td><a href="/pdf/imperial/notification/Signature-Global-Imperial-Extension-Legal-English.pdf" target="_blank"><img src="/images/icon/pdf.svg" alt="/pdf"/></a></td>
                                                <td>-</td>
                                            </tr>
                                           <!-- <tr>
                                                <td>Times of India English</td>
                                                <td>23.03.2022</td>
                                                <td><a href="/pdf/imperial/notification/Jacket Front Times of India Gurgaon 32.8cm(w)x48cm(h).pdf" target="_blank"><img src="/images/icon/pdf.svg" alt="/pdf"/></a></td>
                                                <td>-</td>
                                            </tr> -->
                                            <tr>
                                                <td>Indian Express ( Notification Ad English)</td>
                                                <td>23.03.2022</td>
                                                <td><a href="/pdf/imperial/Notification-ad-week1(English).pdf" target="_blank"><img src="/images/icon/pdf.svg" alt="/pdf"/></a></td>
                                               <td>-</td>
                                            </tr>
                                          
                                          <!--<tr>
                                                <td>Times of India, Indian Express, Financial Express, Hindustan Times (Week 1 Legal Ad English)</td>
                                                <td>23.03.2022</td>
                                              
                                                <td><a href="/pdf/imperial/Notification-ad(English).pdf" target="_blank"><img src="/images/icon/pdf.svg" alt="/pdf"/></a></td>
                                                <td>-</td>
                                            </tr>-->
                                          
                                            <tr>
                                                <td>Dainik Jagran (Notification Ad Hindi)</td>
                                                <td>23.03.2022</td>
                                              <td>-</td>
                                                <td><a href="/pdf/imperial/Notification-ad(Hindi).pdf" target="_blank"><img src="/images/icon/pdf.svg" alt="/pdf"/></a></td>
                                                
                                            </tr>
                                          <tr>
                                                <td>Jansatta (Notification Ad Hindi)</td>
                                                <td>23.03.2022</td>
                                              <td>-</td>
                                                <td><a href="/pdf/imperial/Notification-ad(Hindi).pdf" target="_blank"><img src="/images/icon/pdf.svg" alt="/pdf"/></a></td>
                                                
                                            </tr>
                                          
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--CIN No-->
    <div class="footerpagetop">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        <span>SIGNATUREGLOBAL (INDIA) LIMITED | CIN: U70100DL2000PLC104787 | LICENSE No. : 80 OF 2018 DATED 02.12.18</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--CIN No-->
	<div class="footerpagetop">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="textwrap">
                        <strong>Disclaimer</strong>
                      	<p>Promoter urges every applicant to inspect the project site and shall not merely rely upon any architectural impression, plan or sales brochure and, therefore, requests to make personal judgment prior to submitting an application for allotment. Unless otherwise stated, all the images, visuals, materials and information contained herein are purely creative/artistic and may not be actual representations of the product and/or any amenities. Further, the actual design may vary in the fit and finished form, from the one displayed above. Journey time shown, if any, is based upon Google Maps which may vary as per the traffic at a relevant point of time.. *Rate mentioned above does not include GST and other statutory charges, if applicable. T & C Apply. 1 sq. mt. = 10.7639 sq. ft.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    

<!--Footer-->
    <footer class="footerbg padd100">
       <div class="width100">
            <div class="container">
                <div class="row paddb60">
                   <div class="col-12">
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt m-0 wow animate__ animate__fadeInUp">
                                    <strong>SIGNATURE GLOBAL</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/residential/" title="Residentential projects by Signature Global">Residential</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/" title="Commercial projects by Signature Global">Commercial</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/">Retail</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class=" footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>OUR PRESENCE</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/commercial/society-shops/gurugram/" title="Signature Global in Gurugram">Gurugram</a></li>
                                        <li><a href="https://www.signatureglobal.in/residential/plots/karnal" title="Signature Global in Karnal">Karnal</a></li>
                                        <li><a href="https://www.signatureglobal.in/commercial/malls/ghaziabad" title="Signature Global in Ghaziabad">Ghaziabad</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>ABOUT US</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#chairmans-message" title="Signature Global - Chairman's message" class="scdown">Chairman’s Message</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#board-of-directors" title="Signature Global - Board of Director" class="scdown">Board of Directors</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#key-managerial" title="Signature Global - Key Managerial Positions" class="scdown">Key Managerial Positions</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#our-architects" title="Our Architect" class="scdown">Our Architects</a></li>
                                        <li><a href="https://www.signatureglobal.in/about-us.php#vission-mission" title="Signature Global - Vission & Mission of Signature Global" class="scdown">Vision & Mission</a></li>
                                    <!--    <li><a href="signature-global-foundation.php" title="Signature Global Foundation">Signature Global Foundation</a></li>-->
                                    </ul>
                                </div>
                           </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                <div class="footertopmrg footernav halvar_lt wow animate__ animate__fadeInUp">
                                    <strong>CAREERS</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/career.php#as-associate" title="Careers at Signature Global">As Associate</a></li>
                                        <li><a href="https://www.signatureglobal.in/career.php#life-signature" title="Life At Signature Global">Life @ Signature Global </a></li>
                                        <li><a href="#"></a></li>
                                    </ul>
                                </div>
                              
                                <div class="footernav halvar_lt wow animate__ animate__fadeInUp publicnoticehome">
                                  <ul>
                                    <li><a href="https://www.signatureglobal.in/public-notice.php" title="Signature Global Public Notice"><strong>Public Notice</strong></a></li>
                                  </ul>                                  
                             	</div>
                                          
                           </div>
                            
                        </div>
                        <div class="row">
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong style="margin-bottom: 15px;">GALLERY</strong>
                                    <ul>
                                        <li><a href="https://www.signatureglobal.in/gallery.php" title="Signature Global Gallery">Picture Library</a></li>
                                        <li><a href="https://www.signatureglobal.in/video-gallery.php" title="Signature Global Video Gallery">Video Library</a></li>
                                    </ul>
                                </div>   
                            </div>
                           <div class="col-lg-3 col-md-6 col-sm-6 footerone">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/media.php" title="Signature Global Blogs">MEDIA</a></strong> 
                                    <ul>
                                     <li><a href="https://www.signatureglobal.in/media-coverage.php" title="Signature Global Gallery">Media Coverage</a></li>
                                        <!--<li><a href="https://www.signatureglobal.in/press-release.php" title="Signature Global Video Gallery">Press Release</a></li> -->
                                         <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Gallery">Press Kit</a></li>
                                        <li><a href="https://www.signatureglobal.in/media.php" title="Signature Global Video Gallery">Media Contact</a></li>
                                    </ul>
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footertwo">
                                <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                   <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/blog" title="Signature Global Blogs">Blog</a></strong>
                                <!--    <strong class="mb-2"><a class="clrwh opctext" href="https://online.anyflip.com/dhkmm/nalj/mobile/index.html" target="_blank" title="Signature Global Newsletter ">NEWSLETTER</a></strong> -->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/home-loans.php" title="Signature Global - Home Loans">Home Loans</a></strong>
                                  <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/pay-online.php" title="Signature Global - APPLY ONLINE">PAY ONLINE</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/award.php" title="Signature Global Certificates">AWARD</a></strong>                                  
                                </div>   
                            </div>
                            <div class="col-lg-3 col-md-6 col-sm-6 footerthree">
                                 <div class="footernav halvar_lt mtop wow animate__ animate__fadeInUp">
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://payment.signatureglobal.in/SGIPL/BDALogin.aspx" target="_blank" title="Signature Global Login">MBDA/BDA Login</a></strong>
                                   <!-- <strong class="mb-2"><a class="clrwh opctext" href="http://signatureglobal04.realboost.in/add_appointment.aspx" target="_blank" title="Signature Global Appointments">Appointment</a></strong>-->
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/terms-of-appointment.php" title="Signature Global - Terms of appointment">Terms of Appointment</a></strong>
                                    <strong class="mb-2"><a class="clrwh opctext" href="https://www.signatureglobal.in/green-development.php" title="Signature Global - Green Development">Green Development</a></strong>
                                </div>     
                            </div>
                        </div>
                        
                   </div>
                </div>
            </div>
        </div>
      
        
        <div class="width100 bordertop padt60 wow animate__ animate__fadeInUp">
            <div class="container">
                <div class="row">    
                    <div class="col-lg-3">
                       <div class="footerlogo wow animate__ animate__fadeInUp">
                           <img src="https://www.signatureglobal.in/images/SG-Making-Affordable-India.png" alt="Signature Global" title="Signature Global"/>
                       </div> 
                    </div>
                    <div class="col-lg-4">
                        <div class="footernav pl-65 wow animate__ animate__fadeInUp">
                            <strong>REGISTERED OFFICE</strong>
                            <p>13<sup>th</sup> Floor, Dr. Gopal Das Bhawan, 28<br class="ftmb"/> Barakhamba Road, Connaught Place,<br class="ftmb"/> New Delhi 110 001, India.</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Registered Office: +91 11 4928 1700</a>
                        </div>
                    </div>
                    <div class="col-lg-3 pl-00">
                        <div class="footernav wow animate__ animate__fadeInUp">
                            <strong>CORPORATE OFFICE</strong>
                            <p>Unit No.101, Ground Floor, Tower-A,<br class="ftmb"/>Signature Tower South City-1, Gurugram,<br class="ftmb"/>Haryana 122 001, India</p>
                            <a class="mt-3" href="tel:011–49281700">Telephone Corporate Office: +91 124 4398 011</a>
                        </div>
                    </div>
                    <div class="col-lg-2">
                        <div class="footermedianav mtopft wow animate__ animate__fadeInUp">
                            <strong>FOLLOW US</strong>
                            <ul>
                                <li><a href="https://www.facebook.com/SignatureGlobal" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://twitter.com/signatureglobal" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/signatureglobal/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/channel/UCWjSj4Lo9M2GKe6Q3qKzXzA" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                                <li><a href="https://www.linkedin.com/company/signature-global" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                            </ul>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </footer>
     <!--policytab-->
     <div class="policywraper">
         <div class="container">
             <div class="row">
                 <div class="col-lg-10 col-md-10">
                     <div class="policylink text-left">
                        <p>© 2023 Signature Global. All Rights Reserved <br class="mobhidebr"/><span class="clrwh mobhide">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/advertising-policy-for-channel-partners.php"  >Advertising Policy For Channel Partners</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/privacy-policy.php" title="Signature Global - Privacy Policy">Privacy Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                        <a href="https://www.signatureglobal.in/social-media-policy.php" title="Signature Global - Social Media Policy">Social Media Policy</a><span class="clrwh">&nbsp; | &nbsp;</span>
                          <a href="https://www.signatureglobal.in/generic-faqs-for-haryana-affordable-housing-policy.php">Generic Faq's</a>                        
                       </p>
                       
                     </div>
                  
                 </div>
             <!--     <div class="col-lg-2 col-md-2 cclogo ">
                     <img src="https://www.signatureglobal.in/images/cogdigital.svg" alt="" width="15">
                   </div> -->
             </div>
         </div>
     </div>
   
    <script>
         $.urlParam = function (name) {
            var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);
            return (results !== null) ? results[1] || 0 : false;
            }
            
            var utmSource = $.urlParam('utm_source') ? $.urlParam('utm_source') : 'direct';
            var utmMedium = $.urlParam('utm_medium') ? $.urlParam('utm_medium') : '';
            var utmCampaign = $.urlParam('utm_campaign') ? $.urlParam('utm_campaign') : '';
            var utmId = $.urlParam('utm_id') ? $.urlParam('utm_id') : '';
             
            var enq_url = new URL("https://enquiry.signatureglobal.in/?projectName=ContactUs&enquiryFrom=Online");
            $(function() {
                    enq_url.searchParams.set('utm_source',utmSource);
                    if(utmMedium!=""){enq_url.searchParams.set('utm_medium',utmMedium);}
                    if(utmCampaign!=""){enq_url.searchParams.set('utm_campaign',utmCampaign);}
                    if(utmId!=""){enq_url.searchParams.set('utm_id',utmId);}
                    
              if($('#main_frame').length > 0)
                    $('#main_frame').attr('src', enq_url)
            
            });

    </script>


<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/animate.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/jquery.fancybox.min.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>
<link rel="preload" type="text/css" href="https://www.signatureglobal.in/css/slick.css" as="style" onload="this.onload=null;this.rel='stylesheet'"/>


<script src="https://www.signatureglobal.in/js/wow.min.js"></script>
<script src="https://www.signatureglobal.in/js/slick.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.fancybox.min.js"></script>
<script src="https://www.signatureglobal.in/js/jquery.validate.min.js"></script>
<script src="https://www.signatureglobal.in/js/additional-methods.js"></script>
<script src="https://www.signatureglobal.in/js/custom.js"></script> 
<script src="https://www.signatureglobal.in/js/app.js"></script> 
<!-- Start of  Zendesk Widget script -->
<script>
   setTimeout(function(){
      var chatScript = '<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"/>';
      $('body').append(chatScript);
   },  
 5000);
</script>

<script>
  window.addEventListener('load', function() {
    jQuery('body').on('mousedown', '[href*="tel:"]', function() {
      gtag('event', 'phone_call')
    })
    jQuery('body').on('mousedown', '[href*="api.whatsapp.com"]', function() {
      gtag('event', 'whatsapp_click')
    })
    jQuery('body').on('mousedown', '.btnrt:contains(Enquire Now)', function() {
      gtag('event', 'enquire_now')
    })
    jQuery('body').on('mousedown', '.contact100-form-btn:contains(Submit)', function() {
      gtag('event', 'Submit_btn')
    })
  });

</script>
<!--<script id="ze-snippet" src="https://static.zdassets.com/ekr/snippet.js?key=666fc206-fb4c-44a7-9731-6569a7cde84d"> </script>-->
<!-- End of  Zendesk Widget script -->





 


</body>
</html>
<script>
         $.urlParam = function (name) {
            var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.search);
            return (results !== null) ? results[1] || 0 : false;
            }
            
            var utmSource = $.urlParam('utm_source') ? $.urlParam('utm_source') : 'direct';
            var utmMedium = $.urlParam('utm_medium') ? $.urlParam('utm_medium') : '';
            var utmCampaign = $.urlParam('utm_campaign') ? $.urlParam('utm_campaign') : '';
            var utmId = $.urlParam('utm_id') ? $.urlParam('utm_id') : '';
             
            var url = new URL("https://enquiry.signatureglobal.in/?projectName=imperial&enquiryFrom=Online");
            $(function() {
             
                    if(utmSource!=""){url.searchParams.set('utm_source',utmSource);}
                    if(utmMedium!=""){url.searchParams.set('utm_medium',utmMedium);}
                    if(utmCampaign!=""){url.searchParams.set('utm_campaign',utmCampaign);}
                    if(utmId!=""){url.searchParams.set('utm_id',utmId);}
                    $('#abc_frame').attr('src', url);
             
                    
            });

    </script>
